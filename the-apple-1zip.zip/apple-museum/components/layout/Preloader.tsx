"use client";

import { useEffect, useRef, useState } from "react";
import { markReady } from "@/lib/ready";

const SESSION_KEY = "museum:preloaded";
const MIN_DURATION = 1600; // ms — long enough to read, short enough not to annoy

/**
 * Black curtain with a thin progress line and a 0 → 100 counter.
 * Progress eases toward the real load state (document + fonts), never faster than MIN_DURATION.
 * Shown once per session; later navigations skip straight to the content.
 */
export function Preloader() {
  const [visible, setVisible] = useState(true);
  const [leaving, setLeaving] = useState(false);
  const [count, setCount] = useState(0);
  const raf = useRef(0);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let seen = false;
    try {
      seen = sessionStorage.getItem(SESSION_KEY) === "1";
    } catch {
      /* storage may be unavailable */
    }

    if (seen) {
      setVisible(false);
      markReady();
      return;
    }

    let loaded = document.readyState === "complete";
    const onLoad = () => (loaded = true);
    window.addEventListener("load", onLoad);

    const start = performance.now();
    const duration = reduce ? 400 : MIN_DURATION;
    let value = 0;

    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      // Hold at 90 until the page has actually loaded.
      const ceiling = loaded ? 100 : 90;
      const target = Math.min(ceiling, 100 * (1 - Math.pow(1 - t, 3)));
      value += (target - value) * 0.18;
      const shown = Math.round(value >= 99.5 && loaded && t >= 1 ? 100 : value);
      setCount(shown);

      if (shown >= 100) {
        try {
          sessionStorage.setItem(SESSION_KEY, "1");
        } catch {
          /* ignore */
        }
        setLeaving(true);
        // Let the hero begin its entrance as the curtain lifts.
        window.setTimeout(markReady, reduce ? 0 : 250);
        window.setTimeout(() => setVisible(false), reduce ? 300 : 1100);
        return;
      }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);

    // Safety net: never trap the visitor behind the curtain.
    const failSafe = window.setTimeout(() => {
      loaded = true;
    }, 6000);

    return () => {
      cancelAnimationFrame(raf.current);
      window.removeEventListener("load", onLoad);
      window.clearTimeout(failSafe);
    };
  }, []);

  if (!visible) return null;

  return (
    <div
      role="progressbar"
      aria-label="Loading the museum"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={count}
      className={`fixed inset-0 z-[100] flex flex-col justify-end bg-ink transition-[clip-path] duration-1000 ease-[var(--ease-wipe)] motion-reduce:transition-opacity motion-reduce:duration-300 ${
        leaving ? "[clip-path:inset(0_0_100%_0)] motion-reduce:opacity-0" : "[clip-path:inset(0_0_0_0)]"
      }`}
    >
      <div className="container-museum pb-10 md:pb-14">
        <div className="mb-6 flex items-end justify-between">
          <p className="micro text-mute">The Apple Museum</p>
          <p className="text-[clamp(3rem,10vw,8rem)] font-medium leading-none tracking-[-0.05em] tabular-nums">
            {String(count).padStart(3, "0")}
          </p>
        </div>
        <div className="h-px w-full bg-line">
          <div className="h-px origin-left bg-paper" style={{ transform: `scaleX(${count / 100})` }} />
        </div>
        <div className="mt-4 flex justify-between">
          <p className="counter text-mute">1976</p>
          <p className="counter text-mute">Today</p>
        </div>
      </div>
    </div>
  );
}
