"use client";

import Link from "next/link";
import { FOOTER_NAV, SITE, SOCIALS } from "@/lib/site";
import { SocialIcon } from "./SocialIcon";
import { useSmoothScroll } from "./SmoothScroll";

export function Footer() {
  const { scrollTo } = useSmoothScroll();
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t hairline bg-ink pt-20 md:pt-28" aria-labelledby="footer-title">
      <div className="container-museum">
        <div className="grid gap-14 md:grid-cols-12">
          <div className="md:col-span-6">
            <p id="footer-title" className="display-sm max-w-[12ch]">
              Every product marks a decision.
            </p>
          </div>
          <nav aria-label="Footer" className="md:col-span-3">
            <p className="micro mb-6 text-mute">Explore</p>
            <ul className="grid grid-cols-2 gap-x-6 gap-y-3 md:grid-cols-1">
              {FOOTER_NAV.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-paper/80 transition-colors hover:text-paper">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div className="flex flex-col justify-between gap-10 md:col-span-3">
            <div>
              <p className="micro mb-6 text-mute">Follow</p>
              <ul className="flex gap-5" aria-label="Social media">
                {SOCIALS.map((s) => (
                  <li key={s.label}>
                    <a
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`${s.label} (opens in a new tab)`}
                      className="text-mute transition-colors hover:text-paper"
                    >
                      <SocialIcon name={s.icon} />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <button
              type="button"
              onClick={() => scrollTo(0)}
              className="micro group inline-flex items-center gap-3 self-start text-paper"
            >
              Back to top
              <span className="relative inline-flex h-4 w-4 overflow-hidden" aria-hidden="true">
                <svg viewBox="0 0 16 16" className="absolute h-4 w-4 transition-transform duration-500 group-hover:-translate-y-full" fill="none" stroke="currentColor" strokeWidth="1.4">
                  <path d="M8 14V3M3.5 7.5 8 3l4.5 4.5" />
                </svg>
                <svg viewBox="0 0 16 16" className="absolute h-4 w-4 translate-y-full transition-transform duration-500 group-hover:translate-y-0" fill="none" stroke="currentColor" strokeWidth="1.4">
                  <path d="M8 14V3M3.5 7.5 8 3l4.5 4.5" />
                </svg>
              </span>
            </button>
          </div>
        </div>

        <p
          aria-hidden="true"
          className="mt-20 select-none whitespace-nowrap text-[clamp(3rem,13.5vw,15rem)] font-semibold leading-[0.8] tracking-[-0.06em] text-paper/[0.06] md:mt-28"
        >
          Apple Museum
        </p>

        <div className="flex flex-col gap-3 border-t hairline py-6 text-xs text-mute md:flex-row md:items-center md:justify-between">
          <p>{SITE.disclaimer}</p>
          <p>© {year} {SITE.name}. Independent and non-commercial.</p>
        </div>
      </div>
    </footer>
  );
}
