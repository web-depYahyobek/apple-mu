"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef } from "react";
import { NAV, SOCIALS, SITE } from "@/lib/site";
import { pad } from "@/lib/format";
import { SocialIcon } from "./SocialIcon";

type Props = {
  open: boolean;
  onClose: () => void;
};

const EASE = [0.76, 0, 0.24, 1] as const;

/**
 * Full-screen navigation. Curtain wipes down, links rise line by line.
 * Keyboard: focus moves into the dialog, Tab is trapped, Escape closes,
 * focus returns to the "Navigate" button on close (handled by the header).
 */
export function NavOverlay({ open, onClose }: Props) {
  const panel = useRef<HTMLDivElement>(null);
  const pathname = usePathname();
  const reduce = useReducedMotion();

  useEffect(() => {
    if (!open) return;
    const el = panel.current;
    const focusables = () =>
      Array.from(el?.querySelectorAll<HTMLElement>("a[href], button:not([disabled])") ?? []).filter(
        (n) => n.offsetParent !== null,
      );
    // Focus the first menu link once the reveal has started.
    const t = window.setTimeout(() => el?.querySelector<HTMLElement>("nav a")?.focus(), 250);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key !== "Tab") return;
      const items = focusables();
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(t);
      document.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  const line = {
    hidden: { y: reduce ? 0 : "110%", opacity: reduce ? 0 : 1 },
    show: (i: number) => ({
      y: "0%",
      opacity: 1,
      transition: { duration: reduce ? 0.2 : 0.9, ease: EASE, delay: reduce ? 0 : 0.35 + i * 0.07 },
    }),
    exit: { y: reduce ? 0 : "-110%", opacity: reduce ? 0 : 1, transition: { duration: reduce ? 0.15 : 0.5, ease: EASE } },
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={panel}
          id="site-navigation"
          role="dialog"
          aria-modal="true"
          aria-label="Site navigation"
          className="fixed inset-0 z-[80] flex flex-col overflow-y-auto bg-ink text-paper"
          initial={reduce ? { opacity: 0 } : { clipPath: "inset(0% 0% 100% 0%)" }}
          animate={reduce ? { opacity: 1 } : { clipPath: "inset(0% 0% 0% 0%)" }}
          exit={reduce ? { opacity: 0 } : { clipPath: "inset(100% 0% 0% 0%)" }}
          transition={{ duration: reduce ? 0.2 : 0.9, ease: EASE }}
          data-lenis-prevent
        >
          <div className="container-museum flex h-[var(--header-h)] shrink-0 items-center justify-between">
            <Link href="/" onClick={onClose} className="text-sm font-medium tracking-[-0.01em]">
              {SITE.name}
            </Link>
            <button type="button" onClick={onClose} className="micro group inline-flex items-center gap-3" aria-label="Close navigation">
              Close
              <span className="relative block h-3 w-3" aria-hidden="true">
                <span className="absolute left-0 top-1/2 h-px w-full rotate-45 bg-current transition-transform duration-500 group-hover:rotate-[135deg]" />
                <span className="absolute left-0 top-1/2 h-px w-full -rotate-45 bg-current transition-transform duration-500 group-hover:rotate-45" />
              </span>
            </button>
          </div>

          <nav aria-label="Primary" className="container-museum flex flex-1 flex-col justify-center py-10">
            <ul className="border-t hairline">
              {NAV.map((item, i) => {
                const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
                return (
                  <li key={item.href} className="overflow-hidden border-b hairline">
                    <motion.div custom={i} variants={line} initial="hidden" animate="show" exit="exit">
                      <Link
                        href={item.href}
                        onClick={onClose}
                        aria-current={active ? "page" : undefined}
                        className="group flex items-baseline justify-between gap-6 py-3 md:py-4"
                      >
                        <span className="flex items-baseline gap-5">
                          <span className="counter text-mute">{pad(i + 1)}</span>
                          <span
                            className={`text-[clamp(2.5rem,7.5vh,6rem)] font-medium leading-[1] tracking-[-0.045em] transition-[color,transform] duration-500 ease-[var(--ease-expo)] group-hover:translate-x-3 ${
                              active ? "text-paper" : "text-paper/55 group-hover:text-paper"
                            }`}
                          >
                            {item.label}
                          </span>
                        </span>
                        {active && <span className="micro text-mute">Current</span>}
                      </Link>
                    </motion.div>
                  </li>
                );
              })}
            </ul>
          </nav>

          <motion.div
            className="container-museum flex shrink-0 flex-col gap-6 pb-8 md:flex-row md:items-end md:justify-between"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, transition: { delay: reduce ? 0 : 0.8, duration: 0.6 } }}
            exit={{ opacity: 0, transition: { duration: 0.2 } }}
          >
            <p className="max-w-sm text-sm text-mute">A museum of everything Apple has ever made. 1976 to today.</p>
            <ul className="flex gap-5" aria-label="Social media">
              {SOCIALS.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${s.label} (opens in a new tab)`}
                    className="text-mute transition-colors hover:text-paper"
                  >
                    <SocialIcon name={s.icon} />
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
