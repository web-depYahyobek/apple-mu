"use client";

import Lenis from "lenis";
import { usePathname } from "next/navigation";
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { gsap, ScrollTrigger } from "@/lib/gsap";

type Ctx = {
  lenis: Lenis | null;
  /** Scroll to a target (selector, element or y-offset). Falls back to native scrolling. */
  scrollTo: (target: string | number | HTMLElement, opts?: { offset?: number; immediate?: boolean }) => void;
  /** Lock / unlock page scrolling (used by the navigation overlay and the lightbox). */
  lock: (locked: boolean) => void;
};

const SmoothScrollContext = createContext<Ctx>({ lenis: null, scrollTo: () => {}, lock: () => {} });

export function useSmoothScroll() {
  return useContext(SmoothScrollContext);
}

/**
 * Lenis smooth scrolling, driven by GSAP's ticker so ScrollTrigger stays in sync.
 * Disabled entirely when the visitor prefers reduced motion.
 */
export function SmoothScroll({ children }: { children: ReactNode }) {
  const [lenis, setLenis] = useState<Lenis | null>(null);
  const lenisRef = useRef<Lenis | null>(null);
  const pathname = usePathname();

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const instance = new Lenis({ lerp: 0.1, smoothWheel: true, wheelMultiplier: 1 });
    lenisRef.current = instance;
    setLenis(instance);

    instance.on("scroll", ScrollTrigger.update);
    const raf = (time: number) => instance.raf(time * 1000);
    gsap.ticker.add(raf);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(raf);
      instance.destroy();
      lenisRef.current = null;
      setLenis(null);
    };
  }, []);

  // New route: jump to top and let ScrollTrigger re-measure once images have settled.
  useEffect(() => {
    lenisRef.current?.scrollTo(0, { immediate: true, force: true });
    if (!lenisRef.current) window.scrollTo(0, 0);
    const id = window.setTimeout(() => ScrollTrigger.refresh(), 400);
    const onLoad = () => ScrollTrigger.refresh();
    window.addEventListener("load", onLoad);
    return () => {
      window.clearTimeout(id);
      window.removeEventListener("load", onLoad);
    };
  }, [pathname]);

  const value: Ctx = {
    lenis,
    scrollTo: (target, opts = {}) => {
      const l = lenisRef.current;
      if (l) {
        l.scrollTo(target, { offset: opts.offset ?? 0, immediate: opts.immediate, duration: 1.4 });
        return;
      }
      let y = 0;
      if (typeof target === "number") y = target;
      else {
        const el = typeof target === "string" ? document.querySelector<HTMLElement>(target) : target;
        if (!el) return;
        y = el.getBoundingClientRect().top + window.scrollY;
      }
      window.scrollTo({ top: y + (opts.offset ?? 0), behavior: "auto" });
    },
    lock: (locked) => {
      const l = lenisRef.current;
      if (l) {
        if (locked) l.stop();
        else l.start();
      }
      document.documentElement.style.overflow = locked ? "hidden" : "";
    },
  };

  return <SmoothScrollContext.Provider value={value}>{children}</SmoothScrollContext.Provider>;
}
