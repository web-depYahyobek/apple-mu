"use client";

import type { ReactNode } from "react";
import { Cursor } from "./Cursor";
import { Header } from "./Header";
import { Preloader } from "./Preloader";
import { SmoothScroll } from "./SmoothScroll";

/** Client-side shell: smooth scroll context, preloader, cursor and header. */
export function Providers({ children }: { children: ReactNode }) {
  return (
    <SmoothScroll>
      <Preloader />
      <Cursor />
      <Header />
      {children}
    </SmoothScroll>
  );
}
