"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { SITE } from "@/lib/site";
import { NavOverlay } from "./NavOverlay";
import { useSmoothScroll } from "./SmoothScroll";

/**
 * Fixed header: text wordmark left, "Navigate" right.
 * Uses mix-blend-difference so it stays legible over any image.
 */
export function Header() {
  const [open, setOpen] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  const pathname = usePathname();
  const { lock } = useSmoothScroll();

  const close = useCallback(() => {
    setOpen(false);
    // Return focus to the trigger for keyboard users.
    window.setTimeout(() => toggle.current?.focus({ preventScroll: true }), 50);
  }, []);

  useEffect(() => {
    lock(open);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Close on route change.
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <>
      <a
        href="#main"
        className="micro fixed left-4 top-4 z-[130] -translate-y-24 bg-paper px-4 py-3 text-ink transition-transform focus:translate-y-0"
      >
        Skip to content
      </a>
      <header className="pointer-events-none fixed inset-x-0 top-0 z-[70] mix-blend-difference">
        <div className="container-museum flex h-[var(--header-h)] items-center justify-between text-paper">
          <Link href="/" className="pointer-events-auto text-sm font-medium tracking-[-0.01em]" aria-label={`${SITE.name}, home`}>
            {SITE.name}
          </Link>
          <button
            ref={toggle}
            type="button"
            onClick={() => setOpen(true)}
            aria-expanded={open}
            aria-controls="site-navigation"
            className="micro group pointer-events-auto inline-flex items-center gap-3"
          >
            Navigate
            <span className="flex w-5 flex-col gap-[5px]" aria-hidden="true">
              <span className="h-px w-full bg-current transition-transform duration-500 ease-[var(--ease-expo)] group-hover:scale-x-50 group-hover:origin-right" />
              <span className="h-px w-full bg-current transition-transform duration-500 ease-[var(--ease-expo)] group-hover:scale-x-75 group-hover:origin-left" />
            </span>
          </button>
        </div>
      </header>
      <NavOverlay open={open} onClose={close} />
    </>
  );
}
