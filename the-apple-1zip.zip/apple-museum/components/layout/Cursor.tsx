"use client";

import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { gsap } from "@/lib/gsap";

type Mode = "default" | "link" | "view" | "drag";

/**
 * A small dot that follows the pointer.
 * - grows over links, buttons and images
 * - becomes a disc with "View" over product cards ([data-cursor="view"])
 * - shows "Drag" over sliders ([data-cursor="drag"])
 * Only on fine pointers (mouse / trackpad). Touch devices keep native behaviour.
 */
export function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);
  const [mode, setMode] = useState<Mode>("default");
  const [hidden, setHidden] = useState(true);
  const pathname = usePathname();

  useEffect(() => {
    const mql = window.matchMedia("(pointer: fine) and (hover: hover)");
    const update = () => setEnabled(mql.matches);
    update();
    mql.addEventListener("change", update);
    return () => mql.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    if (!enabled || !dot.current) return;
    document.documentElement.classList.add("has-cursor");

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const xTo = gsap.quickTo(dot.current, "x", { duration: reduce ? 0 : 0.35, ease: "power3.out" });
    const yTo = gsap.quickTo(dot.current, "y", { duration: reduce ? 0 : 0.35, ease: "power3.out" });

    const onMove = (e: PointerEvent) => {
      xTo(e.clientX);
      yTo(e.clientY);
      setHidden(false);
    };
    const onOver = (e: PointerEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target?.closest) return;
      const explicit = target.closest<HTMLElement>("[data-cursor]");
      if (explicit) {
        setMode((explicit.dataset.cursor as Mode) ?? "link");
        return;
      }
      if (target.closest("a, button, [role='button'], label, select, summary, img")) setMode("link");
      else setMode("default");
    };
    const onLeave = () => setHidden(true);

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerover", onOver, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);

    return () => {
      document.documentElement.classList.remove("has-cursor");
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      document.documentElement.removeEventListener("pointerleave", onLeave);
    };
  }, [enabled]);

  // Reset on navigation (the element under the pointer has changed).
  useEffect(() => setMode("default"), [pathname]);

  if (!enabled) return null;

  const size = mode === "view" || mode === "drag" ? 84 : mode === "link" ? 36 : 8;

  return (
    <div
      ref={dot}
      aria-hidden="true"
      className="pointer-events-none fixed left-0 top-0 z-[120] mix-blend-difference"
      style={{ opacity: hidden ? 0 : 1, transition: "opacity 200ms" }}
    >
      <div
        className="flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-paper text-ink transition-[width,height] duration-300 ease-[var(--ease-expo)]"
        style={{ width: size, height: size }}
      >
        <span
          className={`micro text-[10px] tracking-[0.18em] transition-opacity duration-200 ${mode === "view" || mode === "drag" ? "opacity-100" : "opacity-0"}`}
        >
          {mode === "drag" ? "Drag" : "View"}
        </span>
      </div>
    </div>
  );
}
