"use client";

import { useCallback, useId, useRef, useState, type KeyboardEvent } from "react";
import type { OsFamily } from "@/data/types";
import { MuseumImage } from "@/components/ui/MuseumImage";

/**
 * Before / after comparison of two OS versions.
 * Drag the handle (mouse, touch or pen), or focus it and use ← / → / Home / End.
 */
export function EvolutionSlider({ family }: { family: OsFamily }) {
  const versions = family.versions;
  const [a, setA] = useState(0);
  const [b, setB] = useState(versions.length - 1);
  const [pos, setPos] = useState(50);
  const frame = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const id = useId();

  const setFromClientX = useCallback((clientX: number) => {
    const rect = frame.current?.getBoundingClientRect();
    if (!rect) return;
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.max(0, Math.min(100, pct)));
  }, []);

  const left = versions[a];
  const right = versions[b];

  const onKey = (e: KeyboardEvent) => {
    const step = e.shiftKey ? 10 : 2;
    if (e.key === "ArrowLeft" || e.key === "ArrowDown") setPos((p) => Math.max(0, p - step));
    else if (e.key === "ArrowRight" || e.key === "ArrowUp") setPos((p) => Math.min(100, p + step));
    else if (e.key === "Home") setPos(0);
    else if (e.key === "End") setPos(100);
    else return;
    e.preventDefault();
  };

  const select = (value: number, set: (n: number) => void, label: string) => (
    <label className="flex flex-col gap-2">
      <span className="micro text-mute">{label}</span>
      <select
        value={value}
        onChange={(e) => set(Number(e.target.value))}
        className="border border-line bg-ink px-3 py-2.5 text-sm text-paper focus:border-paper focus:outline-none"
      >
        {versions.map((v, i) => (
          <option key={v.slug} value={i}>
            {v.name} ({v.year})
          </option>
        ))}
      </select>
    </label>
  );

  return (
    <div>
      <div className="mb-6 grid grid-cols-2 gap-4 md:max-w-xl">
        {select(a, setA, "Before")}
        {select(b, setB, "After")}
      </div>

      <div
        ref={frame}
        data-cursor="drag"
        className="relative aspect-[16/10] w-full touch-pan-y select-none overflow-hidden bg-ink-2"
        onPointerDown={(e) => {
          dragging.current = true;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          setFromClientX(e.clientX);
        }}
        onPointerMove={(e) => dragging.current && setFromClientX(e.clientX)}
        onPointerUp={() => (dragging.current = false)}
        onPointerCancel={() => (dragging.current = false)}
      >
        {/* After (full) */}
        <div className="absolute inset-0">
          <MuseumImage src={right.image.src} alt={right.image.alt} fill sizes="(min-width: 1024px) 66vw, 100vw" />
        </div>
        {/* Before (clipped) */}
        <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
          <MuseumImage src={left.image.src} alt={left.image.alt} fill sizes="(min-width: 1024px) 66vw, 100vw" />
        </div>

        <span className="micro pointer-events-none absolute left-4 top-4 bg-ink/70 px-2 py-1 text-paper">{left.name}</span>
        <span className="micro pointer-events-none absolute right-4 top-4 bg-ink/70 px-2 py-1 text-paper">{right.name}</span>

        {/* Handle */}
        <div className="absolute inset-y-0 w-px bg-paper" style={{ left: `${pos}%` }}>
          <button
            type="button"
            role="slider"
            aria-label={`Compare ${left.name} and ${right.name}`}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(pos)}
            aria-valuetext={`${Math.round(pos)}% ${left.name}`}
            aria-describedby={`${id}-hint`}
            onKeyDown={onKey}
            className="absolute left-1/2 top-1/2 flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-paper bg-ink/80 text-paper backdrop-blur"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
              <path d="m9 7-5 5 5 5M15 7l5 5-5 5" />
            </svg>
          </button>
        </div>
      </div>
      <p id={`${id}-hint`} className="sr-only">
        Use the left and right arrow keys to move the divider.
      </p>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <p className="text-sm text-mute">
          <span className="text-paper">{left.name}, {left.year}.</span> {left.note}
        </p>
        <p className="text-sm text-mute md:text-right">
          <span className="text-paper">{right.name}, {right.year}.</span> {right.note}
        </p>
      </div>
    </div>
  );
}
