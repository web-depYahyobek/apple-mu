"use client";

import { createElement, useRef, type ReactNode } from "react";
import { gsap, MQ, ScrollTrigger, SplitText, useGSAP } from "@/lib/gsap";
import { onReady } from "@/lib/ready";

type Tag = "h1" | "h2" | "h3" | "p" | "span" | "div";

type Props = {
  as?: Tag;
  children: ReactNode;
  className?: string;
  /** "scroll" reveals when it enters the viewport; "ready" waits for the preloader. */
  trigger?: "scroll" | "ready";
  /** Split by lines (default) or words. */
  by?: "lines" | "words";
  delay?: number;
  id?: string;
};

/**
 * Headline that slides up line-by-line (or word-by-word) from a mask.
 * Uses GSAP SplitText with `autoSplit`, so it re-splits on resize and after fonts load.
 * Screen readers get the original text (SplitText sets aria-label automatically).
 */
export function SplitHeadline({ as = "h2", children, className, trigger = "scroll", by = "lines", delay = 0, id }: Props) {
  const ref = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const el = ref.current;
      if (!el) return;
      const mm = gsap.matchMedia();

      mm.add(MQ.motion, () => {
        let unsubscribe = () => {};
        let trig: ScrollTrigger | undefined;
        // Once revealed, later re-splits (resize, font load) must not hide the text again.
        let played = false;

        const split = SplitText.create(el, {
          type: by === "lines" ? "lines" : "words,lines",
          mask: by === "lines" ? "lines" : "words",
          linesClass: "split-line",
          autoSplit: true,
          onSplit(self) {
            if (played) return;
            const targets = by === "lines" ? self.lines : self.words;
            const tween = gsap.from(targets, {
              yPercent: 115,
              duration: 1.1,
              ease: "expo.out",
              stagger: by === "lines" ? 0.1 : 0.06,
              delay,
              paused: true,
            });
            const play = () => {
              played = true;
              tween.play();
            };
            unsubscribe();
            trig?.kill();
            if (trigger === "ready") {
              unsubscribe = onReady(play);
            } else {
              trig = ScrollTrigger.create({ trigger: el, start: "top 88%", once: true, onEnter: play });
            }
            return tween;
          },
        });
        return () => {
          unsubscribe();
          trig?.kill();
          split.revert();
        };
      });

      mm.add(MQ.reduced, () => {
        gsap.from(el, { opacity: 0, duration: 0.6, delay: trigger === "ready" ? 0.2 : 0 });
      });

      return () => mm.revert();
    },
    { scope: ref },
  );

  return createElement(as, { ref, className, id }, children);
}
