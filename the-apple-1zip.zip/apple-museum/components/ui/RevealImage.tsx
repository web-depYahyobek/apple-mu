"use client";

import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { MuseumImage } from "./MuseumImage";
import type { ProductImage } from "@/data/types";

type Props = {
  image: ProductImage;
  /** Tailwind classes for the frame (set the size / aspect ratio here). */
  className?: string;
  sizes?: string;
  priority?: boolean;
  /** Extra classes for the <img>. */
  imgClassName?: string;
  /** Skip the scroll reveal (e.g. when a parent animates it). */
  static?: boolean;
};

/**
 * Image that reveals as it enters the viewport:
 * a clip-path mask opens from the bottom while the image settles from 1.15 → 1.
 * With reduced motion it simply fades in.
 */
export function RevealImage({ image, className, sizes = "100vw", priority, imgClassName, static: isStatic }: Props) {
  const frame = useRef<HTMLDivElement>(null);
  const inner = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      if (isStatic || !frame.current || !inner.current) return;
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        gsap.fromTo(
          frame.current,
          { clipPath: "inset(100% 0% 0% 0%)" },
          {
            clipPath: "inset(0% 0% 0% 0%)",
            duration: 1.2,
            ease: "expo.out",
            scrollTrigger: { trigger: frame.current, start: "top 88%", once: true },
          },
        );
        gsap.fromTo(
          inner.current,
          { scale: 1.15 },
          {
            scale: 1,
            duration: 1.6,
            ease: "expo.out",
            scrollTrigger: { trigger: frame.current, start: "top 88%", once: true },
          },
        );
      });
      mm.add(MQ.reduced, () => {
        gsap.fromTo(
          frame.current,
          { opacity: 0 },
          { opacity: 1, duration: 0.6, scrollTrigger: { trigger: frame.current, start: "top 92%", once: true } },
        );
      });
      return () => mm.revert();
    },
    { scope: frame },
  );

  return (
    <div ref={frame} className={`relative overflow-hidden bg-ink-2 ${className ?? ""}`}>
      <div ref={inner} className="absolute inset-0 will-change-transform">
        <MuseumImage src={image.src} alt={image.alt} fill sizes={sizes} priority={priority} className={imgClassName} />
      </div>
    </div>
  );
}
