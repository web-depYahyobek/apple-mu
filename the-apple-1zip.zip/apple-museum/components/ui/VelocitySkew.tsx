"use client";

import { useRef, type ReactNode } from "react";
import { gsap, MQ, ScrollTrigger, useGSAP } from "@/lib/gsap";

/**
 * Skews its content slightly in the direction of scroll, proportional to scroll speed,
 * and settles back when scrolling stops. Gives grids a physical, elastic feel.
 */
export function VelocitySkew({ children, className = "", max = 5 }: { children: ReactNode; className?: string; max?: number }) {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const el = ref.current;
      if (!el) return;
      const mm = gsap.matchMedia();
      mm.add(MQ.desktopMotion, () => {
        const skewTo = gsap.quickTo(el, "skewY", { duration: 0.8, ease: "power3.out" });
        const clamp = gsap.utils.clamp(-max, max);
        const st = ScrollTrigger.create({
          trigger: el,
          start: "top bottom",
          end: "bottom top",
          onUpdate: (self) => skewTo(clamp(self.getVelocity() / -400)),
          onLeave: () => skewTo(0),
          onLeaveBack: () => skewTo(0),
        });
        // Settle when scrolling stops.
        const settle = () => skewTo(0);
        ScrollTrigger.addEventListener("scrollEnd", settle);
        return () => {
          st.kill();
          ScrollTrigger.removeEventListener("scrollEnd", settle);
          gsap.set(el, { skewY: 0 });
        };
      });
      return () => mm.revert();
    },
    { scope: ref },
  );

  return (
    <div ref={ref} className={`origin-center will-change-transform ${className}`}>
      {children}
    </div>
  );
}
