type Props = {
  items: string[];
  reverse?: boolean;
  className?: string;
  label?: string;
};

/**
 * Infinite CSS marquee (40s loop). The list is rendered twice and shifted by -50%.
 * Pauses on hover/focus; stops entirely with prefers-reduced-motion.
 */
export function Marquee({ items, reverse, className = "", label }: Props) {
  const row = (hidden: boolean) => (
    <ul className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {items.map((item) => (
        <li
          key={item}
          className="flex items-center whitespace-nowrap px-6 text-[clamp(1.75rem,4vw,3.75rem)] font-semibold tracking-[-0.04em] text-mute/70 transition-colors duration-500 hover:text-paper md:px-10"
        >
          {item}
          <span aria-hidden="true" className="ml-12 inline-block h-1.5 w-1.5 rounded-full bg-mute/40 md:ml-20" />
        </li>
      ))}
    </ul>
  );

  return (
    <div className={`marquee relative flex overflow-hidden ${className}`} aria-label={label} role={label ? "region" : undefined}>
      <div className={`marquee-track flex w-max ${reverse ? "animate-marquee-reverse" : "animate-marquee"}`}>
        {row(false)}
        {row(true)}
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-ink to-transparent" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-ink to-transparent" />
    </div>
  );
}
