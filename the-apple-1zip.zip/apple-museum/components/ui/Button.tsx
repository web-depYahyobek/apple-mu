import Link from "next/link";
import type { ReactNode } from "react";

type Common = {
  children: ReactNode;
  className?: string;
  variant?: "outline" | "solid" | "text";
};

type LinkProps = Common & { href: string; type?: never; onClick?: never; disabled?: never };
type ButtonProps = Common & {
  href?: undefined;
  type?: "button" | "submit";
  onClick?: () => void;
  disabled?: boolean;
};

export function Arrow({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" aria-hidden="true" className={`h-3.5 w-3.5 ${className}`} fill="none" stroke="currentColor" strokeWidth="1.4">
      <path d="M2 8h11M9 3.5 13.5 8 9 12.5" strokeLinecap="square" />
    </svg>
  );
}

/**
 * Button / link with a fill-from-bottom hover and an arrow that slides through.
 * Pure CSS so it works in server components.
 */
export function Button(props: LinkProps | ButtonProps) {
  const { children, className = "", variant = "outline" } = props;

  if (variant === "text") {
    const inner = (
      <>
        <span className="relative">
          {children}
          <span className="absolute -bottom-1 left-0 h-px w-full origin-right scale-x-0 bg-current transition-transform duration-500 ease-[var(--ease-expo)] group-hover:origin-left group-hover:scale-x-100" />
        </span>
        <span className="relative inline-flex h-3.5 w-3.5 overflow-hidden">
          <Arrow className="absolute transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-x-full" />
          <Arrow className="absolute -translate-x-full transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-x-0" />
        </span>
      </>
    );
    const cls = `group micro inline-flex items-center gap-3 text-paper ${className}`;
    return props.href ? (
      <Link href={props.href} className={cls}>
        {inner}
      </Link>
    ) : (
      <button type={props.type ?? "button"} onClick={props.onClick} disabled={props.disabled} className={cls}>
        {inner}
      </button>
    );
  }

  const solid = variant === "solid";
  const cls = [
    "group relative inline-flex items-center gap-4 overflow-hidden border px-7 py-4 micro transition-colors duration-500 ease-[var(--ease-expo)]",
    solid ? "border-paper bg-paper text-ink hover:text-paper" : "border-paper/40 text-paper hover:text-ink hover:border-paper",
    "disabled:pointer-events-none disabled:opacity-40",
    className,
  ].join(" ");

  const inner = (
    <>
      <span
        aria-hidden="true"
        className={`absolute inset-0 translate-y-full transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-y-0 ${solid ? "bg-ink" : "bg-paper"}`}
      />
      <span className="relative">{children}</span>
      <span className="relative inline-flex h-3.5 w-3.5 overflow-hidden">
        <Arrow className="absolute transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-x-full" />
        <Arrow className="absolute -translate-x-full transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-x-0" />
      </span>
    </>
  );

  if (props.href) {
    return (
      <Link href={props.href} className={cls}>
        {inner}
      </Link>
    );
  }
  return (
    <button type={props.type ?? "button"} onClick={props.onClick} disabled={props.disabled} className={cls}>
      {inner}
    </button>
  );
}
