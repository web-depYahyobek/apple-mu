import Image, { type ImageProps } from "next/image";

/**
 * A tiny dark gradient used as the blur placeholder for every image.
 * For per-image blur hashes, generate them at build time (see README → Images).
 */
export const BLUR_DATA_URL =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAKCAYAAACJxx+AAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAeklEQVQYlYWPUQrDIBAF9wCCuEa3qSaxkZLe/4KvvL2AHw+GGUEVVUWthn1/o7XuI9OxybYVF8dx4rqGj0zHJjzZWscYH8z59ZHp2MTshd5P3PfE8/x8ZDq29YHlFctHLr8ZY0TOGaVUmJmPTMcmIQSHlBJUs49Mx/YHdVlnvZjm6ZEAAAAASUVORK5CYII=";

type Props = Omit<ImageProps, "placeholder" | "blurDataURL"> & { blur?: boolean };

/** next/image with the museum's defaults: blur placeholder, object-cover when filling. */
export function MuseumImage({ blur = true, className, fill, ...rest }: Props) {
  return (
    <Image
      {...rest}
      fill={fill}
      placeholder={blur ? "blur" : "empty"}
      blurDataURL={blur ? BLUR_DATA_URL : undefined}
      className={[fill ? "object-cover" : "", className ?? ""].join(" ").trim()}
    />
  );
}
