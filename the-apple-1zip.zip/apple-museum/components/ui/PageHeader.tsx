import { SplitHeadline } from "./SplitHeadline";

type Props = {
  eyebrow: string;
  title: string;
  intro?: string;
  counter?: string;
};

/** Shared header for inner pages: micro-label, giant headline, short intro. */
export function PageHeader({ eyebrow, title, intro, counter }: Props) {
  return (
    <header className="container-museum pb-16 pt-[calc(var(--header-h)+5rem)] md:pb-24 md:pt-[calc(var(--header-h)+8rem)]">
      <div className="mb-10 flex items-center justify-between border-b hairline pb-4">
        <p className="micro text-mute">{eyebrow}</p>
        {counter && <p className="counter text-mute">{counter}</p>}
      </div>
      <SplitHeadline as="h1" trigger="ready" className="display max-w-[14ch]">
        {title}
      </SplitHeadline>
      {intro && <p className="lead mt-10 max-w-2xl text-mute">{intro}</p>}
    </header>
  );
}
