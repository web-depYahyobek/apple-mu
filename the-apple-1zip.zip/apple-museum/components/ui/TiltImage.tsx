"use client";

import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import type { ProductImage } from "@/data/types";
import { MuseumImage } from "./MuseumImage";

type Props = {
  image: ProductImage;
  className?: string;
  sizes?: string;
  priority?: boolean;
  /** "contain" keeps the whole photo visible (best for real product photography). */
  fit?: "cover" | "contain";
};

/**
 * A framed photograph that tilts in 3D toward the pointer, with a moving glare.
 * Entrance: rises out of a clip mask with a slight 3D swing.
 */
export function TiltImage({ image, className = "", sizes = "50vw", priority, fit = "contain" }: Props) {
  const root = useRef<HTMLDivElement>(null);
  const card = useRef<HTMLDivElement>(null);
  const glare = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const el = root.current;
      const c = card.current;
      if (!el || !c) return;
      const mm = gsap.matchMedia();

      mm.add(MQ.motion, () => {
        gsap.fromTo(
          c,
          { clipPath: "inset(100% 0% 0% 0%)", rotateX: 18, y: 80, scale: 0.92 },
          { clipPath: "inset(0% 0% 0% 0%)", rotateX: 0, y: 0, scale: 1, duration: 1.6, ease: "expo.out", delay: 0.2 },
        );
      });

      mm.add(`${MQ.motion} and (pointer: fine)`, () => {
        const rx = gsap.quickTo(c, "rotateX", { duration: 0.8, ease: "power3.out" });
        const ry = gsap.quickTo(c, "rotateY", { duration: 0.8, ease: "power3.out" });
        const gx = gsap.quickTo(glare.current, "xPercent", { duration: 0.8, ease: "power3.out" });
        const gy = gsap.quickTo(glare.current, "yPercent", { duration: 0.8, ease: "power3.out" });
        const move = (e: PointerEvent) => {
          const r = el.getBoundingClientRect();
          const nx = (e.clientX - r.left) / r.width - 0.5;
          const ny = (e.clientY - r.top) / r.height - 0.5;
          ry(nx * 14);
          rx(-ny * 12);
          gx(nx * 100);
          gy(ny * 100);
          gsap.to(glare.current, { opacity: 1, duration: 0.4 });
        };
        const leave = () => {
          rx(0);
          ry(0);
          gsap.to(glare.current, { opacity: 0, duration: 0.6 });
        };
        el.addEventListener("pointermove", move);
        el.addEventListener("pointerleave", leave);
        return () => {
          el.removeEventListener("pointermove", move);
          el.removeEventListener("pointerleave", leave);
        };
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <div ref={root} className={`[perspective:1400px] ${className}`}>
      <div
        ref={card}
        className="relative h-full w-full overflow-hidden bg-ink-2 shadow-[0_60px_120px_-40px_rgba(0,0,0,0.9)] ring-1 ring-white/10 [transform-style:preserve-3d] will-change-transform"
      >
        <MuseumImage
          src={image.src}
          alt={image.alt}
          fill
          sizes={sizes}
          priority={priority}
          className={fit === "contain" ? "!object-contain p-4 md:p-8" : ""}
        />
        <div
          ref={glare}
          aria-hidden="true"
          className="pointer-events-none absolute -inset-1/2 opacity-0 mix-blend-soft-light"
          style={{ background: "radial-gradient(circle at 50% 50%, rgba(255,255,255,0.55), transparent 45%)" }}
        />
      </div>
    </div>
  );
}
