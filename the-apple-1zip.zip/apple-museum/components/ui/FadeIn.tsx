"use client";

import { useRef, type ReactNode } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";

type Props = {
  children: ReactNode;
  className?: string;
  /** Animate direct children one after another. */
  stagger?: boolean;
  y?: number;
  delay?: number;
  as?: "div" | "section" | "ul" | "ol" | "dl" | "article";
};

/** Generic block reveal: fade + rise as it enters the viewport. Pure fade with reduced motion. */
export function FadeIn({ children, className, stagger = false, y = 32, delay = 0, as: Tag = "div" }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const el = ref.current;
      if (!el) return;
      const targets = stagger ? Array.from(el.children) : el;
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        gsap.from(targets, {
          y,
          opacity: 0,
          duration: 1,
          ease: "power3.out",
          delay,
          stagger: stagger ? 0.08 : 0,
          scrollTrigger: { trigger: el, start: "top 88%", once: true },
        });
      });
      mm.add(MQ.reduced, () => {
        gsap.from(targets, { opacity: 0, duration: 0.5, scrollTrigger: { trigger: el, start: "top 92%", once: true } });
      });
      return () => mm.revert();
    },
    { scope: ref },
  );

  return (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    <Tag ref={ref as any} className={className}>
      {children}
    </Tag>
  );
}
