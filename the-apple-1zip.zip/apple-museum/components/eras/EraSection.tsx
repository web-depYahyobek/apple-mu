import type { Era, Product } from "@/data/types";
import { ProductCard } from "@/components/collection/ProductCard";
import { RevealImage } from "@/components/ui/RevealImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { FadeIn } from "@/components/ui/FadeIn";

type Props = { era: Era; index: number; total: number; products: Product[] };

/**
 * One era: its own colour mood (via --accent), a sticky headline column
 * and a scrolling story with the products released in that period.
 */
export function EraSection({ era, index, total, products }: Props) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    <section
      id={era.slug}
      aria-labelledby={`${era.slug}-title`}
      className="relative scroll-mt-[calc(var(--header-h)+4rem)] border-t hairline"
      style={{ ["--accent" as string]: era.accent }}
    >
      <div className="era-glow pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="container-museum relative grid gap-12 py-24 md:py-32 lg:grid-cols-12">
        {/* Sticky column */}
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-[calc(var(--header-h)+5rem)]">
            <div className="mb-8 flex items-center gap-4">
              <span className="counter text-mute">
                {pad(index + 1)} / {pad(total)}
              </span>
              <span className="h-px w-10" style={{ background: `rgb(${era.accent})` }} aria-hidden="true" />
              <span className="micro text-mute">{era.range}</span>
            </div>
            <h2 id={`${era.slug}-title`} className="micro mb-6" style={{ color: `rgb(${era.accent})` }}>
              {era.title}
            </h2>
            <SplitHeadline as="p" className="display-sm max-w-[13ch]">
              {era.headline}
            </SplitHeadline>
            <p className="lead mt-8 max-w-md text-paper/80">{era.intro}</p>
          </div>
        </div>

        {/* Story */}
        <div className="lg:col-span-6 lg:col-start-7">
          <RevealImage image={era.image} className="mb-14 aspect-[16/10]" sizes="(min-width: 1024px) 50vw, 100vw" />
          <FadeIn stagger as="ol" className="space-y-10">
            {era.story.map((para, i) => (
              <li key={i} className="grid grid-cols-[3rem_1fr] gap-4 border-t hairline pt-6">
                <span className="counter text-mute">{pad(i + 1)}</span>
                <p className="text-lg leading-relaxed text-paper/85">{para}</p>
              </li>
            ))}
          </FadeIn>

          {products.length > 0 && (
            <div className="mt-20">
              <div className="mb-8 flex items-end justify-between border-b hairline pb-4">
                <h3 className="micro text-mute">In the collection</h3>
                <span className="counter text-mute">{products.length} objects</span>
              </div>
              <FadeIn stagger className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
                {products.map((p) => (
                  <ProductCard key={p.slug} product={p} aspect="aspect-square" sizes="(min-width: 1024px) 16vw, (min-width: 768px) 30vw, 50vw" />
                ))}
              </FadeIn>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
