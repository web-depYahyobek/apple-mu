"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import type { MouseEvent } from "react";
import type { Product } from "@/data/types";
import { MuseumImage } from "@/components/ui/MuseumImage";

type Props = {
  product: Product;
  /** Tailwind aspect class for the image, e.g. "aspect-[4/5]". */
  aspect?: string;
  sizes?: string;
  className?: string;
  /** When set, a plain click opens a quick view instead of navigating (Cmd/Ctrl-click still navigates). */
  onOpen?: (product: Product) => void;
};

/** Archive card: image zooms on hover, a "Year / Name" label slides up. */
export function ProductCard({ product, aspect = "aspect-[4/5]", sizes = "(min-width: 1024px) 25vw, 50vw", className = "", onOpen }: Props) {
  const click = (e: MouseEvent<HTMLAnchorElement>) => {
    if (!onOpen || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    onOpen(product);
  };

  return (
    <Link
      href={`/collection/${product.slug}`}
      onClick={click}
      data-cursor="view"
      className={`group block focus-visible:outline-offset-8 ${className}`}
      aria-label={`${product.name}, ${product.year}. ${product.category}.${onOpen ? " Opens quick view." : ""}`}
    >
      <motion.div layoutId={onOpen ? `qv-img-${product.slug}` : undefined} className={`relative overflow-hidden bg-ink-2 ${aspect}`}>
        <MuseumImage
          src={product.images[0].src}
          alt={product.images[0].alt}
          fill
          sizes={sizes}
          className="transition-transform duration-[1200ms] ease-[var(--ease-expo)] group-hover:scale-[1.06] motion-reduce:transition-none"
        />
        <div className="absolute inset-x-0 bottom-0 translate-y-full bg-gradient-to-t from-ink/90 to-transparent p-4 pt-10 transition-transform duration-700 ease-[var(--ease-expo)] group-hover:translate-y-0 group-focus-visible:translate-y-0 motion-reduce:transition-none">
          <p className="micro text-paper">
            {product.year} / {product.name}
          </p>
        </div>
      </motion.div>
      <div className="mt-4 flex items-baseline justify-between gap-4">
        <h3 className="text-base font-medium tracking-[-0.02em]">{product.name}</h3>
        <span className="counter shrink-0 text-mute">{product.year}</span>
      </div>
      <p className="micro mt-2 text-mute">{product.category}</p>
    </Link>
  );
}
