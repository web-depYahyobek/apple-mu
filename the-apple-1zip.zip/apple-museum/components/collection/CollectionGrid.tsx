"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Flip, gsap } from "@/lib/gsap";
import { CATEGORIES, type Category, type Product } from "@/data/types";
import { decadeOf } from "@/lib/format";
import { ProductCard } from "./ProductCard";
import { QuickView } from "./QuickView";
import { VelocitySkew } from "@/components/ui/VelocitySkew";

type Sort = "year-asc" | "year-desc" | "name";

const ASPECTS = ["aspect-[4/5]", "aspect-square", "aspect-[3/4]", "aspect-[4/5]", "aspect-[5/6]", "aspect-[4/3]"];

/** Stable aspect ratio per product so cards keep their shape across filters. */
function aspectFor(slug: string) {
  let h = 0;
  for (let i = 0; i < slug.length; i++) h = (h * 31 + slug.charCodeAt(i)) >>> 0;
  return ASPECTS[h % ASPECTS.length];
}

const useIsoLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;

/**
 * Filterable, searchable masonry archive.
 * - Columns are filled round-robin so reading order stays left → right.
 * - Layout changes animate with GSAP Flip (skipped with reduced motion).
 * - The ?category= query parameter pre-selects a category (used by the home page exhibits).
 */
export function CollectionGrid({ products }: { products: Product[] }) {
  const params = useSearchParams();
  const initialCategory = params.get("category");

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Category | "All">(
    CATEGORIES.includes(initialCategory as Category) ? (initialCategory as Category) : "All",
  );
  const [decade, setDecade] = useState<number | "All">("All");
  const [sort, setSort] = useState<Sort>("year-asc");
  const [columns, setColumns] = useState(3);
  const [quick, setQuick] = useState<Product | null>(null);

  const grid = useRef<HTMLDivElement>(null);
  const flipState = useRef<Flip.FlipState | null>(null);

  // Responsive column count.
  useEffect(() => {
    const update = () => {
      const w = window.innerWidth;
      setColumns(w >= 1280 ? 4 : w >= 768 ? 3 : 2);
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  // Keep the URL in sync with the category, without a navigation.
  useEffect(() => {
    const url = new URL(window.location.href);
    if (category === "All") url.searchParams.delete("category");
    else url.searchParams.set("category", category);
    window.history.replaceState(null, "", url.toString());
  }, [category]);

  const decades = useMemo(() => [...new Set(products.map((p) => decadeOf(p.year)))].sort(), [products]);
  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const p of products) map.set(p.category, (map.get(p.category) ?? 0) + 1);
    return map;
  }, [products]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = products.filter((p) => {
      if (category !== "All" && p.category !== category) return false;
      if (decade !== "All" && decadeOf(p.year) !== decade) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        String(p.year).includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.designers.some((d) => d.toLowerCase().includes(q)) ||
        p.summary.toLowerCase().includes(q)
      );
    });
    return list.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name);
      if (sort === "year-desc") return b.releaseDate.localeCompare(a.releaseDate);
      return a.releaseDate.localeCompare(b.releaseDate);
    });
  }, [products, query, category, decade, sort]);

  const cols = useMemo(() => {
    const out: Array<Array<{ product: Product; index: number }>> = Array.from({ length: columns }, () => []);
    filtered.forEach((product, index) => out[index % columns].push({ product, index }));
    return out;
  }, [filtered, columns]);

  /** Capture positions before any state change that affects layout. */
  const capture = () => {
    if (!grid.current) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    flipState.current = Flip.getState(grid.current.querySelectorAll("[data-flip-id]"));
  };

  useIsoLayoutEffect(() => {
    const state = flipState.current;
    if (!state || !grid.current) return;
    flipState.current = null;
    Flip.from(state, {
      targets: grid.current.querySelectorAll("[data-flip-id]"),
      duration: 0.7,
      ease: "power3.out",
      stagger: 0.015,
      absolute: false,
      onEnter: (els) => gsap.fromTo(els, { opacity: 0, scale: 0.94 }, { opacity: 1, scale: 1, duration: 0.6, ease: "power3.out" }),
    });
  }, [filtered]);

  const reset = () => {
    capture();
    setQuery("");
    setCategory("All");
    setDecade("All");
    setSort("year-asc");
  };

  const chip = (active: boolean) =>
    `micro whitespace-nowrap border px-4 py-2.5 transition-colors duration-300 ${
      active ? "border-paper bg-paper text-ink" : "border-line text-paper/75 hover:border-paper/60 hover:text-paper"
    }`;

  return (
    <div>
      {/* Controls */}
      <div className="sticky top-[var(--header-h)] z-20 border-y hairline bg-ink/90 backdrop-blur-md">
        <div className="container-museum flex flex-col gap-4 py-4">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <label className="relative block md:w-80">
              <span className="sr-only">Search the collection</span>
              <input
                type="search"
                value={query}
                onChange={(e) => {
                  capture();
                  setQuery(e.target.value);
                }}
                placeholder="Search name, year, designer…"
                className="w-full border-b border-line bg-transparent py-2.5 pr-8 text-sm text-paper placeholder:text-mute focus:border-paper focus:outline-none"
              />
              <svg viewBox="0 0 16 16" className="absolute right-1 top-1/2 h-4 w-4 -translate-y-1/2 text-mute" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
                <circle cx="7" cy="7" r="4.5" />
                <path d="m10.5 10.5 3.5 3.5" />
              </svg>
            </label>
            <div className="flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-2">
                <span className="micro text-mute">Decade</span>
                <select
                  value={decade}
                  onChange={(e) => {
                    capture();
                    setDecade(e.target.value === "All" ? "All" : Number(e.target.value));
                  }}
                  className="border border-line bg-ink px-3 py-2 text-sm text-paper focus:border-paper focus:outline-none"
                >
                  <option value="All">All</option>
                  {decades.map((d) => (
                    <option key={d} value={d}>
                      {d}s
                    </option>
                  ))}
                </select>
              </label>
              <label className="flex items-center gap-2">
                <span className="micro text-mute">Sort</span>
                <select
                  value={sort}
                  onChange={(e) => {
                    capture();
                    setSort(e.target.value as Sort);
                  }}
                  className="border border-line bg-ink px-3 py-2 text-sm text-paper focus:border-paper focus:outline-none"
                >
                  <option value="year-asc">Year, oldest first</option>
                  <option value="year-desc">Year, newest first</option>
                  <option value="name">Name, A–Z</option>
                </select>
              </label>
            </div>
          </div>

          <div className="-mx-5 overflow-x-auto px-5 [scrollbar-width:none] md:mx-0 md:overflow-visible md:px-0" role="group" aria-label="Filter by category">
            <div className="flex gap-2 md:flex-wrap">
              <button
                type="button"
                aria-pressed={category === "All"}
                className={chip(category === "All")}
                onClick={() => {
                  capture();
                  setCategory("All");
                }}
              >
                All <span className="opacity-60">{products.length}</span>
              </button>
              {CATEGORIES.filter((c) => counts.get(c)).map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-pressed={category === c}
                  className={chip(category === c)}
                  onClick={() => {
                    capture();
                    setCategory(c);
                  }}
                >
                  {c} <span className="opacity-60">{counts.get(c)}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="container-museum py-12 md:py-16">
        <p className="counter mb-8 text-mute" aria-live="polite">
          Showing {filtered.length} of {products.length}
        </p>

        {filtered.length === 0 ? (
          <div className="border-t hairline py-24 text-center">
            <p className="display-sm">Nothing in the archive matches.</p>
            <button type="button" onClick={reset} className="micro mt-8 underline decoration-paper/40 underline-offset-8 hover:decoration-paper">
              Clear filters
            </button>
          </div>
        ) : (
          <VelocitySkew>
          <div ref={grid} className="flex items-start gap-4 md:gap-6">
            {cols.map((col, ci) => (
              <div key={ci} className="flex min-w-0 flex-1 flex-col gap-10 md:gap-14">
                {col.map(({ product }) => (
                  <div key={product.slug} data-flip-id={product.slug}>
                    <ProductCard
                      product={product}
                      aspect={aspectFor(product.slug)}
                      onOpen={setQuick}
                      sizes={`(min-width: 1280px) 25vw, (min-width: 768px) 33vw, 50vw`}
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
          </VelocitySkew>
        )}
      </div>
      <QuickView product={quick} list={filtered} onChange={setQuick} />
    </div>
  );
}
