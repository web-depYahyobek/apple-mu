"use client";

import Link from "next/link";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useRef } from "react";
import type { Product } from "@/data/types";
import { ERA_BY_SLUG } from "@/data/eras";
import { formatDate } from "@/lib/format";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { Button } from "@/components/ui/Button";
import { useSmoothScroll } from "@/components/layout/SmoothScroll";

type Props = {
  product: Product | null;
  /** The list the visitor is browsing, for previous / next. */
  list: Product[];
  onChange: (p: Product | null) => void;
};

const EASE = [0.16, 1, 0.3, 1] as const;

/**
 * Full-information quick view. The card image morphs into the panel (shared layout),
 * then facts, specs and the story stagger in. ← / → browse, Escape closes.
 */
export function QuickView({ product, list, onChange }: Props) {
  const panel = useRef<HTMLDivElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const reduce = useReducedMotion();
  const { lock } = useSmoothScroll();
  const open = product !== null;

  const index = product ? list.findIndex((p) => p.slug === product.slug) : -1;
  const go = (dir: 1 | -1) => {
    if (index < 0 || !list.length) return;
    onChange(list[(index + dir + list.length) % list.length]);
  };

  useEffect(() => {
    if (!open) return;
    returnFocus.current = document.activeElement as HTMLElement;
    lock(true);
    const t = window.setTimeout(() => panel.current?.querySelector<HTMLElement>("[data-qv-close]")?.focus(), 80);
    return () => {
      window.clearTimeout(t);
      lock(false);
      returnFocus.current?.focus?.({ preventScroll: true });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onChange(null);
      else if (e.key === "ArrowRight") go(1);
      else if (e.key === "ArrowLeft") go(-1);
      else if (e.key === "Tab" && panel.current) {
        const items = Array.from(panel.current.querySelectorAll<HTMLElement>("a[href], button"));
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  });

  const item = {
    hidden: { opacity: 0, y: reduce ? 0 : 24 },
    show: (i: number) => ({ opacity: 1, y: 0, transition: { duration: reduce ? 0.2 : 0.8, ease: EASE, delay: reduce ? 0 : 0.25 + i * 0.05 } }),
  };

  return (
    <AnimatePresence>
      {product && (
        <motion.div
          key="qv"
          className="fixed inset-0 z-[105] flex items-stretch justify-center md:items-center md:p-6 lg:p-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.3 } }}
        >
          <button type="button" aria-label="Close quick view" tabIndex={-1} onClick={() => onChange(null)} className="absolute inset-0 bg-ink/80 backdrop-blur-md" />

          <div
            ref={panel}
            role="dialog"
            aria-modal="true"
            aria-labelledby="qv-title"
            className="relative grid h-full w-full max-w-[1400px] grid-cols-1 overflow-y-auto border hairline bg-ink md:h-[min(860px,100%)] md:grid-cols-2 md:overflow-hidden"
            data-lenis-prevent
          >
            {/* Image side */}
            <div className="relative min-h-[46svh] md:min-h-0">
              <motion.div layoutId={`qv-img-${product.slug}`} className="absolute inset-0 overflow-hidden bg-ink-2" transition={{ duration: reduce ? 0 : 0.8, ease: EASE }}>
                <MuseumImage src={product.images[0].src} alt={product.images[0].alt} fill sizes="(min-width: 768px) 50vw, 100vw" priority />
              </motion.div>
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
              <p className="counter absolute bottom-5 left-5 text-paper/80">
                {String(index + 1).padStart(2, "0")} / {String(list.length).padStart(2, "0")}
              </p>
            </div>

            {/* Info side */}
            <div className="relative flex flex-col md:overflow-y-auto" data-lenis-prevent>
              <div className="sticky top-0 z-10 flex items-center justify-between border-b hairline bg-ink/90 px-6 py-4 backdrop-blur md:px-10">
                <div className="flex gap-1">
                  <button type="button" onClick={() => go(-1)} className="micro px-2 py-1 text-mute hover:text-paper" aria-label="Previous product">
                    ← Prev
                  </button>
                  <button type="button" onClick={() => go(1)} className="micro px-2 py-1 text-mute hover:text-paper" aria-label="Next product">
                    Next →
                  </button>
                </div>
                <button type="button" data-qv-close onClick={() => onChange(null)} className="micro inline-flex items-center gap-3">
                  Close
                  <span className="relative block h-3 w-3" aria-hidden="true">
                    <span className="absolute left-0 top-1/2 h-px w-full rotate-45 bg-current" />
                    <span className="absolute left-0 top-1/2 h-px w-full -rotate-45 bg-current" />
                  </span>
                </button>
              </div>

              <AnimatePresence mode="wait">
                <motion.div key={product.slug} className="px-6 pb-12 pt-8 md:px-10" exit={{ opacity: 0, transition: { duration: 0.15 } }}>
                  <motion.p custom={0} variants={item} initial="hidden" animate="show" className="micro mb-4 text-mute">
                    {product.category} · {ERA_BY_SLUG[product.era].title}
                  </motion.p>
                  <motion.h2 id="qv-title" custom={1} variants={item} initial="hidden" animate="show" className="display-sm">
                    {product.name}
                  </motion.h2>
                  <motion.p custom={2} variants={item} initial="hidden" animate="show" className="lead mt-5 text-paper/85">
                    {product.summary}
                  </motion.p>

                  <motion.dl custom={3} variants={item} initial="hidden" animate="show" className="mt-8 grid grid-cols-2 gap-x-6 gap-y-5 border-t hairline pt-6">
                    {[
                      ["Released", formatDate(product.releaseDate)],
                      ["Announced", product.announced ? formatDate(product.announced) : "—"],
                      ["Price at launch", product.priceAtLaunch],
                      ["Discontinued", product.discontinued ?? "Still available"],
                      ["Designed by", product.designers.join(", ")],
                      ["Era", ERA_BY_SLUG[product.era].range],
                    ].map(([label, value]) => (
                      <div key={label}>
                        <dt className="micro mb-1.5 text-mute">{label}</dt>
                        <dd className="text-sm">{value}</dd>
                      </div>
                    ))}
                  </motion.dl>

                  <motion.div custom={4} variants={item} initial="hidden" animate="show" className="mt-10">
                    <h3 className="micro mb-3 text-mute">Specifications</h3>
                    <dl>
                      {product.specs.map((s) => (
                        <div key={s.label} className="grid grid-cols-[8rem_1fr] gap-4 border-t hairline py-3 text-sm">
                          <dt className="text-mute">{s.label}</dt>
                          <dd>{s.value}</dd>
                        </div>
                      ))}
                    </dl>
                  </motion.div>

                  <motion.div custom={5} variants={item} initial="hidden" animate="show" className="mt-10 space-y-4">
                    <h3 className="micro text-mute">Why it mattered</h3>
                    {product.whyItMattered.map((para) => (
                      <p key={para} className="text-paper/80">
                        {para}
                      </p>
                    ))}
                  </motion.div>

                  <motion.div custom={6} variants={item} initial="hidden" animate="show" className="mt-10 flex flex-wrap items-center gap-6">
                    <Button href={`/collection/${product.slug}`} variant="solid">
                      Open full exhibit
                    </Button>
                    <Link href={product.source.url} target="_blank" rel="noopener noreferrer" className="micro text-mute hover:text-paper">
                      Source: {product.source.label} ↗
                    </Link>
                  </motion.div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
