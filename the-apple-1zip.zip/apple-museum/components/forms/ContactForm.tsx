"use client";

import { useId, useState, type FormEvent } from "react";
import { validateContact, type ContactInput, type FieldErrors } from "@/lib/validation";
import { Button } from "@/components/ui/Button";

type Status = "idle" | "sending" | "sent" | "error";

/** Contact form with inline validation, accessible error messages and a POST to /api/contact. */
export function ContactForm() {
  const id = useId();
  const [values, setValues] = useState<ContactInput>({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<FieldErrors<ContactInput>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof ContactInput, boolean>>>({});
  const [status, setStatus] = useState<Status>("idle");

  const update = (key: keyof ContactInput, value: string) => {
    const next = { ...values, [key]: value };
    setValues(next);
    if (touched[key]) setErrors(validateContact(next));
  };

  const blur = (key: keyof ContactInput) => {
    setTouched((t) => ({ ...t, [key]: true }));
    setErrors(validateContact(values));
  };

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const found = validateContact(values);
    setErrors(found);
    setTouched({ name: true, email: true, message: true });
    const firstInvalid = (Object.keys(found) as Array<keyof ContactInput>)[0];
    if (firstInvalid) {
      document.getElementById(`${id}-${firstInvalid}`)?.focus();
      return;
    }
    setStatus("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("sent");
      setValues({ name: "", email: "", message: "" });
      setTouched({});
    } catch {
      setStatus("error");
    }
  };

  if (status === "sent") {
    return (
      <div role="status" className="border-t hairline pt-10">
        <p className="display-sm">Thank you.</p>
        <p className="lead mt-4 text-mute">Your message is with the curators. We read everything and reply within a few days.</p>
        <button type="button" onClick={() => setStatus("idle")} className="micro mt-8 underline decoration-paper/40 underline-offset-8 hover:decoration-paper">
          Send another message
        </button>
      </div>
    );
  }

  const field = (key: keyof ContactInput, label: string, type: "text" | "email" | "textarea", autoComplete?: string) => {
    const err = touched[key] ? errors[key] : undefined;
    const common = {
      id: `${id}-${key}`,
      name: key,
      value: values[key],
      onChange: (e: { target: { value: string } }) => update(key, e.target.value),
      onBlur: () => blur(key),
      "aria-invalid": err ? true : undefined,
      "aria-describedby": err ? `${id}-${key}-error` : undefined,
      required: true,
      className: `w-full border-b bg-transparent py-3 text-lg text-paper placeholder:text-mute/60 focus:outline-none ${
        err ? "border-red-400/80 focus:border-red-300" : "border-line focus:border-paper"
      }`,
    };
    return (
      <div>
        <label htmlFor={`${id}-${key}`} className="micro mb-2 block text-mute">
          {label}
        </label>
        {type === "textarea" ? (
          <textarea {...common} rows={5} className={`${common.className} resize-y`} />
        ) : (
          <input {...common} type={type} autoComplete={autoComplete} />
        )}
        <p id={`${id}-${key}-error`} className="mt-2 min-h-5 text-sm text-red-300" aria-live="polite">
          {err ?? ""}
        </p>
      </div>
    );
  };

  return (
    <form noValidate onSubmit={submit} className="space-y-6" aria-labelledby={`${id}-title`}>
      <h3 id={`${id}-title`} className="sr-only">
        Contact the museum
      </h3>
      <div className="grid gap-6 md:grid-cols-2">
        {field("name", "Name", "text", "name")}
        {field("email", "Email", "email", "email")}
      </div>
      {field("message", "Message", "textarea")}
      {status === "error" && (
        <p role="alert" className="text-sm text-red-300">
          Something went wrong sending your message. Please try again.
        </p>
      )}
      <Button type="submit" variant="solid" disabled={status === "sending"}>
        {status === "sending" ? "Sending…" : "Send message"}
      </Button>
    </form>
  );
}
