"use client";

import { useId, useState, type FormEvent } from "react";
import { validateEmail } from "@/lib/validation";
import { Arrow } from "@/components/ui/Button";

type Status = "idle" | "sending" | "sent" | "error";

export function NewsletterForm() {
  const id = useId();
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | undefined>();
  const [status, setStatus] = useState<Status>("idle");

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validateEmail(email);
    setError(err);
    if (err) {
      document.getElementById(`${id}-email`)?.focus();
      return;
    }
    setStatus("sending");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("sent");
      setEmail("");
    } catch {
      setStatus("error");
    }
  };

  if (status === "sent") {
    return (
      <p role="status" className="lead text-paper">
        You&apos;re on the list. One letter a month, when a new exhibit opens.
      </p>
    );
  }

  return (
    <form noValidate onSubmit={submit}>
      <label htmlFor={`${id}-email`} className="micro mb-2 block text-mute">
        Email address
      </label>
      <div className={`flex items-center border-b ${error ? "border-red-400/80" : "border-line focus-within:border-paper"}`}>
        <input
          id={`${id}-email`}
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            if (error) setError(validateEmail(e.target.value));
          }}
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${id}-error` : undefined}
          placeholder="you@example.com"
          className="w-full bg-transparent py-3 text-lg text-paper placeholder:text-mute/60 focus:outline-none"
          required
        />
        <button type="submit" disabled={status === "sending"} className="micro group inline-flex shrink-0 items-center gap-3 py-3 pl-4 text-paper disabled:opacity-50">
          {status === "sending" ? "Joining…" : "Subscribe"}
          <Arrow className="transition-transform duration-500 group-hover:translate-x-1" />
        </button>
      </div>
      <p id={`${id}-error`} className="mt-2 min-h-5 text-sm text-red-300" aria-live="polite">
        {error ?? (status === "error" ? "Something went wrong. Please try again." : "")}
      </p>
    </form>
  );
}
