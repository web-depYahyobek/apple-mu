"use client";

const DIGITS = Array.from({ length: 10 }, (_, i) => i);

/**
 * Four rolling digit columns. Changing `year` rolls each column to its new digit,
 * so 1998 → 2001 visibly counts across the boundary.
 */
export function YearCounter({ year, className = "" }: { year: number; className?: string }) {
  const chars = String(year).padStart(4, "0").split("").map(Number);
  return (
    <div className={`flex leading-none tabular-nums ${className}`} aria-hidden="true">
      {chars.map((digit, col) => (
        <span key={col} className="relative inline-block h-[1em] overflow-hidden">
          <span
            className="flex flex-col transition-transform duration-[900ms] ease-[var(--ease-expo)] motion-reduce:transition-none"
            style={{ transform: `translateY(-${digit * 10}%)`, transitionDelay: `${col * 40}ms` }}
          >
            {DIGITS.map((d) => (
              <span key={d} className="block h-[1em]">
                {d}
              </span>
            ))}
          </span>
        </span>
      ))}
    </div>
  );
}
