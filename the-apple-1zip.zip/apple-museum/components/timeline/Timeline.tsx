"use client";

import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import { gsap, MQ, ScrollTrigger, useGSAP } from "@/lib/gsap";
import type { Product } from "@/data/types";
import { ERA_BY_SLUG } from "@/data/eras";
import { decadeOf, formatDate } from "@/lib/format";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { useSmoothScroll } from "@/components/layout/SmoothScroll";
import { YearCounter } from "./YearCounter";

type Group = { year: number; items: Product[] };

/**
 * Year-by-year timeline.
 * Left (desktop): a giant year that rolls to the year currently in view.
 * Right: product cards for each year. Non-active years dim; each year fades in.
 * Top: sticky decade filter.
 */
export function Timeline({ groups }: { groups: Group[] }) {
  const root = useRef<HTMLDivElement>(null);
  const list = useRef<HTMLOListElement>(null);
  const { scrollTo } = useSmoothScroll();
  const [decade, setDecade] = useState<number | "All">("All");
  const [current, setCurrent] = useState(groups[0]?.year ?? 1976);

  const decades = useMemo(() => [...new Set(groups.map((g) => decadeOf(g.year)))], [groups]);
  const visible = useMemo(() => (decade === "All" ? groups : groups.filter((g) => decadeOf(g.year) === decade)), [groups, decade]);
  const currentGroup = visible.find((g) => g.year === current) ?? visible[0];
  const total = visible.reduce((n, g) => n + g.items.length, 0);

  useGSAP(
    () => {
      const items = gsap.utils.toArray<HTMLElement>("[data-year-group]", list.current);
      const triggers = items.map((el) =>
        ScrollTrigger.create({
          trigger: el,
          start: "top 55%",
          end: "bottom 55%",
          onToggle: (self) => {
            if (self.isActive) setCurrent(Number(el.dataset.yearGroup));
          },
        }),
      );
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        items.forEach((el) => {
          gsap.from(el.querySelectorAll("[data-card]"), {
            opacity: 0,
            y: 40,
            duration: 1,
            stagger: 0.08,
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 85%", once: true },
          });
        });
      });
      ScrollTrigger.refresh();
      return () => {
        triggers.forEach((t) => t.kill());
        mm.revert();
      };
    },
    { scope: root, dependencies: [decade], revertOnUpdate: true },
  );

  const choose = (d: number | "All") => {
    setDecade(d);
    const first = d === "All" ? groups[0] : groups.find((g) => decadeOf(g.year) === d);
    if (first) setCurrent(first.year);
    if (list.current) scrollTo(list.current, { offset: -180 });
  };

  const chip = (active: boolean) =>
    `micro whitespace-nowrap px-3 py-2 transition-colors duration-300 md:px-4 ${
      active ? "bg-paper text-ink" : "text-paper/70 hover:text-paper"
    }`;

  return (
    <div ref={root}>
      {/* Sticky decade filter */}
      <div className="sticky top-[var(--header-h)] z-20 border-y hairline bg-ink/90 backdrop-blur-md">
        <div className="container-museum flex items-center justify-between gap-6 py-3">
          <div className="-mx-2 flex overflow-x-auto [scrollbar-width:none]" role="group" aria-label="Filter by decade">
            <button type="button" aria-pressed={decade === "All"} className={chip(decade === "All")} onClick={() => choose("All")}>
              All
            </button>
            {decades.map((d) => (
              <button key={d} type="button" aria-pressed={decade === d} className={chip(decade === d)} onClick={() => choose(d)}>
                {d}s
              </button>
            ))}
          </div>
          <p className="counter hidden shrink-0 text-mute md:block" aria-live="polite">
            {total} releases
          </p>
        </div>
      </div>

      <div className="container-museum grid gap-10 lg:grid-cols-12">
        {/* Sticky year */}
        <aside className="hidden lg:col-span-5 lg:block">
          <div className="sticky top-[calc(var(--header-h)+3.5rem)] flex h-[calc(100vh-var(--header-h)-3.5rem)] flex-col justify-center">
            <p className="micro mb-6 text-mute">{currentGroup ? ERA_BY_SLUG[currentGroup.items[0].era].title : ""}</p>
            <YearCounter year={currentGroup?.year ?? current} className="text-[clamp(6rem,12vw,13rem)] font-medium tracking-[-0.06em]" />
            <p className="sr-only" aria-live="polite">
              Now showing {currentGroup?.year}
            </p>
            <p className="counter mt-8 text-mute">
              {currentGroup?.items.length} {currentGroup?.items.length === 1 ? "release" : "releases"}
            </p>
          </div>
        </aside>

        {/* Years */}
        <ol ref={list} className="lg:col-span-7">
          {visible.map((group) => {
            const active = group.year === current;
            return (
              <li
                key={group.year}
                data-year-group={group.year}
                className={`border-t hairline py-14 transition-opacity duration-700 md:py-20 ${active ? "lg:opacity-100" : "lg:opacity-50"}`}
                aria-labelledby={`year-${group.year}`}
              >
                <h2 id={`year-${group.year}`} className="mb-10 flex items-baseline justify-between">
                  <span className="text-[clamp(3.5rem,14vw,5rem)] font-medium leading-none tracking-[-0.05em] lg:sr-only">{group.year}</span>
                  <span className="micro hidden text-mute lg:inline">{group.year}</span>
                  <span className="counter text-mute">
                    {group.items.length} {group.items.length === 1 ? "release" : "releases"}
                  </span>
                </h2>
                <div className="space-y-12">
                  {group.items.map((p) => (
                    <article key={p.slug} data-card className="grid gap-6 sm:grid-cols-[9rem_1fr] md:gap-8">
                      <Link href={`/collection/${p.slug}`} data-cursor="view" className="group relative block aspect-[4/5] w-36 overflow-hidden bg-ink-2" tabIndex={-1} aria-hidden="true">
                        <MuseumImage src={p.images[0].src} alt="" fill sizes="144px" className="transition-transform duration-1000 group-hover:scale-105" />
                      </Link>
                      <div>
                        <p className="micro mb-3 text-mute">
                          {p.category} · {formatDate(p.releaseDate)}
                        </p>
                        <h3 className="text-2xl font-medium tracking-[-0.03em] md:text-3xl">
                          <Link href={`/collection/${p.slug}`} className="hover:underline hover:decoration-paper/40 hover:underline-offset-8">
                            {p.name}
                          </Link>
                        </h3>
                        <p className="mt-3 max-w-xl text-mute">{p.summary}</p>
                        <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t hairline pt-5 text-sm md:grid-cols-3">
                          <div>
                            <dt className="micro mb-1 text-mute">Launch price</dt>
                            <dd>{p.priceAtLaunch}</dd>
                          </div>
                          {p.specs.slice(0, 2).map((s) => (
                            <div key={s.label}>
                              <dt className="micro mb-1 text-mute">{s.label}</dt>
                              <dd>{s.value}</dd>
                            </div>
                          ))}
                        </dl>
                      </div>
                    </article>
                  ))}
                </div>
              </li>
            );
          })}
        </ol>
      </div>
    </div>
  );
}
