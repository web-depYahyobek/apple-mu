"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { EXHIBITS } from "@/data/home";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { RevealImage } from "@/components/ui/RevealImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { Button } from "@/components/ui/Button";

const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Editorial statement + a tall list of eight exhibits.
 * A sticky image on the left swaps (crossfade + slight zoom) as each item crosses the viewport centre.
 */
export function StickyImageList() {
  const root = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);

  useGSAP(
    () => {
      const items = gsap.utils.toArray<HTMLElement>("[data-exhibit]", root.current);
      const triggers = items.map((item, i) =>
        ScrollTrigger.create({
          trigger: item,
          start: "top center",
          end: "bottom center",
          onToggle: (self) => self.isActive && setActive(i),
        }),
      );
      return () => triggers.forEach((t) => t.kill());
    },
    { scope: root },
  );

  return (
    <section ref={root} className="relative border-t hairline" aria-labelledby="statement-title">
      {/* Statement */}
      <div className="container-museum py-24 md:py-40">
        <p className="micro mb-10 text-mute">The exhibits</p>
        <SplitHeadline id="statement-title" className="display-sm max-w-[22ch] text-balance">
          A product should say something before it&apos;s switched on. Every line, material and finish is considered.
        </SplitHeadline>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Sticky swapping image (desktop) */}
        <div className="hidden lg:block">
          <div className="sticky top-0 h-screen p-[var(--header-h)] pr-8">
            <div className="relative h-full w-full overflow-hidden bg-ink-2">
              {EXHIBITS.map((ex, i) => (
                <div
                  key={ex.slug}
                  className={`absolute inset-0 transition-[opacity,transform] duration-[1200ms] ease-[var(--ease-expo)] motion-reduce:transition-opacity motion-reduce:duration-300 ${
                    i === active ? "scale-100 opacity-100" : "scale-110 opacity-0"
                  }`}
                  aria-hidden={i !== active}
                >
                  <MuseumImage src={ex.image.src} alt={ex.image.alt} fill sizes="50vw" />
                </div>
              ))}
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                <p className="micro text-paper/85">{EXHIBITS[active].title}</p>
                <p className="counter text-paper/85">
                  {pad(active + 1)} / {pad(EXHIBITS.length)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* List */}
        <ol className="container-museum lg:pl-12 lg:pr-[clamp(1.25rem,4vw,3.5rem)]">
          {EXHIBITS.map((ex, i) => (
            <li
              key={ex.slug}
              data-exhibit
              className={`flex min-h-[auto] flex-col justify-center border-t hairline py-14 transition-opacity duration-700 lg:min-h-[78vh] lg:py-0 ${
                i === active ? "lg:opacity-100" : "lg:opacity-35"
              }`}
            >
              <RevealImage image={ex.image} className="mb-8 aspect-[4/3] lg:hidden" sizes="100vw" />
              <div className="mb-6 flex items-center gap-4">
                <span className="micro text-mute">Exhibit</span>
                <span className="counter text-mute">{pad(i + 1)}</span>
              </div>
              <h3 className="display-md mb-6">{ex.title}</h3>
              <p className="lead max-w-md text-mute">{ex.description}</p>
              <div className="mt-8">
                <Button href={ex.href} variant="text">
                  Explore
                </Button>
              </div>
            </li>
          ))}
        </ol>
      </div>
      <div className="container-museum py-16 text-right">
        <Link href="/collection" className="micro text-mute hover:text-paper">
          Browse every product in the collection →
        </Link>
      </div>
    </section>
  );
}
