import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { Button } from "@/components/ui/Button";
import { Magnetic } from "@/components/ui/Magnetic";
import { FadeIn } from "@/components/ui/FadeIn";

export function ClosingCta() {
  return (
    <section aria-labelledby="cta-title" className="relative overflow-hidden py-32 md:py-48">
      <div className="era-glow absolute inset-0 opacity-70" aria-hidden="true" />
      <div className="container-museum relative text-center">
        <p className="lead mb-6 text-mute">Are you ready to</p>
        <SplitHeadline as="h2" id="cta-title" by="words" className="display mx-auto max-w-[12ch]">
          Think Different
        </SplitHeadline>
        <FadeIn className="mt-14 flex justify-center">
<Magnetic>          <Button href="/visit" variant="solid">
            Plan Your Visit
          </Button></Magnetic>
        </FadeIn>
      </div>
    </section>
  );
}
