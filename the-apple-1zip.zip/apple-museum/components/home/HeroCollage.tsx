"use client";

import Link from "next/link";
import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { onReady } from "@/lib/ready";
import { HERO_COLLAGE } from "@/data/home";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";

/** Scattered layout: left %, top %, resting rotation, parallax depth. */
const LAYOUT = [
  { x: 2, y: 4, r: -4, d: 0.6 },
  { x: 21, y: 0, r: 3, d: 1.1 },
  { x: 40, y: 7, r: -2, d: 0.8 },
  { x: 60, y: 1, r: 4, d: 1.3 },
  { x: 80, y: 5, r: -3, d: 0.7 },
  { x: 87, y: 50, r: 2, d: 1.0 },
  { x: 68, y: 46, r: -5, d: 1.2 },
  { x: 11, y: 48, r: 5, d: 0.9 },
  { x: 30, y: 52, r: -3, d: 1.4 },
  { x: 49, y: 44, r: 2, d: 0.75 },
];

export function HeroCollage() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const el = root.current;
      if (!el) return;
      const cards = gsap.utils.toArray<HTMLElement>("[data-card]", el);
      const floats = gsap.utils.toArray<HTMLElement>("[data-float]", el);
      const mm = gsap.matchMedia();

      mm.add(MQ.motion, () => {
        // Entrance: fly in from outside the frame, roughly away from the centre.
        // (fromTo renders its "from" state immediately, so cards stay hidden until play.)
        const intro = gsap.timeline({ paused: true });
        cards.forEach((card, i) => {
          const l = LAYOUT[i];
          const fromX = (l.x - 45) * 14 + (i % 2 ? 120 : -120);
          const fromY = (l.y - 30) * 12 + (i % 3 === 0 ? 260 : -220);
          intro.fromTo(
            card,
            { x: fromX, y: fromY, rotation: l.r * 5, scale: 0.7, opacity: 0 },
            { x: 0, y: 0, rotation: l.r, scale: 1, opacity: 1, duration: 1.6, ease: "expo.out" },
            0.08 * i,
          );
        });
        intro.from("[data-hero-meta]", { opacity: 0, y: 16, duration: 1, stagger: 0.1 }, 0.6);
        const unsubscribe = onReady(() => intro.play());

        // Scroll: the collage drifts up at different speeds as the hero leaves.
        floats.forEach((f, i) => {
          gsap.to(f, {
            yPercent: -40 * LAYOUT[i].d,
            ease: "none",
            scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
          });
        });

        return () => unsubscribe();
      });

      // Mouse parallax (fine pointers only).
      mm.add(`${MQ.motion} and (pointer: fine)`, () => {
        const movers = floats.map((f, i) => ({
          x: gsap.quickTo(f, "x", { duration: 1.2, ease: "power3.out" }),
          y: gsap.quickTo(f, "y", { duration: 1.2, ease: "power3.out" }),
          d: LAYOUT[i].d,
        }));
        const onMove = (e: PointerEvent) => {
          const nx = e.clientX / window.innerWidth - 0.5;
          const ny = e.clientY / window.innerHeight - 0.5;
          movers.forEach((m) => {
            m.x(nx * 40 * m.d);
            m.y(ny * 30 * m.d);
          });
        };
        window.addEventListener("pointermove", onMove, { passive: true });
        return () => window.removeEventListener("pointermove", onMove);
      });

      mm.add(MQ.reduced, () => {
        gsap.set(cards, { rotation: (i: number) => LAYOUT[i].r });
      });

      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section ref={root} className="relative h-[100svh] min-h-[640px] overflow-hidden" aria-labelledby="hero-title">
      <div className="era-glow absolute inset-0" aria-hidden="true" />

      {/* Collage */}
      <div className="absolute inset-x-0 top-[calc(var(--header-h)+1rem)] bottom-[30%] md:bottom-[18%]">
        <ul className="relative h-full w-full" aria-label="Ten iconic Apple products">
          {HERO_COLLAGE.map((item, i) => {
            const l = LAYOUT[i];
            return (
              <li
                key={item.slug}
                data-float
                className={`absolute will-change-transform ${i > 6 ? "hidden sm:block" : ""}`}
                style={{ left: `${l.x}%`, top: `${l.y}%` }}
              >
                <Link href={`/collection/${item.slug}`} data-cursor="view" className="group block" aria-label={`${item.name}, ${item.year}`}>
                <figure
                  data-card
                  className="relative aspect-[4/5] w-[clamp(72px,11.5vw,216px)] overflow-hidden bg-ink-2 shadow-[0_30px_60px_-20px_rgba(0,0,0,0.8)] transition-[box-shadow] duration-500 group-hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.95)]"
                  style={{ transform: `rotate(${l.r}deg)` }}
                >
                  <MuseumImage
                    src={`/images/products/${item.slug}/hero.jpg`}
                    alt={`${item.name}, ${item.year}`}
                    fill
                    sizes="(min-width: 1024px) 216px, 25vw"
                    priority={i < 5}
                    className="transition-transform duration-[1200ms] ease-[var(--ease-expo)] group-hover:scale-110"
                  />
                  <figcaption className="absolute inset-x-0 bottom-0 hidden justify-between sm:flex bg-gradient-to-t from-ink/80 to-transparent px-2 pb-1.5 pt-6 text-[9px] uppercase tracking-[0.16em] text-paper/80 md:text-[10px]">
                    <span>{item.name}</span>
                    <span>{item.year}</span>
                  </figcaption>
                </figure>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Copy */}
      <div className="absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-ink via-ink/60 to-transparent pt-32">
        <div className="container-museum pb-10 md:pb-14">
        <p data-hero-meta className="micro mb-6 text-mute">
          We don&apos;t collect devices. We preserve ideas.
        </p>
        <SplitHeadline as="h1" id="hero-title" trigger="ready" delay={0.35} className="display max-w-[13ch]">
          For Those Who Think Different
        </SplitHeadline>
        <div className="mt-8 flex flex-col gap-6 border-t hairline pt-6 md:flex-row md:items-end md:justify-between">
          <p data-hero-meta className="lead max-w-md text-paper/80">
            A museum of everything Apple has ever made. 1976 to today.
          </p>
          <div data-hero-meta className="flex items-center gap-4" aria-hidden="true">
            <span className="micro text-mute">Scroll</span>
            <span className="relative block h-10 w-px overflow-hidden bg-line">
              <span className="absolute inset-0 animate-scroll-hint bg-paper motion-reduce:animate-none" />
            </span>
          </div>
        </div>
        </div>
      </div>
    </section>
  );
}
