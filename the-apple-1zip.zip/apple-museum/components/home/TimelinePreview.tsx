"use client";

import Link from "next/link";
import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { DECADE_CARDS, PAGE_IMAGES } from "@/data/home";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { Button } from "@/components/ui/Button";
import { Magnetic } from "@/components/ui/Magnetic";
import { FadeIn } from "@/components/ui/FadeIn";

/**
 * Full-height image intro, then a strip of decade cards.
 * Desktop + motion: the strip pins and scrolls horizontally with the page.
 * Mobile / reduced motion: a native swipe carousel with scroll-snap.
 */
export function TimelinePreview() {
  const root = useRef<HTMLElement>(null);
  const strip = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const heroImg = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        gsap.fromTo(
          heroImg.current,
          { yPercent: -10, scale: 1.1 },
          { yPercent: 10, scale: 1, ease: "none", scrollTrigger: { trigger: heroImg.current, start: "top bottom", end: "bottom top", scrub: true } },
        );
      });
      mm.add(MQ.desktopMotion, () => {
        const distance = () => (track.current ? track.current.scrollWidth - window.innerWidth : 0);
        gsap.to(track.current, {
          x: () => -distance(),
          ease: "none",
          scrollTrigger: {
            trigger: strip.current,
            start: "top top",
            end: () => `+=${distance()}`,
            pin: true,
            scrub: 0.6,
            invalidateOnRefresh: true,
          },
        });
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section ref={root} aria-labelledby="timeline-title" className="relative">
      {/* Full-height intro */}
      <div className="relative flex h-[100svh] min-h-[600px] items-end overflow-hidden">
        <div ref={heroImg} className="absolute inset-0 will-change-transform">
          <MuseumImage src={PAGE_IMAGES.timeline.src} alt={PAGE_IMAGES.timeline.alt} fill sizes="100vw" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" aria-hidden="true" />
        <div className="container-museum relative pb-14 md:pb-20">
          <p className="micro mb-6 text-paper/70">The Timeline</p>
          <SplitHeadline id="timeline-title" className="display max-w-[10ch]">
            1976 to Today
          </SplitHeadline>
          <FadeIn className="mt-8 flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
            <p className="lead max-w-lg text-paper/85">
              Fifty years, one year at a time. Every release, with the date it shipped, the price it asked and the story
              behind it.
            </p>
            <Magnetic><Button href="/timeline">Explore the Timeline</Button></Magnetic>
          </FadeIn>
        </div>
      </div>

      {/* Decade strip */}
      <div ref={strip} className="relative overflow-hidden py-20 lg:motion-safe:flex lg:motion-safe:h-screen lg:motion-safe:items-center lg:motion-safe:py-0">
        <div
          ref={track}
          className="flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-6 [scrollbar-width:none] md:gap-6 md:px-10 lg:motion-safe:snap-none lg:motion-safe:overflow-visible lg:motion-safe:pb-0 lg:motion-safe:pl-[8vw] lg:motion-safe:pr-[8vw]"
          role="list"
          aria-label="Decades"
          tabIndex={0}
        >
          <div role="listitem" className="flex w-[78vw] shrink-0 snap-start flex-col justify-end md:w-[40vw] lg:w-[28vw]">
            <p className="micro mb-4 text-mute">Six decades</p>
            <p className="display-sm max-w-[10ch]">Swipe through the archive.</p>
          </div>
          {DECADE_CARDS.map((card, i) => (
            <div role="listitem" key={card.decade} className="w-[78vw] shrink-0 snap-start md:w-[42vw] lg:w-[30vw]">
            <Link
              href={`/collection/${card.slug}`}
              data-cursor="view"
              className="group relative flex h-full flex-col justify-between border hairline bg-ink-2"
            >
              <div className="flex items-center justify-between p-6">
                <span className="micro text-mute">{card.decade}</span>
                <span className="counter text-mute">
                  {String(i + 1).padStart(2, "0")} / {String(DECADE_CARDS.length).padStart(2, "0")}
                </span>
              </div>
              <div className="relative mx-6 aspect-[4/3] overflow-hidden">
                <MuseumImage
                  src={`/images/products/${card.slug}/hero.jpg`}
                  alt={`${card.product}, ${card.year}`}
                  fill
                  sizes="(min-width: 1024px) 30vw, 78vw"
                  className="transition-transform duration-[1200ms] ease-[var(--ease-expo)] group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <p className="text-[clamp(3rem,6vw,5.5rem)] font-medium leading-none tracking-[-0.05em]">{card.year}</p>
                <p className="mt-4 text-lg font-medium">{card.product}</p>
                <p className="mt-2 text-sm text-mute">{card.fact}</p>
              </div>
            </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
