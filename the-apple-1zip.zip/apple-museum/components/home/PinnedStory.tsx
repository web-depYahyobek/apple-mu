"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { STORY_STEPS } from "@/data/home";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { RevealImage } from "@/components/ui/RevealImage";
import { Button } from "@/components/ui/Button";
import { FadeIn } from "@/components/ui/FadeIn";

const TOTAL = STORY_STEPS.length;
const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Three-step pinned story. On large screens with motion allowed the section pins
 * and scroll crossfades image + text with a clip/scale transition.
 * Otherwise the same content renders as a simple vertical list.
 */
export function PinnedStory() {
  const root = useRef<HTMLElement>(null);
  const pinned = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.desktopMotion, () => {
        const images = gsap.utils.toArray<HTMLElement>("[data-story-image]", pinned.current);
        const inners = gsap.utils.toArray<HTMLElement>("[data-story-inner]", pinned.current);
        const texts = gsap.utils.toArray<HTMLElement>("[data-story-text]", pinned.current);

        gsap.set(images.slice(1), { clipPath: "inset(100% 0% 0% 0%)" });
        gsap.set(inners.slice(1), { scale: 1.25 });
        gsap.set(texts.slice(1), { autoAlpha: 0, y: 60 });

        const tl = gsap.timeline({
          defaults: { ease: "power2.inOut" },
          scrollTrigger: {
            trigger: pinned.current,
            start: "top top",
            end: `+=${TOTAL * 100}%`,
            pin: true,
            scrub: 0.8,
            anticipatePin: 1,
            onUpdate: (self) => {
              const i = Math.min(TOTAL - 1, Math.floor(self.progress * TOTAL * 0.999 + 0.0001));
              setActive((prev) => (prev === i ? prev : i));
            },
          },
        });

        for (let i = 1; i < TOTAL; i++) {
          const at = i - 0.5;
          tl.to(texts[i - 1], { autoAlpha: 0, y: -60, duration: 0.35 }, at)
            .to(inners[i - 1], { scale: 1.1, duration: 0.6 }, at)
            .to(images[i], { clipPath: "inset(0% 0% 0% 0%)", duration: 0.6 }, at)
            .to(inners[i], { scale: 1, duration: 0.8 }, at)
            .to(texts[i], { autoAlpha: 1, y: 0, duration: 0.4 }, at + 0.3);
        }
        tl.to({}, { duration: 0.5 }); // hold the last step
        tl.fromTo("[data-story-progress]", { scaleX: 1 / TOTAL }, { scaleX: 1, ease: "none", duration: tl.duration() }, 0);
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section ref={root} aria-labelledby="story-title" className="relative">
      <h2 id="story-title" className="sr-only">
        From the garage to spatial computing, in three steps
      </h2>

      {/* Pinned version */}
      <div ref={pinned} className="relative hidden h-screen overflow-hidden lg:motion-safe:block">
        <div className="grid h-full grid-cols-12">
          <div className="relative col-span-7 h-full overflow-hidden">
            {STORY_STEPS.map((step, i) => (
              <div key={step.label} data-story-image className="absolute inset-0 overflow-hidden" style={{ zIndex: i + 1 }}>
                <div data-story-inner className="absolute inset-0 will-change-transform">
                  <MuseumImage src={step.image.src} alt={step.image.alt} fill sizes="60vw" />
                </div>
              </div>
            ))}
            <div className="pointer-events-none absolute inset-0 z-10 bg-gradient-to-r from-transparent via-transparent to-ink/60" />
          </div>

          <div className="relative col-span-5 flex h-full flex-col justify-between px-12 pb-14 pt-[calc(var(--header-h)+2rem)] xl:px-16">
            <div className="flex items-center justify-between">
              <p className="micro text-mute">The story</p>
              <p className="counter text-paper" aria-live="polite">
                {pad(active + 1)} / {pad(TOTAL)}
              </p>
            </div>

            <div className="relative h-[52vh]">
              {STORY_STEPS.map((step) => (
                <article key={step.label} data-story-text className="absolute inset-x-0 bottom-0">
                  <p className="micro mb-6 text-mute">
                    {step.label} — {step.range}
                  </p>
                  <h3 className="display-md mb-8">{step.title}</h3>
                  <p className="lead max-w-md text-paper/85">{step.body}</p>
                  <p className="mt-6 text-sm text-mute">{step.products}</p>
                  <div className="mt-10">
                    <Button href={`/eras#${step.era}`} variant="text">
                      Explore this era
                    </Button>
                  </div>
                </article>
              ))}
            </div>

            <div className="h-px w-full bg-line">
              <div data-story-progress className="h-px origin-left bg-paper" style={{ transform: `scaleX(${1 / TOTAL})` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Stacked version: mobile, tablet and reduced motion */}
      <div className="container-museum space-y-24 py-24 lg:motion-safe:hidden">
        {STORY_STEPS.map((step, i) => (
          <article key={step.label} className="grid gap-8 md:grid-cols-2 md:items-end md:gap-12">
            <RevealImage image={step.image} className="aspect-[4/5]" sizes="(min-width: 768px) 50vw, 100vw" />
            <FadeIn stagger>
              <p className="counter mb-6 text-mute">
                {pad(i + 1)} / {pad(TOTAL)} — {step.range}
              </p>
              <h3 className="display-md mb-6">{step.title}</h3>
              <p className="lead text-paper/85">{step.body}</p>
              <p className="mt-5 text-sm text-mute">{step.products}</p>
              <div className="mt-8">
                <Link href={`/eras#${step.era}`} className="micro underline decoration-paper/30 underline-offset-8 hover:decoration-paper">
                  Explore this era
                </Link>
              </div>
            </FadeIn>
          </article>
        ))}
      </div>
    </section>
  );
}
