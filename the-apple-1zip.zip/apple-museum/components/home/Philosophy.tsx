"use client";

import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { MARQUEE_ROWS, PAGE_IMAGES } from "@/data/home";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { Marquee } from "@/components/ui/Marquee";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { Button } from "@/components/ui/Button";
import { Magnetic } from "@/components/ui/Magnetic";
import { FadeIn } from "@/components/ui/FadeIn";

/** "Our Approach To Every Exhibit": sticky image that scales with scroll, marquee of product lines. */
export function Philosophy() {
  const root = useRef<HTMLElement>(null);
  const frame = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.desktopMotion, () => {
        gsap.fromTo(
          frame.current,
          { clipPath: "inset(14% 18% 14% 18%)" },
          {
            clipPath: "inset(0% 0% 0% 0%)",
            ease: "none",
            scrollTrigger: { trigger: root.current, start: "top 80%", end: "center center", scrub: true },
          },
        );
        gsap.fromTo(
          img.current,
          { scale: 1.3 },
          {
            scale: 1,
            ease: "none",
            scrollTrigger: { trigger: root.current, start: "top bottom", end: "bottom top", scrub: true },
          },
        );
      });
      mm.add(`(max-width: 1023px) and ${MQ.motion}`, () => {
        gsap.fromTo(
          img.current,
          { scale: 1.15 },
          { scale: 1, ease: "none", scrollTrigger: { trigger: frame.current, start: "top bottom", end: "bottom top", scrub: true } },
        );
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section ref={root} className="relative py-24 md:py-0" aria-labelledby="approach-title">
      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Sticky image */}
        <div className="px-5 md:px-10 lg:px-0">
          <div className="lg:sticky lg:top-0 lg:h-screen lg:py-[var(--header-h)]">
            <div ref={frame} className="relative aspect-[4/5] overflow-hidden bg-ink-2 lg:aspect-auto lg:h-full">
              <div ref={img} className="absolute inset-0 will-change-transform">
                <MuseumImage src={PAGE_IMAGES.philosophy.src} alt={PAGE_IMAGES.philosophy.alt} fill sizes="(min-width: 1024px) 50vw, 100vw" />
              </div>
              <p className="micro absolute bottom-5 left-5 text-paper/80">Fig. 01 — Material</p>
            </div>
          </div>
        </div>

        {/* Copy column */}
        <div className="flex flex-col justify-between gap-24 pt-20 lg:min-h-[170vh] lg:pb-40 lg:pt-[calc(var(--header-h)+4rem)]">
          <div className="container-museum lg:pl-16">
            <p className="micro mb-8 text-mute">Our approach</p>
            <SplitHeadline id="approach-title" className="display-md max-w-[11ch]">
              Our Approach To Every Exhibit
            </SplitHeadline>
          </div>

          <div className="space-y-4 py-6" aria-label="Product lines in the collection">
            <Marquee items={MARQUEE_ROWS[0]} />
            <Marquee items={MARQUEE_ROWS[1]} reverse />
          </div>

          <FadeIn className="container-museum max-w-xl lg:pl-16" stagger>
            <p className="lead text-paper/85">Every product marks a decision. Every detail has a purpose.</p>
            <p className="mt-5 text-mute">
              We document what shipped, what failed and what changed everything. Each exhibit records the date, the
              price, the people behind it and the reason it still matters.
            </p>
            <div className="mt-10">
              <Magnetic><Button href="/collection">Enter the Collection</Button></Magnetic>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
