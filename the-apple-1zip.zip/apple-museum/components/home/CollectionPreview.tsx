"use client";

import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { PAGE_IMAGES } from "@/data/home";
import { PRODUCTS } from "@/data/products";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { Button } from "@/components/ui/Button";
import { Magnetic } from "@/components/ui/Magnetic";
import { FadeIn } from "@/components/ui/FadeIn";

export function CollectionPreview() {
  const root = useRef<HTMLElement>(null);
  const img = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        gsap.fromTo(
          img.current,
          { clipPath: "inset(10% 10% 10% 10%)", scale: 1.15 },
          {
            clipPath: "inset(0% 0% 0% 0%)",
            scale: 1,
            ease: "none",
            scrollTrigger: { trigger: root.current, start: "top bottom", end: "top top", scrub: true },
          },
        );
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section ref={root} aria-labelledby="collection-title" className="relative flex h-[100svh] min-h-[600px] items-end overflow-hidden">
      <div ref={img} className="absolute inset-0 will-change-transform">
        <MuseumImage src={PAGE_IMAGES.collection.src} alt={PAGE_IMAGES.collection.alt} fill sizes="100vw" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-ink/40" aria-hidden="true" />
      <div className="container-museum relative pb-14 md:pb-20">
        <div className="mb-6 flex items-center gap-6">
          <p className="micro text-paper/70">The Collection</p>
          <p className="counter text-paper/70">{PRODUCTS.length} objects</p>
        </div>
        <SplitHeadline id="collection-title" className="display max-w-[12ch]">
          Every Product. One Archive.
        </SplitHeadline>
        <FadeIn className="mt-10 flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <p className="lead max-w-lg text-paper/85">
            Search and filter the whole collection by category, decade or name, from the Apple I to this month&apos;s
            releases.
          </p>
          <Magnetic><Button href="/collection">Browse the Collection</Button></Magnetic>
        </FadeIn>
      </div>
    </section>
  );
}
