"use client";

import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import { ORDINARY_COLUMNS } from "@/data/home";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { RevealImage } from "@/components/ui/RevealImage";

/** Parallax speeds for the three columns (0.8x / 1.0x / 1.2x). */
const SPEEDS = [0.8, 1, 1.2];

/**
 * "Ordinary" is struck through, blurred and faded while three tall portraits rise
 * past it at different speeds. Then "ends here." arrives.
 */
export function OrdinaryEnds() {
  const root = useRef<HTMLElement>(null);
  const stage = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.desktopMotion, () => {
        const cols = gsap.utils.toArray<HTMLElement>("[data-col]", stage.current);
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: { trigger: stage.current, start: "top top", end: "+=220%", pin: true, scrub: 0.6 },
        });

        cols.forEach((col, i) => {
          tl.fromTo(col, { yPercent: 60 * SPEEDS[i] + 40 }, { yPercent: -120 * SPEEDS[i] - 20, duration: 1 }, 0);
        });
        tl.fromTo("[data-strike]", { scaleX: 0 }, { scaleX: 1, duration: 0.3 }, 0.1)
          .to("[data-word]", { filter: "blur(14px)", opacity: 0.12, duration: 0.35 }, 0.35)
          .fromTo("[data-ends]", { yPercent: 100, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.25, ease: "power3.out" }, 0.62)
          .fromTo("[data-ends-sub]", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.2 }, 0.74);
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  return (
    <section ref={root} aria-labelledby="ordinary-title" className="relative border-t hairline">
      {/* Pinned, animated version */}
      <div ref={stage} className="relative hidden h-screen overflow-hidden lg:motion-safe:block">
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <h2 id="ordinary-title" className="relative">
            <span data-word className="relative inline-block text-[clamp(5rem,16vw,15rem)] font-medium italic leading-none tracking-[-0.05em]">
              Ordinary
              <span data-strike aria-hidden="true" className="absolute left-[-2%] top-[55%] block h-[0.05em] w-[104%] origin-left bg-paper" />
            </span>
            <span className="block overflow-hidden">
              <span data-ends className="display-md block pt-4">
                ends here.
              </span>
            </span>
          </h2>
          <p data-ends-sub className="lead mt-8 max-w-md px-6 text-mute">
            Objects shaped by restraint, refined until there was nothing left to take away.
          </p>
        </div>

        <div className="pointer-events-none absolute inset-0 grid grid-cols-3 gap-[6vw] px-[8vw]" aria-hidden="true">
          {ORDINARY_COLUMNS.map((img, i) => (
            <div key={img.src} data-col className={`relative ${i === 1 ? "mt-[18vh]" : ""}`}>
              <div className="relative aspect-[3/5] w-full overflow-hidden bg-ink-2 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.9)]">
                <MuseumImage src={img.src} alt="" fill sizes="25vw" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Static version */}
      <div className="container-museum py-24 text-center lg:motion-safe:hidden">
        <p className="text-[clamp(4rem,18vw,9rem)] font-medium italic leading-none tracking-[-0.05em] text-paper/30 line-through decoration-paper decoration-[0.04em]">
          Ordinary
        </p>
        <p className="display-md mt-4">ends here.</p>
        <p className="lead mx-auto mt-6 max-w-md text-mute">
          Objects shaped by restraint, refined until there was nothing left to take away.
        </p>
        <div className="mt-14 grid grid-cols-3 gap-3 md:gap-6">
          {ORDINARY_COLUMNS.map((img, i) => (
            <RevealImage key={img.src} image={img} className={`aspect-[3/5] ${i === 1 ? "translate-y-8" : ""}`} sizes="33vw" />
          ))}
        </div>
      </div>
    </section>
  );
}
