"use client";

import { useState } from "react";
import type { ProductImage } from "@/data/types";
import type { ImageCredit } from "@/lib/credits";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { FadeIn } from "@/components/ui/FadeIn";
import { Lightbox } from "./Lightbox";

const LAYOUT = ["md:col-span-7 aspect-[4/3]", "md:col-span-5 aspect-[4/5]", "md:col-span-5 aspect-[4/5]", "md:col-span-7 aspect-[4/3]", "md:col-span-6 aspect-square", "md:col-span-6 aspect-square"];

function layoutFor(i: number, n: number) {
  if (n === 1) return "aspect-[16/9] md:col-span-12";
  if (n === 2) return "aspect-[4/5] md:col-span-6";
  if (n === 3 && i === 2) return "aspect-[21/9] md:col-span-12";
  if (n === 5 && i === 4) return "aspect-[21/9] md:col-span-12";
  return LAYOUT[i % LAYOUT.length];
}

/** Editorial gallery grid; each image opens the lightbox. */
export function Gallery({ images, title, credits = {} }: { images: ProductImage[]; title: string; credits?: Record<string, ImageCredit | undefined> }) {
  const [index, setIndex] = useState<number | null>(null);

  return (
    <>
      <FadeIn stagger className="grid grid-cols-1 gap-4 md:grid-cols-12 md:gap-6">
        {images.map((img, i) => (
          <button
            key={img.src}
            type="button"
            onClick={() => setIndex(i)}
            data-cursor="view"
            className={`group relative block w-full overflow-hidden bg-ink-2 ${
              layoutFor(i, images.length)
            }`}
            aria-label={`Open image ${i + 1} of ${images.length}: ${img.alt}`}
          >
            <MuseumImage
              src={img.src}
              alt={img.alt}
              fill
              sizes="(min-width: 768px) 60vw, 100vw"
              className="transition-transform duration-[1200ms] ease-[var(--ease-expo)] group-hover:scale-105 motion-reduce:transition-none"
            />
            <span className="counter absolute bottom-4 left-4 text-paper/80">{String(i + 1).padStart(2, "0")}</span>
            {credits[img.src] && (
              <span className="absolute bottom-4 right-4 max-w-[70%] truncate bg-ink/60 px-2 py-1 text-[10px] text-paper/70">
                {credits[img.src]!.artist} · {credits[img.src]!.license}
              </span>
            )}
          </button>
        ))}
      </FadeIn>
      <Lightbox images={images} index={index} onChange={setIndex} title={title} credits={credits} />
    </>
  );
}
