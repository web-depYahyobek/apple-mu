"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useCallback, useEffect, useRef } from "react";
import type { ProductImage } from "@/data/types";
import type { ImageCredit } from "@/lib/credits";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { useSmoothScroll } from "@/components/layout/SmoothScroll";

type Props = {
  images: ProductImage[];
  index: number | null;
  onChange: (index: number | null) => void;
  title: string;
  credits?: Record<string, ImageCredit | undefined>;
};

/**
 * Accessible lightbox: Escape closes, ← / → navigate, focus is trapped and restored,
 * swipe left/right on touch devices.
 */
export function Lightbox({ images, index, onChange, title, credits = {} }: Props) {
  const open = index !== null;
  const dialog = useRef<HTMLDivElement>(null);
  const closeBtn = useRef<HTMLButtonElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const touchX = useRef<number | null>(null);
  const reduce = useReducedMotion();
  const { lock } = useSmoothScroll();

  const go = useCallback(
    (dir: 1 | -1) => {
      if (index === null) return;
      onChange((index + dir + images.length) % images.length);
    },
    [index, images.length, onChange],
  );

  useEffect(() => {
    if (!open) return;
    returnFocus.current = document.activeElement as HTMLElement;
    lock(true);
    const t = window.setTimeout(() => closeBtn.current?.focus(), 50);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onChange(null);
      else if (e.key === "ArrowRight") go(1);
      else if (e.key === "ArrowLeft") go(-1);
      else if (e.key === "Tab" && dialog.current) {
        const items = Array.from(dialog.current.querySelectorAll<HTMLElement>("a[href], button"));
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(t);
      document.removeEventListener("keydown", onKey);
      lock(false);
      returnFocus.current?.focus?.({ preventScroll: true });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, go, onChange]);

  const image = index !== null ? images[index] : null;

  return (
    <AnimatePresence>
      {open && image && (
        <motion.div
          ref={dialog}
          role="dialog"
          aria-modal="true"
          aria-label={`${title} gallery, image ${index! + 1} of ${images.length}`}
          className="fixed inset-0 z-[110] flex flex-col bg-ink/95 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reduce ? 0.15 : 0.4 }}
          onTouchStart={(e) => (touchX.current = e.touches[0].clientX)}
          onTouchEnd={(e) => {
            if (touchX.current === null) return;
            const dx = e.changedTouches[0].clientX - touchX.current;
            if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1);
            touchX.current = null;
          }}
          data-lenis-prevent
        >
          <div className="container-museum flex h-[var(--header-h)] shrink-0 items-center justify-between">
            <p className="counter text-mute">
              {String(index! + 1).padStart(2, "0")} / {String(images.length).padStart(2, "0")}
            </p>
            <button ref={closeBtn} type="button" onClick={() => onChange(null)} className="micro inline-flex items-center gap-3" aria-label="Close gallery">
              Close
              <span className="relative block h-3 w-3" aria-hidden="true">
                <span className="absolute left-0 top-1/2 h-px w-full rotate-45 bg-current" />
                <span className="absolute left-0 top-1/2 h-px w-full -rotate-45 bg-current" />
              </span>
            </button>
          </div>

          <div className="relative flex-1">
            <AnimatePresence mode="wait" initial={false}>
              <motion.figure
                key={image.src}
                className="absolute inset-0 mx-auto max-w-6xl px-5 md:px-20"
                initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 1.04 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: reduce ? 0.15 : 0.5, ease: [0.16, 1, 0.3, 1] }}
              >
                <div className="relative h-[calc(100%-3rem)] w-full">
                  <MuseumImage src={image.src} alt={image.alt} fill sizes="100vw" className="!object-contain" />
                </div>
                <figcaption className="mt-4 text-center text-sm text-mute">
                  {credits[image.src] ? (
                    <>
                      Photo: {credits[image.src]!.artist} ·{" "}
                      <a href={credits[image.src]!.source} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-paper">
                        {credits[image.src]!.license}, Wikimedia Commons
                      </a>
                    </>
                  ) : (
                    image.alt
                  )}
                </figcaption>
              </motion.figure>
            </AnimatePresence>

            <button
              type="button"
              onClick={() => go(-1)}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-4 text-paper/70 transition-colors hover:text-paper md:left-6"
              aria-label="Previous image"
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
                <path d="M15 4 7 12l8 8" />
              </svg>
            </button>
            <button
              type="button"
              onClick={() => go(1)}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-4 text-paper/70 transition-colors hover:text-paper md:right-6"
              aria-label="Next image"
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
                <path d="m9 4 8 8-8 8" />
              </svg>
            </button>
          </div>
          <div className="h-8 shrink-0" />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
