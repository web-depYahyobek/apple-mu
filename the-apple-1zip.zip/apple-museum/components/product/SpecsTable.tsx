"use client";

import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import type { Spec } from "@/data/types";

/** Key specs as a definition table; each row draws its rule and slides in as you scroll. */
export function SpecsTable({ specs }: { specs: Spec[] }) {
  const ref = useRef<HTMLDListElement>(null);

  useGSAP(
    () => {
      const rows = gsap.utils.toArray<HTMLElement>("[data-spec]", ref.current);
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        rows.forEach((row) => {
          const tl = gsap.timeline({ scrollTrigger: { trigger: row, start: "top 90%", once: true } });
          tl.fromTo(row.querySelector("[data-rule]"), { scaleX: 0 }, { scaleX: 1, duration: 1, ease: "expo.out" })
            .from(row.querySelectorAll("dt, dd"), { yPercent: 60, opacity: 0, duration: 0.8, stagger: 0.08 }, 0.1);
        });
      });
      return () => mm.revert();
    },
    { scope: ref },
  );

  return (
    <dl ref={ref}>
      {specs.map((s) => (
        <div key={s.label} data-spec className="relative grid grid-cols-[minmax(7rem,1fr)_2fr] gap-6 py-5">
          <span data-rule aria-hidden="true" className="absolute inset-x-0 top-0 h-px origin-left bg-line" />
          <dt className="micro self-center text-mute">{s.label}</dt>
          <dd className="text-lg tracking-[-0.02em] md:text-xl">{s.value}</dd>
        </div>
      ))}
    </dl>
  );
}
