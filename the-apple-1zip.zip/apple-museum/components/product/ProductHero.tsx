"use client";

import Link from "next/link";
import { useRef } from "react";
import { gsap, MQ, useGSAP } from "@/lib/gsap";
import type { Product } from "@/data/types";
import { ERA_BY_SLUG } from "@/data/eras";
import { formatDate } from "@/lib/format";
import { MuseumImage } from "@/components/ui/MuseumImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { TiltImage } from "@/components/ui/TiltImage";

/**
 * Exhibit hero: the photograph glows behind the page as a blurred ambient light,
 * while a framed copy tilts toward the pointer. On scroll the frame recedes in depth.
 */
export function ProductHero({ product }: { product: Product }) {
  const root = useRef<HTMLElement>(null);
  const ambient = useRef<HTMLDivElement>(null);
  const frame = useRef<HTMLDivElement>(null);
  const era = ERA_BY_SLUG[product.era];

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        gsap.fromTo(ambient.current, { scale: 1.4, opacity: 0 }, { scale: 1.15, opacity: 0.5, duration: 2.4, ease: "expo.out" });
        gsap.from("[data-hero-fact]", { opacity: 0, y: 24, duration: 1, stagger: 0.07, delay: 0.6, ease: "power3.out" });
      });
      mm.add(MQ.desktopMotion, () => {
        gsap.to(frame.current, {
          scale: 0.86,
          yPercent: 12,
          opacity: 0.4,
          ease: "none",
          scrollTrigger: { trigger: root.current, start: "top top", end: "bottom top", scrub: true },
        });
        gsap.to(ambient.current, {
          yPercent: 20,
          ease: "none",
          scrollTrigger: { trigger: root.current, start: "top top", end: "bottom top", scrub: true },
        });
      });
      return () => mm.revert();
    },
    { scope: root },
  );

  const facts = [
    { label: "Released", value: formatDate(product.releaseDate) },
    { label: "Price at launch", value: product.priceAtLaunch },
    { label: "Designed by", value: product.designers.join(", ") },
    { label: "Discontinued", value: product.discontinued ?? "Still available" },
  ];

  return (
    <section
      ref={root}
      className="relative overflow-hidden"
      style={{ ["--accent" as string]: era.accent }}
      aria-labelledby="product-title"
    >
      {/* Ambient light from the photograph itself */}
      <div ref={ambient} className="pointer-events-none absolute inset-0 opacity-50 blur-3xl saturate-150 will-change-transform" aria-hidden="true">
        <MuseumImage src={product.images[0].src} alt="" fill sizes="50vw" blur={false} />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-ink/60 via-ink/70 to-ink" aria-hidden="true" />
      <div className="era-glow absolute inset-0 opacity-60" aria-hidden="true" />

      <div className="container-museum relative grid min-h-[100svh] grid-cols-1 items-end gap-10 pb-12 pt-[calc(var(--header-h)+3rem)] md:pb-16 lg:grid-cols-12 lg:items-center lg:gap-16">
        <div className="order-2 lg:order-1 lg:col-span-6">
          <nav aria-label="Breadcrumb" className="micro mb-10 text-paper/70">
            <ol className="flex flex-wrap items-center gap-2">
              <li>
                <Link href="/collection" className="hover:text-paper">
                  Collection
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link href={`/collection?category=${encodeURIComponent(product.category)}`} className="hover:text-paper">
                  {product.category}
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li aria-current="page" className="text-paper">
                {product.year}
              </li>
            </ol>
          </nav>

          <p className="counter mb-4 text-paper/70">
            {product.year} — {era.title}
          </p>
          <SplitHeadline as="h1" id="product-title" trigger="ready" className="display-md max-w-[14ch]">
            {product.name}
          </SplitHeadline>
          <p data-hero-fact className="lead mt-8 max-w-xl text-paper/85">
            {product.summary}
          </p>

          <dl className="mt-12 grid grid-cols-2 gap-x-6 gap-y-6 border-t hairline pt-6">
            {facts.map((f) => (
              <div key={f.label} data-hero-fact>
                <dt className="micro mb-2 text-mute">{f.label}</dt>
                <dd className="text-sm text-paper md:text-base">{f.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div ref={frame} className="order-1 will-change-transform lg:order-2 lg:col-span-6">
          <TiltImage image={product.images[0]} priority className="aspect-[4/5] w-full lg:aspect-[4/5] lg:max-h-[78vh]" sizes="(min-width: 1024px) 50vw, 100vw" />
        </div>
      </div>
    </section>
  );
}
