export const SITE = {
  name: "The Apple Museum",
  shortName: "Apple Museum",
  description:
    "An unofficial, fan-made digital museum of everything Apple has ever made — hardware, software, services and accessories, from 1976 to today.",
  url: (process.env.NEXT_PUBLIC_SITE_URL ?? "https://the-apple-museum.example").replace(/\/$/, ""),
  disclaimer: "Unofficial fan-made museum. Apple and all product names are trademarks of Apple Inc.",
  locale: "en_US",
} as const;

export type NavItem = { label: string; href: string };

export const NAV: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Timeline", href: "/timeline" },
  { label: "Collection", href: "/collection" },
  { label: "Eras", href: "/eras" },
  { label: "Software", href: "/software" },
  { label: "About", href: "/about" },
  { label: "Visit", href: "/visit" },
];

export const FOOTER_NAV: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Timeline", href: "/timeline" },
  { label: "Collection", href: "/collection" },
  { label: "Eras", href: "/eras" },
  { label: "About", href: "/about" },
  { label: "Visit", href: "/visit" },
  { label: "Legal", href: "/legal" },
  { label: "Sitemap", href: "/sitemap" },
];

/** Replace with real profiles before launch. */
export const SOCIALS = [
  { label: "Instagram", href: "https://www.instagram.com/", icon: "instagram" },
  { label: "X", href: "https://x.com/", icon: "x" },
  { label: "YouTube", href: "https://www.youtube.com/", icon: "youtube" },
] as const;

export function absoluteUrl(path = "/") {
  return `${SITE.url}${path.startsWith("/") ? path : `/${path}`}`;
}
