const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

/** "1984-01-24" → "January 24, 1984"; "1976-07" → "July 1976"; "1976" → "1976". */
export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const [y, m, d] = value.split("-");
  if (!m) return y;
  const month = MONTHS[Number(m) - 1];
  if (!d) return `${month} ${y}`;
  return `${month} ${Number(d)}, ${y}`;
}

export function decadeOf(year: number) {
  return Math.floor(year / 10) * 10;
}

export function decadeLabel(decade: number) {
  return `${decade}s`;
}

export function pad(n: number, len = 2) {
  return String(n).padStart(len, "0");
}

export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}
