"use client";

/**
 * Single place where GSAP plugins are registered.
 * GSAP 3.13+ ships every plugin (ScrollTrigger, SplitText, Flip) for free.
 */
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import { Flip } from "gsap/Flip";
import { useGSAP } from "@gsap/react";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger, SplitText, Flip, useGSAP);
  gsap.defaults({ ease: "power3.out", duration: 1 });
}

/** Media queries shared by every animated component (pass to gsap.matchMedia().add). */
export const MQ = {
  /** Full motion: pinning, scrubbing, parallax. */
  desktopMotion: "(min-width: 1024px) and (prefers-reduced-motion: no-preference)",
  /** Reveals are fine on any size as long as motion is allowed. */
  motion: "(prefers-reduced-motion: no-preference)",
  reduced: "(prefers-reduced-motion: reduce)",
} as const;

export { gsap, ScrollTrigger, SplitText, Flip, useGSAP };
