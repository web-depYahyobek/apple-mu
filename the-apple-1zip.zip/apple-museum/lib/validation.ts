/** Shared by the client forms and the API routes so both validate identically. */

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export type ContactInput = { name: string; email: string; message: string };
export type FieldErrors<T> = Partial<Record<keyof T, string>>;

export function validateContact(input: Partial<ContactInput>): FieldErrors<ContactInput> {
  const errors: FieldErrors<ContactInput> = {};
  const name = (input.name ?? "").trim();
  const email = (input.email ?? "").trim();
  const message = (input.message ?? "").trim();

  if (name.length < 2) errors.name = "Please enter your name.";
  else if (name.length > 100) errors.name = "Please keep your name under 100 characters.";

  if (!email) errors.email = "Please enter your email address.";
  else if (!EMAIL_RE.test(email)) errors.email = "That email address doesn't look right.";

  if (message.length < 10) errors.message = "Please write at least 10 characters.";
  else if (message.length > 2000) errors.message = "Please keep your message under 2,000 characters.";

  return errors;
}

export function validateEmail(email: string | undefined): string | undefined {
  const value = (email ?? "").trim();
  if (!value) return "Please enter your email address.";
  if (!EMAIL_RE.test(value)) return "That email address doesn't look right.";
  return undefined;
}
