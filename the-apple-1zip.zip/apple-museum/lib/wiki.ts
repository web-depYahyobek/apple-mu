import type { Product } from "@/data/types";

/**
 * Wikipedia article for products whose primary source is not Wikipedia.
 * Keep in sync with WIKI_OVERRIDES in scripts/fetch-real-images.mjs.
 */
export const WIKI_OVERRIDES: Record<string, string> = {
  "apple-m1": "Apple_M1",
  "macbook-air-m1": "MacBook_Air_(Apple_silicon)",
  "vision-pro": "Apple_Vision_Pro",
  "iphone-air": "IPhone_Air",
  "macbook-neo": "MacBook_Neo",
  "iphone-18-pro": "IPhone_18_Pro",
  "iphone-duo": "IPhone_Duo",
  "macbook-pro-proled": "MacBook_Pro_(Apple_silicon)",
};

/** The English Wikipedia page title for a product. */
export function wikiTitleFor(product: Product): string {
  if (WIKI_OVERRIDES[product.slug]) return WIKI_OVERRIDES[product.slug];
  const m = product.source.url.match(/en\.wikipedia\.org\/wiki\/(.+)$/);
  return m ? decodeURIComponent(m[1]) : product.name.replace(/\s+/g, "_");
}

export type WikiIntro = { title: string; paragraphs: string[]; url: string };

/**
 * Fetches the plain-text introduction of the product's Wikipedia article at build time
 * (revalidated daily). Returns null when offline or when the article does not exist.
 * Text is CC BY-SA 4.0 and is shown with attribution.
 */
export async function getWikiIntro(product: Product): Promise<WikiIntro | null> {
  const title = wikiTitleFor(product);
  const params = new URLSearchParams({
    action: "query",
    prop: "extracts",
    exintro: "1",
    explaintext: "1",
    redirects: "1",
    titles: title,
    format: "json",
    formatversion: "2",
    origin: "*",
  });
  try {
    const res = await fetch(`https://en.wikipedia.org/w/api.php?${params}`, {
      headers: { "User-Agent": "TheAppleMuseum/1.0 (unofficial fan museum)" },
      next: { revalidate: 86400 },
    });
    if (!res.ok) return null;
    const json = await res.json();
    const page = json?.query?.pages?.[0];
    if (!page || page.missing || !page.extract) return null;
    const paragraphs = String(page.extract)
      .split(/\n+/)
      .map((p: string) => p.trim())
      .filter((p: string) => p.length > 40);
    if (!paragraphs.length) return null;
    return {
      title: page.title,
      paragraphs,
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(String(page.title).replace(/ /g, "_"))}`,
    };
  } catch {
    return null;
  }
}
