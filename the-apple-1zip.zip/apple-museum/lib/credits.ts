import credits from "@/data/image-credits.json";

/**
 * Credits for real photographs downloaded by `npm run images:real`
 * (Wikimedia Commons, free licences only). Keyed by public path.
 */
export type ImageCredit = {
  file: string;
  artist: string;
  license: string;
  licenseUrl?: string;
  source: string;
};

export const CREDITS = credits as Record<string, ImageCredit>;

export function creditFor(src: string): ImageCredit | undefined {
  return CREDITS[src];
}

export function hasRealImage(src: string) {
  return Boolean(CREDITS[src]);
}
