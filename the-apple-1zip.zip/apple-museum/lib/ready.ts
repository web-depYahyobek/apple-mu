"use client";

/**
 * Tiny signal that fires once the preloader has finished.
 * Components that animate "on load" (hero collage, hero headline) wait for it,
 * so the reveal happens as the black curtain lifts rather than behind it.
 */
type Listener = () => void;

let ready = false;
const listeners = new Set<Listener>();

export function markReady() {
  if (ready) return;
  ready = true;
  listeners.forEach((fn) => fn());
  listeners.clear();
}

export function isReady() {
  return ready;
}

/** Calls `fn` now if already ready, otherwise once ready. Returns an unsubscribe. */
export function onReady(fn: Listener) {
  if (ready) {
    fn();
    return () => {};
  }
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
