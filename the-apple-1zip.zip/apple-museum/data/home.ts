import type { EraSlug, ProductImage } from "./types";

/** Ten portrait images for the hero collage (product slugs reuse their hero image). */
export const HERO_COLLAGE: Array<{ slug: string; name: string; year: number }> = [
  { slug: "apple-i", name: "Apple I", year: 1976 },
  { slug: "macintosh-128k", name: "Macintosh 128K", year: 1984 },
  { slug: "imac-g3", name: "iMac G3", year: 1998 },
  { slug: "ipod", name: "iPod", year: 2001 },
  { slug: "iphone", name: "iPhone", year: 2007 },
  { slug: "ipad", name: "iPad", year: 2010 },
  { slug: "apple-watch", name: "Apple Watch", year: 2015 },
  { slug: "airpods", name: "AirPods", year: 2016 },
  { slug: "vision-pro", name: "Apple Vision Pro", year: 2024 },
  { slug: "macbook-air", name: "MacBook Air", year: 2008 },
];

export const MARQUEE_ROWS: string[][] = [
  ["Apple I", "Apple II", "Lisa", "Macintosh", "PowerBook", "Newton", "iMac", "iBook", "iPod"],
  ["iPhone", "iPad", "MacBook", "Apple TV", "Apple Watch", "AirPods", "HomePod", "Vision Pro"],
];

export interface StoryStep {
  label: string;
  title: string;
  range: string;
  body: string;
  products: string;
  era: EraSlug;
  image: ProductImage;
}

export const STORY_STEPS: StoryStep[] = [
  {
    label: "01",
    title: "Vision",
    range: "1976 — 1984",
    body: "It started in a garage in Los Altos, with a circuit board and a conviction that computers belonged to people, not institutions.",
    products: "Apple I · Apple II · Macintosh",
    era: "garage",
    image: { src: "/images/home/story-vision.jpg", alt: "Placeholder: hand-soldered circuit board under warm light" },
  },
  {
    label: "02",
    title: "Craft",
    range: "1997 — 2012",
    body: "Industrial design became strategy. Translucent plastic, polished steel, then a single block of aluminium carved into a unibody.",
    products: "iMac G3 · iPod · iPhone · Unibody MacBook",
    era: "return",
    image: { src: "/images/home/story-craft.jpg", alt: "Placeholder: milled aluminium edge catching a highlight" },
  },
  {
    label: "03",
    title: "Legacy",
    range: "2015 — Today",
    body: "The products became a system. Apple's own silicon underneath, health on the wrist, and computing that fills the room.",
    products: "M-series · Apple Watch · Vision Pro",
    era: "spatial",
    image: { src: "/images/home/story-legacy.jpg", alt: "Placeholder: curved glass reflecting violet light" },
  },
];

export interface Exhibit {
  slug: string;
  title: string;
  description: string;
  href: string;
  image: ProductImage;
}

export const EXHIBITS: Exhibit[] = [
  {
    slug: "mac",
    title: "Mac",
    description: "From a beige box with a handle to a laptop on an iPhone chip. Forty-two years of the personal computer.",
    href: "/collection?category=Mac",
    image: { src: "/images/home/exhibits/mac.jpg", alt: "Placeholder: compact desktop computer on a dark plinth" },
  },
  {
    slug: "ipod",
    title: "iPod",
    description: "Scroll wheel, Click Wheel, no screen at all. The music player that changed Apple's business.",
    href: "/collection?category=iPod",
    image: { src: "/images/home/exhibits/ipod.jpg", alt: "Placeholder: white music player with a circular control" },
  },
  {
    slug: "iphone",
    title: "iPhone",
    description: "An iPod, a phone and an internet communicator. Then a camera, a wallet and a fold.",
    href: "/collection?category=iPhone",
    image: { src: "/images/home/exhibits/iphone.jpg", alt: "Placeholder: black glass phone on a reflective floor" },
  },
  {
    slug: "ipad",
    title: "iPad",
    description: "A sheet of glass you hold in two hands. Later, a pencil, a keyboard and a studio.",
    href: "/collection?category=iPad",
    image: { src: "/images/home/exhibits/ipad.jpg", alt: "Placeholder: thin tablet leaning against a wall" },
  },
  {
    slug: "watch",
    title: "Apple Watch",
    description: "A computer on the wrist that found its purpose in health, and has been credited with saving lives.",
    href: "/collection?category=Watch",
    image: { src: "/images/home/exhibits/watch.jpg", alt: "Placeholder: watch with a rounded square case" },
  },
  {
    slug: "audio",
    title: "AirPods & Audio",
    description: "Earbuds that pair by opening a lid, headphones with a crown, speakers that hear the room.",
    href: "/collection?category=Audio",
    image: { src: "/images/home/exhibits/audio.jpg", alt: "Placeholder: white earbuds in an open case" },
  },
  {
    slug: "vision",
    title: "Vision Pro",
    description: "Apps arranged in the room around you, controlled by your eyes, your hands and your voice.",
    href: "/collection?category=Vision",
    image: { src: "/images/home/exhibits/vision.jpg", alt: "Placeholder: curved glass headset on a stand" },
  },
  {
    slug: "software",
    title: "Software & Services",
    description: "macOS, iOS, iTunes, the App Store, Apple Music. The parts you cannot hold, and use every day.",
    href: "/software",
    image: { src: "/images/home/exhibits/software.jpg", alt: "Placeholder: a window interface glowing on a dark screen" },
  },
];

export const ORDINARY_COLUMNS: ProductImage[] = [
  { src: "/images/home/ordinary-1.jpg", alt: "Placeholder: tall portrait of an all-in-one computer" },
  { src: "/images/home/ordinary-2.jpg", alt: "Placeholder: tall portrait of a phone standing upright" },
  { src: "/images/home/ordinary-3.jpg", alt: "Placeholder: tall portrait of a headset on a plinth" },
];

export const DECADE_CARDS: Array<{ decade: string; year: number; product: string; fact: string; slug: string }> = [
  { decade: "1970s", year: 1976, product: "Apple I", fact: "Sold as a bare board for $666.66. About 200 were made.", slug: "apple-i" },
  { decade: "1980s", year: 1984, product: "Macintosh", fact: "Introduced itself on stage, in its own voice.", slug: "macintosh-128k" },
  { decade: "1990s", year: 1998, product: "iMac G3", fact: "No floppy drive. Critics called it a mistake.", slug: "imac-g3" },
  { decade: "2000s", year: 2007, product: "iPhone", fact: "Announced as three devices. It was one.", slug: "iphone" },
  { decade: "2010s", year: 2015, product: "Apple Watch", fact: "Launched as fashion. Became a health device.", slug: "apple-watch" },
  { decade: "2020s", year: 2026, product: "iPhone Duo", fact: "The first iPhone that folds, from $1,999.", slug: "iphone-duo" },
];

export const PAGE_IMAGES = {
  philosophy: { src: "/images/home/philosophy-macro.jpg", alt: "Placeholder: macro of an aluminium unibody edge and a circuit trace" },
  timeline: { src: "/images/home/timeline-hero.jpg", alt: "Placeholder: long row of devices fading into the dark" },
  collection: { src: "/images/home/collection-hero.jpg", alt: "Placeholder: archive shelves of products in soft light" },
  cta: { src: "/images/home/cta.jpg", alt: "Placeholder: an empty gallery plinth under a spotlight" },
  about: { src: "/images/pages/about.jpg", alt: "Placeholder: a quiet reading room with a single lamp" },
  visit: { src: "/images/pages/visit.jpg", alt: "Placeholder: a long gallery corridor lit from above" },
} satisfies Record<string, ProductImage>;
