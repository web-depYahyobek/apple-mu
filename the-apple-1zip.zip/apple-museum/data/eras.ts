import type { Era, EraSlug } from "./types";

export const ERAS: Era[] = [
  {
    slug: "garage",
    title: "The Garage Years",
    range: "1976 — 1984",
    start: 1976,
    end: 1984,
    accent: "214 168 112",
    headline: "Two Steves. One board. No case.",
    intro:
      "Apple began as a circuit board sold without a keyboard, a power supply or a box. Within a year it was a computer anyone could buy.",
    story: [
      "Steve Wozniak designed the Apple I to impress a hobbyist club. Steve Jobs saw something to sell. The first fifty went to a single store in Mountain View.",
      "The Apple II added colour, sound, expansion slots and a moulded plastic case. It turned a kit into an appliance, and VisiCalc gave businesses a reason to buy one.",
      "The Apple III and Lisa aimed higher and fell short. Both taught the company the same lesson: ambition has to ship at a price people will pay.",
    ],
    image: { src: "/images/eras/garage.jpg", alt: "Placeholder: warm workbench light over a bare circuit board" },
  },
  {
    slug: "macintosh",
    title: "The Macintosh Era",
    range: "1984 — 1985",
    start: 1984,
    end: 1985,
    accent: "226 220 206",
    headline: "The computer for the rest of us.",
    intro:
      "On January 24, 1984, a beige box introduced itself on stage. It had a mouse, a bitmapped screen and a sense of humour.",
    story: [
      "The Macintosh team worked under a pirate flag, apart from the rest of Apple. They signed the inside of the case because they considered it a work of art.",
      "Windows, icons, menus and a pointer were not new ideas. Making them affordable, consistent and friendly was.",
      "Sales slowed in 1985. By September, Steve Jobs had left the company he co-founded.",
    ],
    image: { src: "/images/eras/macintosh.jpg", alt: "Placeholder: soft daylight on a compact beige all-in-one" },
  },
  {
    slug: "wilderness",
    title: "The Wilderness",
    range: "1985 — 1996",
    start: 1985,
    end: 1996,
    accent: "120 140 170",
    headline: "Brilliant parts. No single direction.",
    intro:
      "A decade of real invention and real confusion. Apple built the modern laptop, a pen computer and the PowerPC Mac, while its product line sprawled.",
    story: [
      "The PowerBook set the template every laptop still follows: keyboard pushed back, pointing device in front, palm rests on either side.",
      "Newton recognised handwriting years before the world wanted it to. It was mocked, then missed.",
      "By 1996 Apple had dozens of overlapping models and a stalled operating system. It bought NeXT, and with it, Steve Jobs came back.",
    ],
    image: { src: "/images/eras/wilderness.jpg", alt: "Placeholder: cool blue light across a dark grey laptop lid" },
  },
  {
    slug: "return",
    title: "The Return and iMac",
    range: "1997 — 2000",
    start: 1997,
    end: 2000,
    accent: "70 170 190",
    headline: "Less. Then better.",
    intro:
      "The product line was cut to four quadrants: consumer and pro, desktop and portable. Then colour arrived.",
    story: [
      "The iMac shipped in Bondi Blue translucent plastic, with no floppy drive and a handle on top. Critics called it a mistake. Buyers called it theirs.",
      "The iBook carried the idea into a clamshell, and AirPort made wireless networking something you could set up on a kitchen table.",
      "Even the failures were beautiful. The Power Mac G4 Cube was silent, suspended in acrylic, and gone within a year.",
    ],
    image: { src: "/images/eras/return.jpg", alt: "Placeholder: translucent teal plastic catching a studio light" },
  },
  {
    slug: "ipod",
    title: "The iPod Era",
    range: "2001 — 2006",
    start: 2001,
    end: 2006,
    accent: "236 236 240",
    headline: "A thousand songs in your pocket.",
    intro:
      "Apple stepped outside the computer. A music player, a jukebox app and a store made it a consumer electronics company.",
    story: [
      "The first iPod paired a tiny hard drive with a mechanical scroll wheel and FireWire sync. It held what used to need a shelf.",
      "iTunes organised the library. The iTunes Store sold songs for 99 cents, one at a time, legally.",
      "Mac OS X rebuilt the Mac from a Unix core. In 2006, the move to Intel processors finished the job.",
    ],
    image: { src: "/images/eras/ipod.jpg", alt: "Placeholder: white gloss and polished steel on a reflective floor" },
  },
  {
    slug: "iphone",
    title: "The iPhone Revolution",
    range: "2007 — 2010",
    start: 2007,
    end: 2010,
    accent: "150 160 175",
    headline: "An iPod, a phone, an internet communicator.",
    intro: "One device replaced a pocketful. A year later, an App Store turned it into whatever you needed.",
    story: [
      "The original iPhone removed the keyboard and trusted a multi-touch screen to do everything.",
      "The App Store opened with 500 apps in July 2008. It became an economy.",
      "In 2010 the iPad stretched the same idea to a sheet of glass you held in two hands.",
    ],
    image: { src: "/images/eras/iphone.jpg", alt: "Placeholder: black glass slab with a single highlight" },
  },
  {
    slug: "ecosystem",
    title: "The Ecosystem Era",
    range: "2011 — 2019",
    start: 2011,
    end: 2019,
    accent: "190 170 150",
    headline: "Everything, everywhere, in sync.",
    intro: "The products started talking to each other. The value moved from any one device to the space between them.",
    story: [
      "iCloud put documents, photos and backups in the background. Apple Pay put a card on the wrist.",
      "Apple Watch made health a product category. AirPods made wireless audio something you stopped thinking about.",
      "Services grew into a business of their own: music, television, games, storage.",
    ],
    image: { src: "/images/eras/ecosystem.jpg", alt: "Placeholder: several devices arranged in warm low light" },
  },
  {
    slug: "silicon",
    title: "Apple Silicon",
    range: "2020 — 2023",
    start: 2020,
    end: 2023,
    accent: "200 200 210",
    headline: "The chip became the product.",
    intro: "In November 2020, the Mac moved to Apple's own processors. Battery life doubled. Fans went quiet.",
    story: [
      "M1 put CPU, GPU, Neural Engine and unified memory on one piece of silicon.",
      "The MacBook Air lost its fan entirely. The iMac became a sheet of colour 11.5 millimetres thin.",
      "Mac Studio, Pro and Ultra chips followed, each scaling the same architecture upward.",
    ],
    image: { src: "/images/eras/silicon.jpg", alt: "Placeholder: macro of a polished chip package" },
  },
  {
    slug: "spatial",
    title: "Spatial Computing",
    range: "2024 — Today",
    start: 2024,
    end: null,
    accent: "170 160 220",
    headline: "Apps, in the room with you.",
    intro: "Vision Pro put a computer around your eyes. On-device intelligence moved into everything else.",
    story: [
      "Apple Vision Pro shipped in February 2024 with two micro-OLED displays and an operating system controlled by eyes, hands and voice.",
      "Apple Intelligence arrived in late 2024, running on-device first and in Private Cloud Compute when it needed more.",
      "In 2026 the line kept stretching: a $599 MacBook Neo, the folding iPhone Duo and the first touchscreen MacBook Pro. In September, John Ternus took over as CEO from Tim Cook.",
    ],
    image: { src: "/images/eras/spatial.jpg", alt: "Placeholder: soft violet light reflected in curved glass" },
  },
];

export const ERA_BY_SLUG = Object.fromEntries(ERAS.map((e) => [e.slug, e])) as Record<EraSlug, Era>;

export function getEra(slug: EraSlug) {
  return ERA_BY_SLUG[slug];
}
