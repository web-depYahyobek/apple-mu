/**
 * Content schema. Kept deliberately flat and serialisable so it can move
 * to a headless CMS (Sanity, Contentful, Payload…) without reshaping.
 */

export const CATEGORIES = [
  "Classic",
  "Mac",
  "iPod",
  "iPhone",
  "iPad",
  "Watch",
  "Audio",
  "TV/Home",
  "Vision",
  "Software",
  "Services",
  "Accessories",
] as const;

export type Category = (typeof CATEGORIES)[number];

export type EraSlug =
  | "garage"
  | "macintosh"
  | "wilderness"
  | "return"
  | "ipod"
  | "iphone"
  | "ecosystem"
  | "silicon"
  | "spatial";

export interface Spec {
  label: string;
  value: string;
}

export interface ProductImage {
  src: string;
  alt: string;
}

export interface Product {
  /** URL slug, unique. */
  slug: string;
  name: string;
  category: Category;
  /** Year of first public release (used for sorting, filtering, timeline). */
  year: number;
  /** ISO date of release: "YYYY-MM-DD", or "YYYY-MM" when only the month is certain. */
  releaseDate: string;
  /** ISO date of announcement, when it differs meaningfully from release. */
  announced?: string;
  /** Free text: date the model was discontinued, plus line status. `null` = still available. */
  discontinued: string | null;
  /** US launch price as printed at the time. */
  priceAtLaunch: string;
  designers: string[];
  /** One or two sentences. Used on cards, timeline and meta descriptions. */
  summary: string;
  /** Exactly three short paragraphs. */
  whyItMattered: [string, string, string];
  specs: Spec[];
  /** First image is the hero. 4–6 total. */
  images: ProductImage[];
  era: EraSlug;
  source: { label: string; url: string };
}

export interface Era {
  slug: EraSlug;
  title: string;
  range: string;
  start: number;
  end: number | null;
  /** RGB triplet used for the era mood, e.g. "214 168 112". */
  accent: string;
  headline: string;
  intro: string;
  story: string[];
  image: ProductImage;
}

export interface OsVersion {
  slug: string;
  name: string;
  year: number;
  note: string;
  image: ProductImage;
}

export interface OsFamily {
  slug: string;
  name: string;
  platform: string;
  summary: string;
  versions: OsVersion[];
}

export interface AppEntry {
  name: string;
  year: number;
  note: string;
  productSlug?: string;
}
