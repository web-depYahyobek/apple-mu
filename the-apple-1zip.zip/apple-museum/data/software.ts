import type { AppEntry, OsFamily, OsVersion } from "./types";

function v(family: string, slug: string, name: string, year: number, note: string): OsVersion {
  return {
    slug,
    name,
    year,
    note,
    image: {
      src: `/images/software/${family}-${slug}.jpg`,
      alt: `Placeholder screenshot: ${name} (${year}) desktop or home screen`,
    },
  };
}

export const OS_FAMILIES: OsFamily[] = [
  {
    slug: "macos",
    name: "System 1 to macOS",
    platform: "Mac",
    summary: "Four decades on one platform: a single-tasking Finder, a Unix rebuild, and a glass interface.",
    versions: [
      v("macos", "system-1", "System 1", 1984, "A Finder, a Trash, a menu bar. One app at a time."),
      v("macos", "system-7", "System 7", 1991, "Multitasking for everyone, aliases, colour and TrueType."),
      v("macos", "mac-os-8", "Mac OS 8", 1997, "Platinum appearance, a multithreaded Finder, contextual menus."),
      v("macos", "mac-os-9", "Mac OS 9", 1999, "Sherlock 2, multiple users, the last classic Mac OS."),
      v("macos", "mac-os-x-10-0", "Mac OS X 10.0 Cheetah", 2001, "Unix underneath. Aqua and the Dock on top."),
      v("macos", "os-x-mavericks", "OS X 10.9 Mavericks", 2013, "The end of the big cats, and the first free upgrade."),
      v("macos", "macos-big-sur", "macOS 11 Big Sur", 2020, "Version 11 at last, redesigned for Apple silicon."),
      v("macos", "macos-tahoe", "macOS 26 Tahoe", 2025, "Liquid Glass, and version numbers aligned to the year."),
    ],
  },
  {
    slug: "ios",
    name: "iPhone OS to iOS",
    platform: "iPhone",
    summary: "From a touchscreen with no third-party apps to the most widely used mobile platform in the world.",
    versions: [
      v("ios", "iphone-os-1", "iPhone OS 1", 2007, "Slide to unlock, pinch to zoom, no App Store."),
      v("ios", "iphone-os-3", "iPhone OS 3", 2009, "Copy and paste, Spotlight, push notifications."),
      v("ios", "ios-7", "iOS 7", 2013, "Flat, layered, translucent. Skeuomorphism retired."),
      v("ios", "ios-14", "iOS 14", 2020, "Widgets on the Home Screen and the App Library."),
      v("ios", "ios-26", "iOS 26", 2025, "Liquid Glass across every control."),
      v("ios", "ios-27", "iOS 27", 2026, "Released September 14, 2026."),
    ],
  },
  {
    slug: "ipados",
    name: "iPadOS",
    platform: "iPad",
    summary: "The iPad's own branch of iOS, growing toward windows, files and a real menu bar.",
    versions: [
      v("ipados", "ipados-13", "iPadOS 13", 2019, "Split from iOS. Desktop-class Safari and USB drives."),
      v("ipados", "ipados-16", "iPadOS 16", 2022, "Stage Manager and resizable windows."),
      v("ipados", "ipados-26", "iPadOS 26", 2025, "A new windowing system and a menu bar."),
    ],
  },
  {
    slug: "watchos",
    name: "watchOS",
    platform: "Apple Watch",
    summary: "An interface for a screen the size of a postage stamp, rebuilt more than once.",
    versions: [
      v("watchos", "watchos-1", "watchOS 1", 2015, "Apps ran on the iPhone and were mirrored to the wrist."),
      v("watchos", "watchos-10", "watchOS 10", 2023, "Smart Stack widgets and a redesigned app layout."),
      v("watchos", "watchos-26", "watchOS 26", 2025, "Liquid Glass and a wrist-flick gesture."),
    ],
  },
  {
    slug: "visionos",
    name: "visionOS",
    platform: "Apple Vision Pro",
    summary: "Windows that float in your room, controlled by your eyes and hands.",
    versions: [
      v("visionos", "visionos-1", "visionOS 1", 2024, "Spatial windows, immersive environments, Personas."),
      v("visionos", "visionos-2", "visionOS 2", 2024, "Spatial photos from 2D images and new gestures."),
      v("visionos", "visionos-26", "visionOS 26", 2025, "Widgets placed on walls, shared experiences."),
    ],
  },
];

export const APPS: AppEntry[] = [
  { name: "MacPaint", year: 1984, note: "Bill Atkinson's bitmap editor, bundled with the first Mac." },
  { name: "HyperCard", year: 1987, note: "Stacks of cards with buttons and scripts. A web before the web." },
  { name: "QuickTime", year: 1991, note: "Video on a personal computer, in a window, with sound." },
  { name: "Final Cut Pro", year: 1999, note: "Broadcast editing at desktop prices.", productSlug: "final-cut-pro" },
  { name: "iMovie", year: 1999, note: "Home video editing, free with the iMac DV." },
  { name: "iTunes", year: 2001, note: "Rip, mix, burn. Then sync, buy and back up.", productSlug: "itunes" },
  { name: "Safari", year: 2003, note: "Apple's browser and the WebKit engine.", productSlug: "safari" },
  { name: "Keynote", year: 2003, note: "Built for Steve Jobs' own presentations." },
  { name: "Xcode", year: 2003, note: "The developer toolkit behind every Apple app." },
  { name: "GarageBand", year: 2004, note: "A studio for people who had never been in one.", productSlug: "garageband" },
  { name: "Logic Pro", year: 2004, note: "Professional music production, from the Emagic acquisition." },
  { name: "Pages", year: 2005, note: "Word processing and layout in iWork." },
  { name: "Swift", year: 2014, note: "A safer language for every Apple platform.", productSlug: "swift" },
  { name: "Photos", year: 2015, note: "One library across every device, replacing iPhoto and Aperture." },
  { name: "Shortcuts", year: 2018, note: "Automation for everyone, from the Workflow acquisition." },
];

export function getFamily(slug: string) {
  return OS_FAMILIES.find((f) => f.slug === slug);
}
