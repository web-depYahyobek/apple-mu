import { NextResponse } from "next/server";
import { validateEmail } from "@/lib/validation";

/**
 * Newsletter signup endpoint.
 * TODO: forward to your list provider (Buttondown, Mailchimp, ConvertKit…).
 */
export async function POST(request: Request) {
  let body: { email?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }

  const error = validateEmail(body.email);
  if (error) return NextResponse.json({ ok: false, error }, { status: 422 });

  console.info("[newsletter] signup received");
  return NextResponse.json({ ok: true });
}
