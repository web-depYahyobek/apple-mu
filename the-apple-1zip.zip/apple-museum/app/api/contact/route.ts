import { NextResponse } from "next/server";
import { validateContact, type ContactInput } from "@/lib/validation";

/**
 * Contact endpoint. Validates server-side, then hands off.
 * TODO: connect to your mail provider (Resend, Postmark, SES…) or a form service.
 */
export async function POST(request: Request) {
  let body: Partial<ContactInput>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }

  const errors = validateContact(body);
  if (Object.keys(errors).length) {
    return NextResponse.json({ ok: false, errors }, { status: 422 });
  }

  // Placeholder delivery: log on the server only.
  console.info("[contact] message received from", body.email?.trim());

  return NextResponse.json({ ok: true });
}
