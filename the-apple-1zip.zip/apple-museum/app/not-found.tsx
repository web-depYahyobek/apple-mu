import Link from "next/link";
import { Button } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <section className="container-museum flex min-h-[80svh] flex-col justify-end pb-20 pt-[calc(var(--header-h)+6rem)]">
      <p className="micro mb-6 text-mute">Error 404</p>
      <h1 className="display max-w-[12ch]">This room is empty.</h1>
      <p className="lead mt-8 max-w-lg text-mute">
        The page you were looking for isn&apos;t in the archive. It may have moved, or it may never have shipped.
      </p>
      <div className="mt-12 flex flex-wrap items-center gap-6">
        <Button href="/collection">Browse the Collection</Button>
        <Link href="/" className="micro text-mute hover:text-paper">
          Back to the entrance
        </Link>
      </div>
    </section>
  );
}
