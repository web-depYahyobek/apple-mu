import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui/PageHeader";
import { EraSection } from "@/components/eras/EraSection";
import { ERAS } from "@/data/eras";
import { getProductsByEra } from "@/data/products";

export const metadata: Metadata = {
  title: "The Eras",
  description: "Nine chapters of Apple history, from the garage years to spatial computing, each with its own story and products.",
  alternates: { canonical: "/eras" },
  openGraph: { url: "/eras", title: "The Eras" },
};

export default function ErasPage() {
  return (
    <>
      <PageHeader
        eyebrow="The Eras"
        counter={`${ERAS.length} chapters`}
        title="Nine chapters. One idea."
        intro="Apple's history reads best in chapters: each with its own mood, its own people and its own definition of what a computer should be."
      />

      <nav aria-label="Eras" className="container-museum pb-20">
        <ol className="grid grid-cols-3 gap-px border hairline bg-line lg:grid-cols-9">
          {ERAS.map((era, i) => (
            <li key={era.slug} className="bg-ink">
              <Link href={`#${era.slug}`} className="group flex h-full flex-col justify-between gap-6 p-4 transition-colors hover:bg-ink-2">
                <span className="counter text-mute">{String(i + 1).padStart(2, "0")}</span>
                <span>
                  <span className="block h-px w-6 transition-all duration-500 group-hover:w-12" style={{ background: `rgb(${era.accent})` }} aria-hidden="true" />
                  <span className="mt-3 block text-sm font-medium leading-snug">{era.title}</span>
                  <span className="counter mt-1 block text-mute">{era.range}</span>
                </span>
              </Link>
            </li>
          ))}
        </ol>
      </nav>

      {ERAS.map((era, i) => (
        <EraSection key={era.slug} era={era} index={i} total={ERAS.length} products={getProductsByEra(era.slug)} />
      ))}
    </>
  );
}
