import { ImageResponse } from "next/og";
import { SITE } from "@/lib/site";

export const alt = `${SITE.name} — Every product. One archive.`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Default Open Graph image, rendered at build time. */
export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          background: "radial-gradient(80% 60% at 50% 0%, #2a2c30 0%, #0c0c0c 70%)",
          color: "#f5f5f7",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 22, letterSpacing: 6, textTransform: "uppercase", color: "#86868b" }}>
          <span>{SITE.name}</span>
          <span>1976 — Today</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 112, lineHeight: 0.95, letterSpacing: -5, fontWeight: 600 }}>Every Product.</div>
          <div style={{ fontSize: 112, lineHeight: 0.95, letterSpacing: -5, fontWeight: 600 }}>One Archive.</div>
          <div style={{ marginTop: 36, fontSize: 18, color: "#86868b" }}>{SITE.disclaimer}</div>
        </div>
      </div>
    ),
    size,
  );
}
