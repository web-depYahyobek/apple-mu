import type { Metadata } from "next";
import { Suspense } from "react";
import { PageHeader } from "@/components/ui/PageHeader";
import { CollectionGrid } from "@/components/collection/CollectionGrid";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "The Collection",
  description: `Search and filter ${PRODUCTS.length} Apple products — Mac, iPod, iPhone, iPad, Watch, audio, home, Vision, software, services and accessories.`,
  alternates: { canonical: "/collection" },
  openGraph: { url: "/collection", title: "The Collection" },
};

export default function CollectionPage() {
  return (
    <>
      <PageHeader
        eyebrow="The Collection"
        counter={`${PRODUCTS.length} objects`}
        title="Every Product. One Archive."
        intro="Filter by category or decade, sort by year or name, or search for a designer. Every card opens its own exhibit."
      />
      {/* useSearchParams needs a Suspense boundary for static rendering. */}
      <Suspense fallback={<div className="container-museum py-24 text-mute">Loading the archive…</div>}>
        <CollectionGrid products={PRODUCTS} />
      </Suspense>
    </>
  );
}
