import { ImageResponse } from "next/og";
import { getProduct, PRODUCTS } from "@/data/products";
import { ERA_BY_SLUG } from "@/data/eras";
import { SITE } from "@/lib/site";

export const alt = "Exhibit from the Apple Museum";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export function generateStaticParams() {
  return PRODUCTS.map((p) => ({ slug: p.slug }));
}

/** Per-exhibit Open Graph image: name, year, era colour. */
export default async function Image({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = getProduct(slug);
  const accent = product ? ERA_BY_SLUG[product.era].accent.split(" ").join(",") : "232,236,242";

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          background: `radial-gradient(70% 70% at 50% 0%, rgba(${accent},0.35) 0%, #0c0c0c 70%)`,
          color: "#f5f5f7",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 22, letterSpacing: 6, textTransform: "uppercase", color: "#86868b" }}>
          <span>{SITE.name}</span>
          <span>{product?.category ?? "Exhibit"}</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 40, color: "#86868b" }}>{product?.year}</div>
          <div style={{ fontSize: 108, lineHeight: 0.95, letterSpacing: -5, fontWeight: 600, maxWidth: 1000 }}>{product?.name ?? "Exhibit"}</div>
          <div style={{ marginTop: 28, fontSize: 26, color: "#c7c7cc", maxWidth: 980 }}>{product?.summary}</div>
        </div>
      </div>
    ),
    size,
  );
}
