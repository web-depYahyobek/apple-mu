import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductHero } from "@/components/product/ProductHero";
import { SpecsTable } from "@/components/product/SpecsTable";
import { Gallery } from "@/components/product/Gallery";
import { ProductCard } from "@/components/collection/ProductCard";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { FadeIn } from "@/components/ui/FadeIn";
import { JsonLd } from "@/components/ui/JsonLd";
import { Arrow } from "@/components/ui/Button";
import { getNeighbours, getProduct, getRelated, PRODUCTS } from "@/data/products";
import { ERA_BY_SLUG } from "@/data/eras";
import { absoluteUrl, SITE } from "@/lib/site";
import { formatDate } from "@/lib/format";
import { getWikiIntro } from "@/lib/wiki";
import { CREDITS } from "@/lib/credits";

type Params = { slug: string };

export const dynamicParams = false;

export function generateStaticParams(): Params[] {
  return PRODUCTS.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const product = getProduct(slug);
  if (!product) return {};
  const title = `${product.name} (${product.year})`;
  return {
    title,
    description: product.summary,
    alternates: { canonical: `/collection/${product.slug}` },
    openGraph: { type: "article", url: `/collection/${product.slug}`, title, description: product.summary },
    twitter: { card: "summary_large_image", title, description: product.summary },
  };
}

export default async function ProductPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const product = getProduct(slug);
  if (!product) notFound();

  const { prev, next } = getNeighbours(product.slug);
  const related = getRelated(product);
  const era = ERA_BY_SLUG[product.era];
  const intro = await getWikiIntro(product);
  // Once real photographs are downloaded, show only those in the gallery.
  const realImages = product.images.filter((i) => CREDITS[i.src]);
  const gallery = realImages.length ? realImages : product.images;
  const credits = Object.fromEntries(gallery.map((i) => [i.src, CREDITS[i.src]]));

  return (
    <article>
      <JsonLd
        data={[
          {
            "@context": "https://schema.org",
            "@type": "Product",
            name: product.name,
            description: product.summary,
            image: product.images.map((i) => absoluteUrl(i.src)),
            brand: { "@type": "Brand", name: "Apple" },
            manufacturer: { "@type": "Organization", name: "Apple" },
            releaseDate: product.releaseDate,
            category: product.category,
            url: absoluteUrl(`/collection/${product.slug}`),
          },
          {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: SITE.name, item: absoluteUrl("/") },
              { "@type": "ListItem", position: 2, name: "Collection", item: absoluteUrl("/collection") },
              { "@type": "ListItem", position: 3, name: product.name, item: absoluteUrl(`/collection/${product.slug}`) },
            ],
          },
        ]}
      />

      <ProductHero product={product} />

      {/* Why it mattered + specs */}
      <section className="container-museum grid gap-16 py-24 md:py-36 lg:grid-cols-12" aria-labelledby="why-title">
        <div className="lg:col-span-6">
          <p className="micro mb-8 text-mute">Why it mattered</p>
          <SplitHeadline id="why-title" className="display-sm mb-12 max-w-[16ch]">
            {product.whyItMattered[0]}
          </SplitHeadline>
          <FadeIn stagger className="max-w-xl space-y-6">
            {product.whyItMattered.slice(1).map((para) => (
              <p key={para} className="lead text-paper/80">
                {para}
              </p>
            ))}
            <p className="pt-4 text-sm text-mute">
              Source:{" "}
              <a href={product.source.url} target="_blank" rel="noopener noreferrer" className="underline decoration-paper/30 underline-offset-4 hover:text-paper hover:decoration-paper">
                {product.source.label}
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
              {" · "}
              <Link href={`/eras#${era.slug}`} className="underline decoration-paper/30 underline-offset-4 hover:text-paper hover:decoration-paper">
                {era.title}
              </Link>
            </p>
          </FadeIn>
        </div>
        <div className="lg:col-span-5 lg:col-start-8">
          <h2 className="micro mb-6 text-mute">Key specifications</h2>
          <SpecsTable
            specs={[
              ...product.specs,
              { label: "Category", value: product.category },
              ...(product.announced ? [{ label: "Announced", value: formatDate(product.announced) }] : []),
            ]}
          />
        </div>
      </section>

      {/* Encyclopedia: full introduction from Wikipedia (CC BY-SA) */}
      {intro && (
        <section className="border-t hairline py-24 md:py-32" aria-labelledby="encyclopedia-title">
          <div className="container-museum grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <p className="micro mb-6 text-mute">The full record</p>
              <h2 id="encyclopedia-title" className="display-sm max-w-[12ch]">
                Everything about {product.name}.
              </h2>
            </div>
            <FadeIn stagger className="space-y-6 lg:col-span-7 lg:col-start-6">
              {intro.paragraphs.map((para, i) => (
                <p key={i} className={i === 0 ? "lead text-paper/90" : "text-lg leading-relaxed text-paper/75"}>
                  {para}
                </p>
              ))}
              <p className="border-t hairline pt-5 text-xs text-mute">
                Text from the Wikipedia article{" "}
                <a href={intro.url} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-paper">
                  “{intro.title}”
                </a>
                , available under{" "}
                <a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-paper">
                  CC BY-SA 4.0
                </a>
                .
              </p>
            </FadeIn>
          </div>
        </section>
      )}

      {/* Gallery */}
      <section className="container-museum pb-24 md:pb-36" aria-labelledby="gallery-title">
        <div className="mb-10 flex items-end justify-between border-b hairline pb-4">
          <h2 id="gallery-title" className="micro text-mute">
            Gallery
          </h2>
          <p className="counter text-mute">{gallery.length} images</p>
        </div>
        <Gallery images={gallery} title={product.name} credits={credits} />
      </section>

      {/* Previous / next */}
      <nav aria-label="Timeline" className="grid border-y hairline md:grid-cols-2">
        {prev ? (
          <Link href={`/collection/${prev.slug}`} className="group flex flex-col gap-3 p-8 transition-colors hover:bg-ink-2 md:p-12">
            <span className="micro inline-flex items-center gap-3 text-mute">
              <Arrow className="rotate-180 transition-transform group-hover:-translate-x-1" /> Previous in timeline
            </span>
            <span className="display-sm">{prev.name}</span>
            <span className="counter text-mute">{prev.year}</span>
          </Link>
        ) : (
          <div className="hidden md:block" />
        )}
        {next ? (
          <Link
            href={`/collection/${next.slug}`}
            className="group flex flex-col items-end gap-3 border-t hairline p-8 text-right transition-colors hover:bg-ink-2 md:border-l md:border-t-0 md:p-12"
          >
            <span className="micro inline-flex items-center gap-3 text-mute">
              Next in timeline <Arrow className="transition-transform group-hover:translate-x-1" />
            </span>
            <span className="display-sm">{next.name}</span>
            <span className="counter text-mute">{next.year}</span>
          </Link>
        ) : (
          <div />
        )}
      </nav>

      {/* Related */}
      {related.length > 0 && (
        <section className="container-museum py-24 md:py-32" aria-labelledby="related-title">
          <div className="mb-12 flex items-end justify-between">
            <h2 id="related-title" className="display-sm">
              Related products
            </h2>
            <Link href="/collection" className="micro text-mute hover:text-paper">
              All products
            </Link>
          </div>
          <FadeIn stagger className="grid grid-cols-2 gap-x-4 gap-y-12 md:grid-cols-4 md:gap-x-6">
            {related.map((r) => (
              <ProductCard key={r.slug} product={r} sizes="(min-width: 768px) 25vw, 50vw" />
            ))}
          </FadeIn>
        </section>
      )}
    </article>
  );
}
