import type { Metadata } from "next";
import { PageHeader } from "@/components/ui/PageHeader";
import { RevealImage } from "@/components/ui/RevealImage";
import { Button } from "@/components/ui/Button";
import { FadeIn } from "@/components/ui/FadeIn";
import { ContactForm } from "@/components/forms/ContactForm";
import { NewsletterForm } from "@/components/forms/NewsletterForm";
import { PAGE_IMAGES } from "@/data/home";

export const metadata: Metadata = {
  title: "Visit",
  description: "Plan a visit to the virtual Apple Museum: opening hours, guided virtual tours, the monthly letter and how to contact the curators.",
  alternates: { canonical: "/visit" },
  openGraph: { url: "/visit", title: "Visit the museum" },
};

const HOURS = [
  { day: "Galleries", time: "Open always" },
  { day: "Guided tours", time: "Tue – Sun, 10:00 – 18:00" },
  { day: "Curator Q&A", time: "First Thursday, 19:00" },
  { day: "Closed", time: "Never. It's a website." },
];

export default function VisitPage() {
  return (
    <>
      <PageHeader
        eyebrow="Visit"
        title="The doors never close."
        intro="The museum lives online, so the galleries are open whenever you are. Guided tours run in your local time zone."
      />

      <section className="container-museum grid gap-12 pb-24 lg:grid-cols-12" aria-labelledby="hours-title">
        <RevealImage image={PAGE_IMAGES.visit} className="aspect-[4/3] lg:col-span-7" sizes="(min-width: 1024px) 58vw, 100vw" />
        <div className="lg:col-span-4 lg:col-start-9">
          <h2 id="hours-title" className="micro mb-6 text-mute">
            Opening hours
          </h2>
          <FadeIn as="dl" stagger>
            {HOURS.map((h) => (
              <div key={h.day} className="flex items-baseline justify-between gap-6 border-b hairline py-4">
                <dt className="text-mute">{h.day}</dt>
                <dd className="text-right">{h.time}</dd>
              </div>
            ))}
          </FadeIn>
          <p className="mt-6 text-sm text-mute">Admission is free. No tickets, no queues, no gift shop.</p>
          <div className="mt-10">
            <Button href="/timeline" variant="solid">
              Start the virtual tour
            </Button>
          </div>
        </div>
      </section>

      <section className="border-t hairline py-24 md:py-32" aria-labelledby="newsletter-title">
        <div className="container-museum grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="micro mb-6 text-mute">The monthly letter</p>
            <h2 id="newsletter-title" className="display-sm">
              New exhibits, once a month.
            </h2>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <NewsletterForm />
            <p className="mt-4 text-xs text-mute">We only use your address to send the letter. Unsubscribe with one click.</p>
          </div>
        </div>
      </section>

      <section className="border-t hairline py-24 md:py-32" aria-labelledby="contact-title">
        <div className="container-museum grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="micro mb-6 text-mute">Contact</p>
            <h2 id="contact-title" className="display-sm">
              Spotted an error? Own a prototype?
            </h2>
            <p className="mt-6 max-w-md text-mute">
              Corrections, photographs, loans and questions are all welcome. Please include a source if you&apos;re
              correcting a date or price.
            </p>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
}
