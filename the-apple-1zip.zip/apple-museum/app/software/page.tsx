import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui/PageHeader";
import { EvolutionSlider } from "@/components/software/EvolutionSlider";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { FadeIn } from "@/components/ui/FadeIn";
import { APPS, OS_FAMILIES } from "@/data/software";
import { getProductsByCategory } from "@/data/products";
import { ProductCard } from "@/components/collection/ProductCard";

export const metadata: Metadata = {
  title: "Software",
  description: "A visual history of Apple's operating systems and apps: System 1 to macOS, iPhone OS to iOS, iPadOS, watchOS, visionOS, and the apps that defined them.",
  alternates: { canonical: "/software" },
  openGraph: { url: "/software", title: "Software" },
};

export default function SoftwarePage() {
  const softwareProducts = [...getProductsByCategory("Software"), ...getProductsByCategory("Services")].sort((a, b) =>
    a.releaseDate.localeCompare(b.releaseDate),
  );

  return (
    <>
      <PageHeader
        eyebrow="Software"
        counter={`${OS_FAMILIES.length} platforms`}
        title="The parts you cannot hold."
        intro="Drag the divider to compare versions side by side. Interfaces change faster than hardware, and say more about what each decade valued."
      />

      <nav aria-label="Platforms" className="container-museum pb-16">
        <ul className="flex flex-wrap gap-2">
          {OS_FAMILIES.map((f) => (
            <li key={f.slug}>
              <Link href={`#${f.slug}`} className="micro inline-block border border-line px-4 py-2.5 text-paper/80 transition-colors hover:border-paper hover:text-paper">
                {f.name}
              </Link>
            </li>
          ))}
          <li>
            <Link href="#apps" className="micro inline-block border border-line px-4 py-2.5 text-paper/80 transition-colors hover:border-paper hover:text-paper">
              Apps
            </Link>
          </li>
        </ul>
      </nav>

      {OS_FAMILIES.map((family, i) => (
        <section
          key={family.slug}
          id={family.slug}
          aria-labelledby={`${family.slug}-title`}
          className="scroll-mt-[calc(var(--header-h)+2rem)] border-t hairline py-20 md:py-28"
        >
          <div className="container-museum grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <p className="counter mb-6 text-mute">
                {String(i + 1).padStart(2, "0")} — {family.platform}
              </p>
              <h2 id={`${family.slug}-title`} className="display-sm mb-6">
                {family.name}
              </h2>
              <p className="text-mute">{family.summary}</p>
              <ol className="mt-10 border-t hairline">
                {family.versions.map((v) => (
                  <li key={v.slug} className="flex items-baseline justify-between gap-4 border-b hairline py-3 text-sm">
                    <span>{v.name}</span>
                    <span className="counter text-mute">{v.year}</span>
                  </li>
                ))}
              </ol>
            </div>
            <div className="lg:col-span-8">
              <EvolutionSlider family={family} />
            </div>
          </div>
        </section>
      ))}

      <section id="apps" aria-labelledby="apps-title" className="scroll-mt-[calc(var(--header-h)+2rem)] border-t hairline py-24 md:py-32">
        <div className="container-museum">
          <p className="micro mb-8 text-mute">Apps</p>
          <SplitHeadline id="apps-title" className="display-md mb-16 max-w-[14ch]">
            Tools that taught people to make things.
          </SplitHeadline>
          <FadeIn stagger as="ol" className="grid border-t hairline md:grid-cols-2 lg:grid-cols-3">
            {APPS.map((app) => (
              <li key={app.name} className="flex flex-col justify-between gap-6 border-b hairline py-8 md:pr-10">
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="text-2xl font-medium tracking-[-0.03em]">{app.name}</h3>
                  <span className="counter text-mute">{app.year}</span>
                </div>
                <p className="text-mute">{app.note}</p>
                {app.productSlug && (
                  <Link href={`/collection/${app.productSlug}`} className="micro text-paper/80 underline decoration-paper/30 underline-offset-8 hover:decoration-paper">
                    View exhibit
                  </Link>
                )}
              </li>
            ))}
          </FadeIn>
        </div>
      </section>

      <section aria-labelledby="sw-collection-title" className="border-t hairline py-24 md:py-32">
        <div className="container-museum">
          <div className="mb-12 flex items-end justify-between">
            <h2 id="sw-collection-title" className="display-sm">
              Software & services in the collection
            </h2>
            <span className="counter text-mute">{softwareProducts.length} objects</span>
          </div>
          <FadeIn stagger className="grid grid-cols-2 gap-x-4 gap-y-12 md:grid-cols-4 md:gap-x-6">
            {softwareProducts.map((p) => (
              <ProductCard key={p.slug} product={p} aspect="aspect-[4/3]" sizes="(min-width: 768px) 25vw, 50vw" />
            ))}
          </FadeIn>
        </div>
      </section>
    </>
  );
}
