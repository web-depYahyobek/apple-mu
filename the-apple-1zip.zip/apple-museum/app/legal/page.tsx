import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui/PageHeader";
import { SITE } from "@/lib/site";
import { CREDITS } from "@/lib/credits";

export const metadata: Metadata = {
  title: "Legal",
  description: "Trademark notice, image credit policy, content accuracy and privacy for the unofficial Apple Museum.",
  alternates: { canonical: "/legal" },
};

const SECTIONS = [
  {
    id: "trademarks",
    title: "Trademarks",
    body: [
      SITE.disclaimer,
      "This is an independent, non-commercial fan project. It is not affiliated with, authorised, sponsored or endorsed by Apple Inc. Product names are used only to identify the products being described.",
      "The museum does not use the Apple logo. Where a name such as Macintosh, iPod or iPhone appears, it refers to the product of that name made by Apple Inc.",
    ],
  },
  {
    id: "images",
    title: "Image credit policy",
    body: [
      "Every image on this site is either our own placeholder artwork, photography we hold the rights to, or material used under a licence that permits it.",
      "Press images are taken only from official press kits (such as Apple Newsroom) and used within the terms those kits set out, typically editorial use with credit. Images from Wikimedia Commons are used only when public domain or under a Creative Commons licence, and are credited with author and licence next to the image or on this page.",
      "We never hotlink images from other sites. If you hold the rights to an image here and want it credited differently or removed, contact us and we will act promptly.",
    ],
  },
  {
    id: "accuracy",
    title: "Content accuracy",
    body: [
      "Dates are first public release dates unless marked as announcement dates. Prices are US launch prices in the currency of the day, not adjusted for inflation.",
      "Each exhibit links its primary source. Where sources disagree, we use the most authoritative available and note the difference. Corrections are welcome through the Visit page.",
    ],
  },
  {
    id: "privacy",
    title: "Privacy",
    body: [
      "The site sets no advertising or tracking cookies. Session storage is used only to remember that you've seen the opening animation.",
      "If you use the contact or newsletter forms, your details are used only to reply to you or to send the letter, and are never sold or shared.",
    ],
  },
];

export default function LegalPage() {
  return (
    <>
      <PageHeader eyebrow="Legal" title="The small print, kept small." />
      <div className="container-museum grid gap-12 pb-32 lg:grid-cols-12">
        <nav aria-label="On this page" className="lg:col-span-3">
          <ul className="space-y-3 lg:sticky lg:top-[calc(var(--header-h)+2rem)]">
            {[...SECTIONS, { id: "credits", title: "Photo credits" }].map((s) => (
              <li key={s.id}>
                <a href={`#${s.id}`} className="micro text-mute hover:text-paper">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="space-y-20 lg:col-span-7 lg:col-start-5">
          {SECTIONS.map((s) => (
            <section key={s.id} id={s.id} aria-labelledby={`${s.id}-title`} className="scroll-mt-[calc(var(--header-h)+2rem)] border-t hairline pt-8">
              <h2 id={`${s.id}-title`} className="display-sm mb-8">
                {s.title}
              </h2>
              <div className="space-y-5 text-lg leading-relaxed text-paper/80">
                {s.body.map((p) => (
                  <p key={p}>{p}</p>
                ))}
              </div>
            </section>
          ))}
          <section id="credits" aria-labelledby="credits-title" className="scroll-mt-[calc(var(--header-h)+2rem)] border-t hairline pt-8">
            <h2 id="credits-title" className="display-sm mb-8">
              Photo credits
            </h2>
            {Object.keys(CREDITS).length === 0 ? (
              <p className="text-lg text-paper/80">All images are currently original placeholder artwork.</p>
            ) : (
              <ul className="divide-y divide-[var(--color-line)] text-sm">
                {Object.entries(CREDITS).map(([path, c]) => (
                  <li key={path} className="grid gap-1 py-3 md:grid-cols-[1fr_auto] md:gap-6">
                    <span className="text-paper/80">
                      {c.artist} — <span className="text-mute">{path.replace("/images/", "")}</span>
                    </span>
                    <a href={c.source} target="_blank" rel="noopener noreferrer" className="text-mute underline underline-offset-4 hover:text-paper">
                      {c.license}, Wikimedia Commons
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <p className="text-sm text-mute">
            Questions? <Link href="/visit" className="underline underline-offset-4 hover:text-paper">Contact the curators</Link>.
          </p>
        </div>
      </div>
    </>
  );
}
