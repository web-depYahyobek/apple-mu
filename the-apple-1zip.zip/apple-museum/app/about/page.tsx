import type { Metadata } from "next";
import { PageHeader } from "@/components/ui/PageHeader";
import { RevealImage } from "@/components/ui/RevealImage";
import { SplitHeadline } from "@/components/ui/SplitHeadline";
import { FadeIn } from "@/components/ui/FadeIn";
import { Button } from "@/components/ui/Button";
import { PAGE_IMAGES } from "@/data/home";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "About",
  description: "Why an independent, fan-made museum of Apple products exists, how we write about them and who keeps it running.",
  alternates: { canonical: "/about" },
  openGraph: { url: "/about", title: "About the museum" },
};

const PRINCIPLES = [
  { title: "Record, don't advertise", body: "We describe what shipped and what it did. Failures stay in the collection. Hype stays out." },
  { title: "Cite everything", body: "Every exhibit links its primary source. When sources disagree, we say so and use the most reliable." },
  { title: "Short sentences", body: "Apple's best products remove what isn't needed. We try to write the same way." },
  { title: "Credit the people", body: "Products are made by teams. Where names are documented, we list them." },
];

const TEAM = [
  { role: "Curator", name: "Your name here" },
  { role: "Research", name: "Contributor name" },
  { role: "Design & development", name: "Contributor name" },
  { role: "Photography", name: "Credited per image" },
];

export default function AboutPage() {
  return (
    <>
      <PageHeader
        eyebrow="About"
        title="Why this museum exists."
        intro="Most of what Apple has made is no longer on sale, and much of it is no longer remembered accurately. This is an attempt to keep the record: calm, complete and sourced."
      />

      <section className="container-museum grid gap-12 pb-24 lg:grid-cols-12" aria-label="Introduction">
        <RevealImage image={PAGE_IMAGES.about} className="aspect-[4/5] lg:col-span-5" sizes="(min-width: 1024px) 40vw, 100vw" />
        <FadeIn stagger className="space-y-6 lg:col-span-6 lg:col-start-7 lg:pt-24">
          <p className="lead text-paper/85">
            We started with a question: what has Apple actually released? Not the highlights. All of it — the computers,
            the software, the services, the accessories, the experiments that disappeared within a year.
          </p>
          <p className="text-mute">
            The archive currently holds {PRODUCTS.length} objects, from the Apple I to this year&apos;s releases. Each
            one has a date, a launch price, the people behind it where they are known, and three short paragraphs on why
            it mattered.
          </p>
          <p className="text-mute">
            The museum is independent and non-commercial. It is not affiliated with, endorsed by or sponsored by Apple
            Inc.
          </p>
        </FadeIn>
      </section>

      <section className="border-t hairline py-24 md:py-32" aria-labelledby="principles-title">
        <div className="container-museum">
          <p className="micro mb-8 text-mute">Editorial principles</p>
          <SplitHeadline id="principles-title" className="display-md mb-16 max-w-[14ch]">
            How we write about objects.
          </SplitHeadline>
          <FadeIn stagger as="ol" className="grid gap-px bg-line md:grid-cols-2">
            {PRINCIPLES.map((p, i) => (
              <li key={p.title} className="bg-ink p-8 md:p-12">
                <span className="counter text-mute">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-6 text-2xl font-medium tracking-[-0.03em]">{p.title}</h3>
                <p className="mt-4 text-mute">{p.body}</p>
              </li>
            ))}
          </FadeIn>
        </div>
      </section>

      <section className="border-t hairline py-24 md:py-32" aria-labelledby="team-title">
        <div className="container-museum grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="micro mb-8 text-mute">Credits</p>
            <h2 id="team-title" className="display-sm">
              A small team, and many sources.
            </h2>
          </div>
          <dl className="lg:col-span-6 lg:col-start-7">
            {TEAM.map((t) => (
              <div key={t.role} className="flex items-baseline justify-between gap-6 border-b hairline py-5">
                <dt className="micro text-mute">{t.role}</dt>
                <dd className="text-lg">{t.name}</dd>
              </div>
            ))}
          </dl>
        </div>
        <div className="container-museum mt-20 flex flex-wrap gap-4">
          <Button href="/visit">Plan your visit</Button>
          <Button href="/legal" variant="text">
            Image credits & legal
          </Button>
        </div>
      </section>
    </>
  );
}
