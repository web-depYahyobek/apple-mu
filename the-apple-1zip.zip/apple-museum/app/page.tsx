import type { Metadata } from "next";
import { HeroCollage } from "@/components/home/HeroCollage";
import { Philosophy } from "@/components/home/Philosophy";
import { PinnedStory } from "@/components/home/PinnedStory";
import { StickyImageList } from "@/components/home/StickyImageList";
import { OrdinaryEnds } from "@/components/home/OrdinaryEnds";
import { TimelinePreview } from "@/components/home/TimelinePreview";
import { CollectionPreview } from "@/components/home/CollectionPreview";
import { ClosingCta } from "@/components/home/ClosingCta";
import { JsonLd } from "@/components/ui/JsonLd";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: { absolute: `${SITE.name} — For those who think different` },
  description: SITE.description,
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Museum",
          name: SITE.name,
          url: SITE.url,
          description: SITE.description,
          isAccessibleForFree: true,
          publicAccess: true,
        }}
      />
      <HeroCollage />
      <Philosophy />
      <PinnedStory />
      <StickyImageList />
      <OrdinaryEnds />
      <TimelinePreview />
      <CollectionPreview />
      <ClosingCta />
    </>
  );
}
