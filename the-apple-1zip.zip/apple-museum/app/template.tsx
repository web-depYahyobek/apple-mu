"use client";

import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";

/**
 * Templates re-mount on every navigation, so this runs a wipe each time a route changes:
 * a black panel covers the screen and retracts upward to reveal the new page.
 */
export default function Template({ children }: { children: ReactNode }) {
  const reduce = useReducedMotion();
  return (
    <>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-[90] origin-top bg-ink"
        initial={reduce ? { opacity: 1 } : { scaleY: 1 }}
        animate={reduce ? { opacity: 0 } : { scaleY: 0 }}
        transition={{ duration: reduce ? 0.25 : 0.9, ease: [0.76, 0, 0.24, 1], delay: reduce ? 0 : 0.05 }}
      >
        <motion.span
          className="absolute inset-x-0 bottom-0 block h-px bg-paper/30"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.6, ease: [0.76, 0, 0.24, 1] }}
        />
      </motion.div>
      {/* Opacity only: a transform here would break position:fixed pins inside the page. */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: reduce ? 0.25 : 0.8, ease: [0.16, 1, 0.3, 1], delay: reduce ? 0 : 0.2 }}
      >
        {children}
      </motion.div>
    </>
  );
}
