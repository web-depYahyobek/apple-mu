import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui/PageHeader";
import { NAV } from "@/lib/site";
import { CATEGORIES } from "@/data/types";
import { getProductsByCategory } from "@/data/products";
import { ERAS } from "@/data/eras";

export const metadata: Metadata = {
  title: "Sitemap",
  description: "Every page and every exhibit in the Apple Museum.",
  alternates: { canonical: "/sitemap" },
};

export default function SitemapPage() {
  return (
    <>
      <PageHeader eyebrow="Sitemap" title="Every room in the building." />
      <div className="container-museum grid gap-16 pb-32 md:grid-cols-12">
        <section className="md:col-span-3" aria-labelledby="pages-title">
          <h2 id="pages-title" className="micro mb-6 text-mute">
            Pages
          </h2>
          <ul className="space-y-3">
            {[...NAV, { label: "Legal", href: "/legal" }, { label: "Sitemap", href: "/sitemap" }].map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-lg hover:underline hover:underline-offset-4">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <h2 className="micro mb-6 mt-14 text-mute">Eras</h2>
          <ul className="space-y-3">
            {ERAS.map((e) => (
              <li key={e.slug}>
                <Link href={`/eras#${e.slug}`} className="hover:underline hover:underline-offset-4">
                  {e.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section className="md:col-span-9" aria-labelledby="exhibits-title">
          <h2 id="exhibits-title" className="micro mb-6 text-mute">
            Exhibits by category
          </h2>
          <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((c) => {
              const items = getProductsByCategory(c);
              if (!items.length) return null;
              return (
                <div key={c}>
                  <h3 className="mb-4 border-b hairline pb-3 text-lg font-medium">{c}</h3>
                  <ul className="space-y-2">
                    {items.map((p) => (
                      <li key={p.slug} className="flex items-baseline justify-between gap-4 text-sm">
                        <Link href={`/collection/${p.slug}`} className="text-paper/85 hover:text-paper hover:underline hover:underline-offset-4">
                          {p.name}
                        </Link>
                        <span className="counter text-mute">{p.year}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </>
  );
}
