import { PRODUCTS } from "@/data/products";
import { absoluteUrl } from "@/lib/site";

/**
 * sitemap.xml as a route handler. (The human-readable sitemap lives at /sitemap,
 * so the metadata-file convention `app/sitemap.ts` would collide with it.)
 */
export const dynamic = "force-static";

const STATIC_ROUTES: Array<{ path: string; priority: number; changefreq: string }> = [
  { path: "/", priority: 1, changefreq: "weekly" },
  { path: "/timeline", priority: 0.9, changefreq: "weekly" },
  { path: "/collection", priority: 0.9, changefreq: "weekly" },
  { path: "/eras", priority: 0.8, changefreq: "monthly" },
  { path: "/software", priority: 0.8, changefreq: "monthly" },
  { path: "/about", priority: 0.5, changefreq: "yearly" },
  { path: "/visit", priority: 0.5, changefreq: "yearly" },
  { path: "/legal", priority: 0.2, changefreq: "yearly" },
  { path: "/sitemap", priority: 0.2, changefreq: "monthly" },
];

export function GET() {
  const now = new Date().toISOString();
  const urls = [
    ...STATIC_ROUTES.map((r) => ({ loc: absoluteUrl(r.path), priority: r.priority, changefreq: r.changefreq })),
    ...PRODUCTS.map((p) => ({ loc: absoluteUrl(`/collection/${p.slug}`), priority: 0.7, changefreq: "monthly" })),
  ];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (u) => `  <url>
    <loc>${u.loc}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority.toFixed(1)}</priority>
  </url>`,
  )
  .join("\n")}
</urlset>
`;

  return new Response(xml, { headers: { "Content-Type": "application/xml; charset=utf-8" } });
}
