import type { Metadata } from "next";
import { PageHeader } from "@/components/ui/PageHeader";
import { Timeline } from "@/components/timeline/Timeline";
import { JsonLd } from "@/components/ui/JsonLd";
import { groupByYear, PRODUCTS_BY_DATE } from "@/data/products";
import { absoluteUrl } from "@/lib/site";

export const metadata: Metadata = {
  title: "Timeline, 1976 to Today",
  description: "Every Apple release, year by year: hardware, software, services and accessories, with launch dates, prices and the story behind each one.",
  alternates: { canonical: "/timeline" },
  openGraph: { url: "/timeline", title: "Timeline, 1976 to Today" },
};

export default function TimelinePage() {
  const groups = groupByYear();
  const first = groups[0]?.year;
  const last = groups[groups.length - 1]?.year;

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: "Apple product timeline",
          numberOfItems: PRODUCTS_BY_DATE.length,
          itemListElement: PRODUCTS_BY_DATE.map((p, i) => ({
            "@type": "ListItem",
            position: i + 1,
            url: absoluteUrl(`/collection/${p.slug}`),
            name: `${p.name} (${p.year})`,
          })),
        }}
      />
      <PageHeader
        eyebrow="The Timeline"
        counter={`${first} — ${last}`}
        title="Fifty years, one at a time."
        intro="Scroll through every release in the archive. The year on the left rolls forward as you go; filter by decade to jump straight in."
      />
      <Timeline groups={groups} />
    </>
  );
}
