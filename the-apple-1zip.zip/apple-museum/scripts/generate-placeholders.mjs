#!/usr/bin/env node
/**
 * Generates tasteful placeholder images for every path the site references.
 *
 *   npm run images            # create missing placeholders only
 *   npm run images -- --force # regenerate everything
 *
 * It reads the data files with simple pattern matching (no TS build step needed),
 * draws an SVG "studio shot" per image — dark floor, era-tinted glow, a generic
 * product silhouette — and writes a JPEG with sharp.
 *
 * Replace any file with licensed photography using the same filename. See README → Images.
 */
import { mkdir, readFile, access } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const OUT = join(ROOT, "public");
const FORCE = process.argv.includes("--force");

const read = (p) => readFile(join(ROOT, p), "utf8");
const exists = (p) => access(p).then(() => true, () => false);

/* ------------------------------------------------------------------ data */

const productsSrc = await read("data/products.ts");
const erasSrc = await read("data/eras.ts");
const homeSrc = await read("data/home.ts");
const softwareSrc = await read("data/software.ts");

const ERA_ACCENT = {};
for (const m of erasSrc.matchAll(/slug: "([a-z-]+)",[\s\S]*?accent: "(\d+ \d+ \d+)"/g)) ERA_ACCENT[m[1]] = m[2];

const PRODUCTS = [];
for (const block of productsSrc.split(/\n\s*p\(\{/).slice(1)) {
  const get = (k) => block.match(new RegExp(`\\b${k}: "([^"]+)"`))?.[1];
  const slug = get("slug");
  if (!slug) continue;
  PRODUCTS.push({
    slug,
    name: get("name"),
    category: get("category"),
    year: (get("releaseDate") ?? "").slice(0, 4),
    era: get("era"),
  });
}

const OS = [];
for (const m of softwareSrc.matchAll(/v\("([a-z]+)", "([a-z0-9-]+)", "([^"]+)", (\d{4})/g)) {
  OS.push({ family: m[1], slug: m[2], name: m[3], year: Number(m[4]) });
}

const EXPLICIT = [...new Set([...homeSrc.matchAll(/"(\/images\/[^"]+\.jpg)"/g), ...erasSrc.matchAll(/"(\/images\/[^"]+\.jpg)"/g)].map((m) => m[1]))];

/* --------------------------------------------------------------- drawing */

const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const rgb = (triplet, a = 1) => `rgba(${triplet.split(" ").join(",")},${a})`;

const BODY = `url(#body)`;
const EDGE = `rgba(255,255,255,0.22)`;

/** Generic silhouettes, drawn in a 1000 × 1000 box centred on (500, 560). Not product logos. */
function silhouette(kind) {
  switch (kind) {
    case "board":
      return `<rect x="170" y="330" width="660" height="440" rx="10" fill="#1d2a1f" stroke="${EDGE}"/>
        ${Array.from({ length: 12 }, (_, i) => `<rect x="${220 + (i % 6) * 100}" y="${380 + Math.floor(i / 6) * 150}" width="60" height="90" rx="4" fill="#111"/>`).join("")}
        ${Array.from({ length: 8 }, (_, i) => `<line x1="200" y1="${350 + i * 52}" x2="800" y2="${350 + i * 52}" stroke="rgba(214,168,112,0.25)" stroke-width="2"/>`).join("")}`;
    case "classic":
      return `<rect x="260" y="300" width="480" height="300" rx="18" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="300" y="335" width="400" height="230" rx="8" fill="#0a0a0a"/>
        <path d="M200 650 L800 650 L760 760 L240 760 Z" fill="${BODY}" stroke="${EDGE}"/>`;
    case "compact":
      return `<rect x="330" y="250" width="340" height="460" rx="26" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="370" y="295" width="260" height="200" rx="8" fill="#0a0a0a"/>
        <rect x="560" y="560" width="70" height="10" rx="5" fill="#0d0d0d"/>
        <rect x="350" y="710" width="300" height="40" rx="10" fill="${BODY}"/>`;
    case "desktop":
      return `<rect x="200" y="250" width="600" height="400" rx="22" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="225" y="275" width="550" height="320" rx="6" fill="#0a0a0a"/>
        <path d="M455 650 L545 650 L565 760 L435 760 Z" fill="${BODY}"/>
        <rect x="380" y="755" width="240" height="14" rx="7" fill="${BODY}" stroke="${EDGE}"/>`;
    case "translucent":
      return `<path d="M260 270 Q500 210 740 270 L760 640 Q500 720 240 640 Z" fill="rgba(70,170,190,0.35)" stroke="rgba(200,240,255,0.4)"/>
        <rect x="320" y="310" width="360" height="270" rx="10" fill="#0a0a0a"/>
        <rect x="380" y="700" width="240" height="40" rx="12" fill="rgba(70,170,190,0.3)"/>`;
    case "laptop":
      return `<rect x="240" y="300" width="520" height="340" rx="18" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="262" y="322" width="476" height="296" rx="6" fill="#0a0a0a"/>
        <path d="M170 650 L830 650 L800 690 L200 690 Z" fill="${BODY}" stroke="${EDGE}"/>`;
    case "box":
      return `<rect x="290" y="560" width="420" height="120" rx="28" fill="${BODY}" stroke="${EDGE}"/>
        <circle cx="500" cy="620" r="10" fill="rgba(255,255,255,0.15)"/>`;
    case "tower":
      return `<rect x="330" y="360" width="340" height="340" rx="40" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="370" y="620" width="80" height="12" rx="6" fill="#0d0d0d"/>`;
    case "cube":
      return `<rect x="300" y="240" width="400" height="500" rx="16" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.35)"/>
        <rect x="350" y="320" width="300" height="300" rx="12" fill="${BODY}" stroke="${EDGE}"/>`;
    case "chip":
      return `<rect x="310" y="330" width="380" height="380" rx="30" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="370" y="390" width="260" height="260" rx="14" fill="#1b1b1d" stroke="rgba(255,255,255,0.12)"/>
        ${Array.from({ length: 9 }, (_, i) => `<rect x="${330 + i * 40}" y="300" width="14" height="24" fill="#444"/><rect x="${330 + i * 40}" y="716" width="14" height="24" fill="#444"/>`).join("")}`;
    case "handheld":
      return `<rect x="380" y="270" width="240" height="420" rx="28" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="405" y="300" width="190" height="270" rx="4" fill="#3a4038"/>`;
    case "clamshell":
      return `<path d="M250 600 Q500 520 750 600 L730 720 Q500 770 270 720 Z" fill="rgba(90,170,120,0.35)" stroke="rgba(200,255,220,0.4)"/>
        <path d="M290 330 L710 330 L720 590 L280 590 Z" fill="rgba(90,170,120,0.25)" stroke="rgba(200,255,220,0.35)"/>
        <rect x="330" y="370" width="340" height="190" fill="#2f362f"/>`;
    case "player":
      return `<rect x="390" y="250" width="220" height="380" rx="30" fill="#e9e9ec" stroke="rgba(255,255,255,0.5)"/>
        <rect x="415" y="280" width="170" height="125" rx="6" fill="#9aa3a0"/>
        <circle cx="500" cy="520" r="72" fill="#d6d6da"/><circle cx="500" cy="520" r="26" fill="#e9e9ec"/>`;
    case "stick":
      return `<rect x="455" y="400" width="90" height="230" rx="16" fill="#ececef"/>
        <circle cx="500" cy="480" r="28" fill="#d0d0d4"/>`;
    case "phone":
      return `<rect x="395" y="230" width="210" height="430" rx="38" fill="#141416" stroke="${EDGE}"/>
        <rect x="410" y="250" width="180" height="390" rx="28" fill="#060606"/>`;
    case "fold":
      return `<rect x="300" y="250" width="200" height="420" rx="30" fill="#141416" stroke="${EDGE}"/>
        <rect x="500" y="250" width="200" height="420" rx="30" fill="#141416" stroke="${EDGE}"/>
        <rect x="314" y="266" width="372" height="388" rx="20" fill="#060606"/>
        <line x1="500" y1="262" x2="500" y2="658" stroke="rgba(255,255,255,0.08)" stroke-width="2"/>`;
    case "tablet":
      return `<rect x="290" y="220" width="420" height="560" rx="34" fill="#141416" stroke="${EDGE}"/>
        <rect x="310" y="240" width="380" height="520" rx="22" fill="#060606"/>`;
    case "watch":
      return `<rect x="455" y="190" width="90" height="140" rx="20" fill="#2a2a2c"/><rect x="455" y="640" width="90" height="160" rx="20" fill="#2a2a2c"/>
        <rect x="395" y="320" width="210" height="260" rx="52" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="415" y="340" width="170" height="220" rx="40" fill="#060606"/>
        <rect x="604" y="400" width="14" height="44" rx="6" fill="#555"/>`;
    case "earbuds":
      return `<rect x="390" y="560" width="220" height="160" rx="64" fill="#efeff2"/>
        <line x1="392" y1="622" x2="608" y2="622" stroke="#cfcfd4" stroke-width="3"/>
        <circle cx="290" cy="520" r="40" fill="#f4f4f6"/><rect x="296" y="520" width="26" height="150" rx="13" fill="#f4f4f6"/>
        <circle cx="710" cy="520" r="40" fill="#f4f4f6"/><rect x="678" y="520" width="26" height="150" rx="13" fill="#f4f4f6"/>`;
    case "headphones":
      return `<path d="M330 560 Q330 270 500 270 Q670 270 670 560" fill="none" stroke="#bdbdc2" stroke-width="26" stroke-linecap="round"/>
        <rect x="280" y="500" width="120" height="190" rx="50" fill="${BODY}" stroke="${EDGE}"/>
        <rect x="600" y="500" width="120" height="190" rx="50" fill="${BODY}" stroke="${EDGE}"/>`;
    case "speaker":
      return `<rect x="380" y="330" width="240" height="380" rx="110" fill="#3a3a3e" stroke="${EDGE}"/>
        ${Array.from({ length: 14 }, (_, i) => `<line x1="392" y1="${360 + i * 24}" x2="608" y2="${360 + i * 24}" stroke="rgba(255,255,255,0.05)"/>`).join("")}
        <ellipse cx="500" cy="345" rx="70" ry="14" fill="rgba(255,255,255,0.12)"/>`;
    case "visor":
      return `<path d="M230 470 Q240 350 500 345 Q760 350 770 470 Q770 610 640 615 Q560 618 520 580 Q500 565 480 580 Q440 618 360 615 Q230 610 230 470 Z" fill="#101012" stroke="rgba(255,255,255,0.35)"/>
        <path d="M260 470 Q270 380 500 375 Q730 380 740 470" fill="none" stroke="${rgb("170 160 220", 0.5)}" stroke-width="3"/>
        <path d="M770 470 Q860 480 860 560" fill="none" stroke="#2c2c2e" stroke-width="40" stroke-linecap="round"/>`;
    case "window":
      return `<rect x="200" y="280" width="600" height="420" rx="16" fill="#1a1a1c" stroke="${EDGE}"/>
        <rect x="200" y="280" width="600" height="44" rx="16" fill="#2a2a2d"/>
        <circle cx="236" cy="302" r="8" fill="#5a5a5e"/><circle cx="262" cy="302" r="8" fill="#5a5a5e"/><circle cx="288" cy="302" r="8" fill="#5a5a5e"/>
        ${Array.from({ length: 6 }, (_, i) => `<rect x="240" y="${360 + i * 50}" width="${520 - (i % 3) * 120}" height="14" rx="7" fill="rgba(255,255,255,${0.12 - i * 0.012})"/>`).join("")}`;
    case "service":
      return `<circle cx="500" cy="500" r="170" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="3"/>
        <circle cx="500" cy="500" r="110" fill="${BODY}" stroke="${EDGE}"/>
        <path d="M440 520 Q500 420 560 520" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="6" stroke-linecap="round"/>`;
    case "mouse":
      return `<ellipse cx="500" cy="560" rx="120" ry="190" fill="#ececef" stroke="rgba(255,255,255,0.6)"/>`;
    case "pencil":
      return `<rect x="200" y="550" width="600" height="34" rx="17" fill="#f1f1f3"/><path d="M800 550 L860 567 L800 584 Z" fill="#d8d8dc"/>`;
    case "disc":
      return `<circle cx="500" cy="600" r="120" fill="#f0f0f2"/><circle cx="500" cy="600" r="90" fill="none" stroke="#d6d6da" stroke-width="3"/>`;
    case "dome":
      return `<path d="M300 660 Q300 430 500 420 Q700 430 700 660 Z" fill="#d9dadd" stroke="rgba(255,255,255,0.5)"/><ellipse cx="500" cy="660" rx="200" ry="22" fill="#bfc0c4"/>`;
    case "group":
      return `<g transform="translate(-170 40) scale(0.8)">${silhouette("phone")}</g><g transform="translate(180 120) scale(0.7)">${silhouette("watch")}</g><g transform="translate(40 300) scale(0.6)">${silhouette("earbuds")}</g>`;
    default:
      return `<rect x="330" y="330" width="340" height="340" rx="40" fill="${BODY}" stroke="${EDGE}"/>`;
  }
}

function kindFor(p) {
  const s = p.slug;
  if (s === "apple-i") return "board";
  if (["apple-ii", "apple-iii"].includes(s)) return "classic";
  if (s === "lisa" || s === "macintosh-128k") return "compact";
  if (s === "newton-messagepad") return "handheld";
  if (s === "emate-300") return "clamshell";
  if (s === "imac-g3") return "translucent";
  if (/macbook|powerbook|ibook|portable/.test(s)) return "laptop";
  if (s === "power-mac-g4-cube") return "cube";
  if (s === "apple-m1") return "chip";
  if (s === "mac-mini") return "box";
  if (s === "mac-studio" || s === "power-macintosh-6100") return "tower";
  if (s === "ipod-shuffle") return "stick";
  if (s === "iphone-duo") return "fold";
  if (s === "airpods-max") return "headphones";
  if (s === "homepod") return "speaker";
  if (s === "apple-tv") return "box";
  if (s === "magic-mouse") return "mouse";
  if (s === "apple-pencil") return "pencil";
  if (s === "airtag") return "disc";
  if (s === "airport-base-station") return "dome";
  switch (p.category) {
    case "Mac": return "desktop";
    case "iPod": return "player";
    case "iPhone": return "phone";
    case "iPad": return "tablet";
    case "Watch": return "watch";
    case "Audio": return "earbuds";
    case "TV/Home": return "box";
    case "Vision": return "visor";
    case "Software": return "window";
    case "Services": return "service";
    default: return "classic";
  }
}

function defs(accent) {
  return `<defs>
    <radialGradient id="glow" cx="50%" cy="38%" r="60%"><stop offset="0" stop-color="${rgb(accent, 0.32)}"/><stop offset="0.55" stop-color="${rgb(accent, 0.06)}"/><stop offset="1" stop-color="rgba(0,0,0,0)"/></radialGradient>
    <linearGradient id="floor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#121214"/><stop offset="1" stop-color="#070707"/></linearGradient>
    <linearGradient id="body" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a3a3d"/><stop offset="0.5" stop-color="#1f1f22"/><stop offset="1" stop-color="#121214"/></linearGradient>
    <linearGradient id="fade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0.35"/><stop offset="0.6" stop-color="#000" stop-opacity="1"/></linearGradient>
    <filter id="soft"><feGaussianBlur stdDeviation="6"/></filter>
  </defs>`;
}

/** A studio shot: backdrop, glow, floor, object, reflection. `t` is a transform for the object group. */
function studio({ w, h, accent, art, t = "", label, file }) {
  const floorY = h * 0.72;
  const s = Math.min(w, h) / 1000;
  const ox = (w - 1000 * s) / 2;
  const oy = floorY - 780 * s;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
    ${defs(accent)}
    <rect width="${w}" height="${h}" fill="#0c0c0c"/>
    <rect width="${w}" height="${h}" fill="url(#glow)"/>
    <rect y="${floorY}" width="${w}" height="${h - floorY}" fill="url(#floor)"/>
    <line x1="0" y1="${floorY}" x2="${w}" y2="${floorY}" stroke="rgba(255,255,255,0.05)"/>
    <ellipse cx="${w / 2}" cy="${floorY + 6}" rx="${w * 0.28}" ry="${h * 0.02}" fill="rgba(0,0,0,0.7)" filter="url(#soft)"/>
    <g transform="translate(${ox} ${oy}) scale(${s}) ${t}">${art}</g>
    <g opacity="0.16" transform="translate(${ox} ${floorY * 2 - oy}) scale(${s} ${-s}) ${t}">${art}</g>
    <rect y="${floorY}" width="${w}" height="${h - floorY}" fill="url(#fade)" opacity="0.55"/>
    ${caption(w, h, label, file)}
  </svg>`;
}

function caption(w, h, label, file) {
  const fs = Math.max(14, Math.round(Math.min(w, h) * 0.022));
  return `<g font-family="Inter, 'Helvetica Neue', Arial, sans-serif" fill="rgba(245,245,247,0.55)">
    <text x="${fs * 2}" y="${h - fs * 3.4}" font-size="${fs * 0.7}" letter-spacing="${fs * 0.18}">PLACEHOLDER</text>
    <text x="${fs * 2}" y="${h - fs * 2}" font-size="${fs}" fill="rgba(245,245,247,0.8)">${esc(label)}</text>
    <text x="${w - fs * 2}" y="${h - fs * 2}" font-size="${fs * 0.7}" text-anchor="end">${esc(file)}</text>
  </g>`;
}

/** Abstract scenes for non-product images. */
function scene(name, w, h, accent, label, file) {
  const base = `<rect width="${w}" height="${h}" fill="#0c0c0c"/><rect width="${w}" height="${h}" fill="url(#glow)"/>`;
  let body = "";
  if (name === "aluminium") {
    body = Array.from({ length: 60 }, (_, i) => `<line x1="${-h + i * (w + h) / 60}" y1="${h}" x2="${i * (w + h) / 60}" y2="0" stroke="rgba(255,255,255,${0.02 + (i % 5) * 0.008})" stroke-width="${2 + (i % 3)}"/>`).join("") +
      `<path d="M0 ${h * 0.62} Q${w * 0.5} ${h * 0.5} ${w} ${h * 0.3} L${w} ${h} L0 ${h} Z" fill="url(#body)" opacity="0.9"/>
       <path d="M0 ${h * 0.62} Q${w * 0.5} ${h * 0.5} ${w} ${h * 0.3}" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="3"/>
       <path d="M${w * 0.1} ${h * 0.85} L${w * 0.45} ${h * 0.85} L${w * 0.55} ${h * 0.75} L${w * 0.9} ${h * 0.75}" fill="none" stroke="${rgb(accent, 0.5)}" stroke-width="4"/>`;
  } else if (name === "circuit") {
    body = Array.from({ length: 24 }, (_, i) => `<rect x="${(i % 6) * w / 6 + w * 0.04}" y="${Math.floor(i / 6) * h / 4 + h * 0.06}" width="${w / 10}" height="${h / 9}" rx="6" fill="#141414" stroke="rgba(255,255,255,0.08)"/>`).join("") +
      Array.from({ length: 18 }, (_, i) => `<path d="M0 ${h * (0.05 + i * 0.055)} H${w * (0.3 + (i % 4) * 0.15)} V${h * (0.08 + i * 0.05)} H${w}" fill="none" stroke="${rgb(accent, 0.18)}" stroke-width="2"/>`).join("");
  } else if (name === "glass") {
    body = Array.from({ length: 7 }, (_, i) => `<ellipse cx="${w * 0.5}" cy="${h * 1.1}" rx="${w * (0.3 + i * 0.12)}" ry="${h * (0.5 + i * 0.12)}" fill="none" stroke="${rgb(accent, 0.25 - i * 0.03)}" stroke-width="${3 + i}"/>`).join("");
  } else if (name === "row") {
    const kinds = ["board", "compact", "laptop", "translucent", "player", "phone", "tablet", "watch", "visor"];
    body = `<rect y="${h * 0.7}" width="${w}" height="${h * 0.3}" fill="url(#floor)"/>` +
      kinds.map((k, i) => {
        const sc = 0.12 + i * 0.03;
        const x = w * 0.04 + i * (w * 0.105);
        return `<g transform="translate(${x} ${h * 0.7 - 780 * sc}) scale(${sc})" opacity="${0.4 + i * 0.07}">${silhouette(k)}</g>`;
      }).join("");
  } else if (name === "shelves") {
    body = Array.from({ length: 4 }, (_, r) => `<line x1="0" y1="${h * (0.28 + r * 0.2)}" x2="${w}" y2="${h * (0.28 + r * 0.2)}" stroke="rgba(255,255,255,0.08)" stroke-width="3"/>` +
      Array.from({ length: 9 }, (_, c) => `<rect x="${w * 0.04 + c * w * 0.107}" y="${h * (0.14 + r * 0.2)}" width="${w * 0.07}" height="${h * 0.13}" rx="10" fill="url(#body)" opacity="${0.35 + ((r + c) % 4) * 0.15}"/>`).join("")).join("");
  } else if (name === "plinth") {
    body = `<path d="M${w * 0.42} 0 L${w * 0.58} 0 L${w * 0.72} ${h * 0.75} L${w * 0.28} ${h * 0.75} Z" fill="${rgb(accent, 0.06)}"/>
      <rect y="${h * 0.75}" width="${w}" height="${h * 0.25}" fill="url(#floor)"/>
      <rect x="${w * 0.4}" y="${h * 0.5}" width="${w * 0.2}" height="${h * 0.25}" fill="url(#body)" stroke="rgba(255,255,255,0.12)"/>
      <rect x="${w * 0.4}" y="${h * 0.5}" width="${w * 0.2}" height="4" fill="rgba(255,255,255,0.3)"/>`;
  } else if (name === "corridor") {
    body = Array.from({ length: 10 }, (_, i) => {
      const k = i / 10;
      return `<rect x="${w * (0.5 - 0.5 * (1 - k))}" y="${h * (0.5 - 0.5 * (1 - k))}" width="${w * (1 - k)}" height="${h * (1 - k)}" fill="none" stroke="rgba(255,255,255,${0.04 + k * 0.05})"/>`;
    }).join("") + `<rect x="${w * 0.47}" y="${h * 0.47}" width="${w * 0.06}" height="${h * 0.06}" fill="${rgb(accent, 0.4)}"/>`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${defs(accent)}${base}${body}${caption(w, h, label, file)}</svg>`;
}

/** Software screenshot placeholders, styled loosely by decade (no real UI). */
function ui(os, w, h, file) {
  const y = os.year;
  const mobile = ["ios", "ipados", "watchos"].includes(os.family);
  const vision = os.family === "visionos";
  const palette =
    y < 1997 ? { bg: "#bdbdbd", bar: "#ffffff", win: "#ffffff", ink: "#000000", acc: "#000000" } :
    y < 2001 ? { bg: "#6f7b8f", bar: "#dddddd", win: "#e8e8e8", ink: "#222222", acc: "#4a5a8a" } :
    y < 2013 ? { bg: "#2a4a7a", bar: "#e8e8e8", win: "#f2f2f2", ink: "#333333", acc: "#3d8be0" } :
    y < 2025 ? { bg: "#2c3e50", bar: "rgba(255,255,255,0.75)", win: "rgba(255,255,255,0.9)", ink: "#1d1d1f", acc: "#0a84ff" } :
               { bg: "#3b3552", bar: "rgba(255,255,255,0.35)", win: "rgba(255,255,255,0.28)", ink: "#ffffff", acc: "#9fa8ff" };
  const fs = Math.round(h * 0.05);
  let content = "";
  if (mobile) {
    const pw = os.family === "watchos" ? h * 0.45 : os.family === "ipados" ? h * 0.62 : h * 0.4;
    const ph = os.family === "watchos" ? h * 0.55 : os.family === "ipados" ? h * 0.8 : h * 0.82;
    const px = (w - pw) / 2, py = (h - ph) / 2;
    const cols = os.family === "ipados" ? 6 : os.family === "watchos" ? 3 : 4;
    const icon = pw / (cols * 1.6);
    content = `<rect x="${px - 10}" y="${py - 10}" width="${pw + 20}" height="${ph + 20}" rx="${pw * 0.14}" fill="#111"/>
      <rect x="${px}" y="${py}" width="${pw}" height="${ph}" rx="${pw * 0.12}" fill="${palette.bg}"/>` +
      Array.from({ length: cols * (os.family === "watchos" ? 3 : 5) }, (_, i) => {
        const cx = px + pw * 0.12 + (i % cols) * (pw * 0.76) / (cols - 1) - icon / 2;
        const cy = py + ph * 0.12 + Math.floor(i / cols) * icon * 1.7;
        const r = y < 2013 ? icon * 0.18 : os.family === "watchos" ? icon / 2 : icon * 0.24;
        return `<rect x="${cx}" y="${cy}" width="${icon}" height="${icon}" rx="${r}" fill="${palette.win}" opacity="${0.55 + (i % 4) * 0.1}"/>`;
      }).join("");
  } else if (vision) {
    content = `<rect width="${w}" height="${h}" fill="#2b2f36"/>
      <rect x="${w * 0.18}" y="${h * 0.2}" width="${w * 0.64}" height="${h * 0.5}" rx="${h * 0.04}" fill="rgba(255,255,255,0.18)" stroke="rgba(255,255,255,0.4)"/>
      <rect x="${w * 0.4}" y="${h * 0.74}" width="${w * 0.2}" height="${h * 0.012}" rx="${h * 0.006}" fill="rgba(255,255,255,0.6)"/>`;
  } else {
    content = `<rect width="${w}" height="${h * 0.05}" fill="${palette.bar}"/>
      <rect x="${w * 0.14}" y="${h * 0.16}" width="${w * 0.56}" height="${h * 0.56}" rx="${y < 2001 ? 0 : h * 0.015}" fill="${palette.win}" stroke="${palette.ink}" stroke-opacity="0.3"/>
      <rect x="${w * 0.14}" y="${h * 0.16}" width="${w * 0.56}" height="${h * 0.05}" fill="${palette.acc}" opacity="${y < 1997 ? 0.15 : 0.35}"/>
      <rect x="${w * 0.4}" y="${h * 0.34}" width="${w * 0.48}" height="${h * 0.44}" rx="${y < 2001 ? 0 : h * 0.015}" fill="${palette.win}" stroke="${palette.ink}" stroke-opacity="0.3"/>
      ${y >= 2001 ? `<rect x="${w * 0.25}" y="${h * 0.88}" width="${w * 0.5}" height="${h * 0.08}" rx="${h * 0.02}" fill="${palette.bar}"/>` : ""}`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
    <rect width="${w}" height="${h}" fill="${palette.bg}"/>${content}
    <g font-family="Inter, 'Helvetica Neue', Arial, sans-serif">
      <rect x="${fs * 0.8}" y="${h - fs * 2.6}" width="${fs * 0.6 * (os.name.length + 6)}" height="${fs * 1.8}" fill="rgba(0,0,0,0.55)"/>
      <text x="${fs * 1.2}" y="${h - fs * 1.35}" font-size="${fs * 0.9}" fill="#fff">${esc(os.name)} · ${os.year}</text>
      <text x="${w - fs}" y="${fs * 1.6}" font-size="${fs * 0.5}" text-anchor="end" fill="rgba(255,255,255,0.7)">PLACEHOLDER · ${esc(file)}</text>
    </g>
  </svg>`;
}

/* ------------------------------------------------------------------ jobs */

const jobs = [];
const add = (path, w, h, svg) => jobs.push({ path, w, h, svg });

for (const p of PRODUCTS) {
  const accent = ERA_ACCENT[p.era] ?? "232 236 242";
  const art = silhouette(kindFor(p));
  const label = `${p.name} · ${p.year}`;
  const dir = `/images/products/${p.slug}`;
  add(`${dir}/hero.jpg`, 1000, 1250, () => studio({ w: 1000, h: 1250, accent, art, label, file: `${dir}/hero.jpg` }));
  const variants = [
    "translate(60 0) rotate(-8 500 560)",
    "translate(-1000 -1100) scale(3)",
    "translate(-450 -420) scale(1.9)",
    "translate(150 140) scale(0.7)",
  ];
  variants.forEach((t, i) => {
    const f = `${dir}/detail-${i + 1}.jpg`;
    add(f, 1400, 1050, () => studio({ w: 1400, h: 1050, accent, art, t, label: `${p.name} · detail ${i + 1}`, file: f }));
  });
}

const ERA_KIND = { garage: "board", macintosh: "compact", wilderness: "laptop", return: "translucent", ipod: "player", iphone: "phone", ecosystem: "group", silicon: "chip", spatial: "visor" };
const EXHIBIT_KIND = { mac: "desktop", ipod: "player", iphone: "phone", ipad: "tablet", watch: "watch", audio: "earbuds", vision: "visor", software: "window" };
const ORDINARY_KIND = ["desktop", "phone", "visor"];

for (const path of EXPLICIT) {
  const file = path;
  const name = path.split("/").pop().replace(".jpg", "");
  if (path.includes("/eras/")) {
    const accent = ERA_ACCENT[name] ?? "232 236 242";
    add(path, 1920, 1200, () => studio({ w: 1920, h: 1200, accent, art: silhouette(ERA_KIND[name]), label: `Era · ${name}`, file }));
  } else if (path.includes("/exhibits/")) {
    add(path, 1400, 1750, () => studio({ w: 1400, h: 1750, accent: "232 236 242", art: silhouette(EXHIBIT_KIND[name]), label: `Exhibit · ${name}`, file }));
  } else if (name.startsWith("ordinary-")) {
    const i = Number(name.split("-")[1]) - 1;
    add(path, 900, 1500, () => studio({ w: 900, h: 1500, accent: ["226 220 206", "150 160 175", "170 160 220"][i], art: silhouette(ORDINARY_KIND[i]), label: `Portrait ${i + 1}`, file }));
  } else if (name === "story-vision") add(path, 1920, 1440, () => scene("circuit", 1920, 1440, "214 168 112", "Vision · circuit board", file));
  else if (name === "story-craft") add(path, 1920, 1440, () => scene("aluminium", 1920, 1440, "70 170 190", "Craft · milled aluminium", file));
  else if (name === "story-legacy") add(path, 1920, 1440, () => scene("glass", 1920, 1440, "170 160 220", "Legacy · curved glass", file));
  else if (name === "philosophy-macro") add(path, 1400, 1750, () => scene("aluminium", 1400, 1750, "232 236 242", "Macro · unibody and trace", file));
  else if (name === "timeline-hero") add(path, 2400, 1350, () => scene("row", 2400, 1350, "200 200 210", "Timeline · 1976 to today", file));
  else if (name === "collection-hero") add(path, 2400, 1350, () => scene("shelves", 2400, 1350, "190 170 150", "Collection · the archive", file));
  else if (name === "cta") add(path, 2400, 1350, () => scene("plinth", 2400, 1350, "232 236 242", "An empty plinth", file));
  else if (name === "about") add(path, 1200, 1500, () => scene("plinth", 1200, 1500, "214 168 112", "Reading room", file));
  else if (name === "visit") add(path, 1920, 1440, () => scene("corridor", 1920, 1440, "232 236 242", "Gallery corridor", file));
  else add(path, 1600, 1200, () => scene("glass", 1600, 1200, "232 236 242", name, file));
}

for (const os of OS) {
  const path = `/images/software/${os.family}-${os.slug}.jpg`;
  add(path, 1600, 1000, () => ui(os, 1600, 1000, path));
}

/* ------------------------------------------------------------------- run */

let made = 0;
let skipped = 0;
for (const job of jobs) {
  const target = join(OUT, job.path);
  if (!FORCE && (await exists(target))) {
    skipped++;
    continue;
  }
  await mkdir(dirname(target), { recursive: true });
  await sharp(Buffer.from(job.svg())).jpeg({ quality: 72, progressive: true, mozjpeg: true }).toFile(target);
  made++;
}

console.log(`Placeholders: ${made} written, ${skipped} already present, ${jobs.length} referenced.`);
console.log(`Products: ${PRODUCTS.length}, OS versions: ${OS.length}, page images: ${EXPLICIT.length}.`);
