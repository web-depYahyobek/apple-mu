#!/usr/bin/env node
/**
 * Downloads REAL photographs of every product from Wikimedia Commons,
 * using only freely licensed files (public domain, CC0, CC BY, CC BY-SA).
 *
 *   npm run images:real              # all products
 *   npm run images:real -- ipod imac-g3   # only these slugs
 *
 * For each product it reads the product's English Wikipedia article, takes the
 * article's lead image plus other photos used in the article, keeps only files
 * hosted on Commons under a free licence, and saves them over the placeholders:
 *   public/images/products/<slug>/hero.jpg, detail-1.jpg … detail-4.jpg
 * Credits (author, licence, source) are written to data/image-credits.json and
 * shown on the product page and on /legal. Home and era images are then filled
 * from the matching products.
 *
 * Requires internet access and Node 18+. Safe to re-run.
 */
import { mkdir, readFile, writeFile, copyFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const PUBLIC = join(ROOT, "public");
const CREDITS_FILE = join(ROOT, "data/image-credits.json");
const API = "https://en.wikipedia.org/w/api.php";
const UA = "TheAppleMuseum/1.0 (unofficial non-commercial fan museum; image credit script)";
const ONLY = process.argv.slice(2).filter((a) => !a.startsWith("-"));

// Keep in sync with lib/wiki.ts
const WIKI_OVERRIDES = {
  "apple-m1": "Apple_M1",
  "macbook-air-m1": "MacBook_Air_(Apple_silicon)",
  "vision-pro": "Apple_Vision_Pro",
  "iphone-air": "IPhone_Air",
  "macbook-neo": "MacBook_Neo",
  "iphone-18-pro": "IPhone_18_Pro",
  "iphone-duo": "IPhone_Duo",
  "macbook-pro-proled": "MacBook_Pro_(Apple_silicon)",
};

const FREE_LICENSE = /^(public domain|pd|cc0|cc[- ]by(-sa)?[- ]?\d|cc[- ]by(-sa)?$|gfdl|attribution)/i;
const SKIP_NAME = /logo|icon|symbol|wordmark|emblem|flag|map|diagram|chart|graph|signature|commons-|wiki|question_book|edit-clear|padlock|ambox|crystal|nuvola|folder|portal|\.svg$|\.gif$/i;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(params) {
  const url = `${API}?${new URLSearchParams({ format: "json", formatversion: "2", ...params })}`;
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url, { headers: { "User-Agent": UA } });
    if (res.ok) return res.json();
    await sleep(1000 * (attempt + 1));
  }
  throw new Error(`Wikipedia API failed: ${url}`);
}

function stripHtml(s = "") {
  return s.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
}

/** Lead image + other images in the article, in article order. */
async function articleImages(title) {
  const json = await api({ action: "query", titles: title, redirects: "1", prop: "pageimages|images", piprop: "name", imlimit: "60" });
  const page = json.query?.pages?.[0];
  if (!page || page.missing) return null;
  const names = [];
  if (page.pageimage) names.push(`File:${page.pageimage}`);
  for (const im of page.images ?? []) if (!names.includes(im.title)) names.push(im.title);
  return { title: page.title, names: names.filter((n) => !SKIP_NAME.test(n)) };
}

async function searchTitle(query) {
  const json = await api({ action: "query", list: "search", srsearch: query, srlimit: "1" });
  return json.query?.search?.[0]?.title;
}

/** Image info for up to 50 files; keeps Commons-hosted, freely licensed photos. */
async function freePhotos(fileTitles) {
  const out = [];
  for (let i = 0; i < fileTitles.length; i += 40) {
    const batch = fileTitles.slice(i, i + 40);
    const json = await api({
      action: "query",
      titles: batch.join("|"),
      prop: "imageinfo",
      iiprop: "url|size|mime|extmetadata",
      iiurlwidth: "1800",
    });
    const pages = json.query?.pages ?? [];
    for (const title of batch) {
      const page = pages.find((p) => p.title === title);
      const info = page?.imageinfo?.[0];
      if (!info) continue;
      if (page.imagerepository !== "shared") continue; // Commons only (en-wiki-local files are often non-free)
      if (!/image\/(jpeg|png|webp)/.test(info.mime)) continue;
      if ((info.width ?? 0) < 600 || (info.height ?? 0) < 400) continue;
      const meta = info.extmetadata ?? {};
      const license = stripHtml(meta.LicenseShortName?.value);
      if (!FREE_LICENSE.test(license)) continue;
      if (meta.NonFree?.value === "true") continue;
      out.push({
        file: title,
        url: info.thumburl ?? info.url,
        artist: stripHtml(meta.Artist?.value) || "Unknown author",
        license,
        licenseUrl: meta.LicenseUrl?.value,
        source: info.descriptionurl,
      });
    }
    await sleep(300);
  }
  return out;
}

async function saveImage(url, target, { maxWidth = 1800 } = {}) {
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  if (!res.ok) throw new Error(`download ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  await mkdir(dirname(target), { recursive: true });
  await sharp(buf).rotate().resize({ width: maxWidth, withoutEnlargement: true }).flatten({ background: "#0c0c0c" }).jpeg({ quality: 84, progressive: true, mozjpeg: true }).toFile(target);
}

/* ------------------------------------------------------------------ main */

const productsSrc = await readFile(join(ROOT, "data/products.ts"), "utf8");
const products = [];
for (const block of productsSrc.split(/\n\s*p\(\{/).slice(1)) {
  const slug = block.match(/\bslug: "([^"]+)"/)?.[1];
  if (!slug) continue;
  const name = block.match(/\bname: "([^"]+)"/)?.[1];
  const category = block.match(/\bcategory: "([^"]+)"/)?.[1];
  const wiki = block.match(/source: wiki\("([^"]+)"\)/)?.[1];
  products.push({ slug, name, category, wiki: WIKI_OVERRIDES[slug] ?? (wiki ? decodeURIComponent(wiki) : null) });
}

let credits = {};
try {
  credits = JSON.parse(await readFile(CREDITS_FILE, "utf8"));
} catch {}

let ok = 0;
const missing = [];
for (const p of products) {
  if (ONLY.length && !ONLY.includes(p.slug)) continue;
  try {
    let title = p.wiki ?? (await searchTitle(`${p.name} Apple`));
    let art = title ? await articleImages(title) : null;
    if (!art || !art.names.length) {
      title = await searchTitle(`${p.name} Apple`);
      art = title ? await articleImages(title) : null;
    }
    if (!art) throw new Error("no article");
    const photos = await freePhotos(art.names.slice(0, 40));
    if (!photos.length) throw new Error("no freely licensed photo");

    const dir = `/images/products/${p.slug}`;
    const targets = ["hero.jpg", "detail-1.jpg", "detail-2.jpg", "detail-3.jpg", "detail-4.jpg"];
    // Clear stale credits for this product, then write fresh ones.
    for (const t of targets) delete credits[`${dir}/${t}`];
    let saved = 0;
    for (const photo of photos) {
      if (saved >= targets.length) break;
      const path = `${dir}/${targets[saved]}`;
      try {
        await saveImage(photo.url, join(PUBLIC, path));
        credits[path] = { file: photo.file.replace(/^File:/, ""), artist: photo.artist, license: photo.license, licenseUrl: photo.licenseUrl, source: photo.source };
        saved++;
      } catch (e) {
        console.warn(`  ! ${p.slug}: ${e.message}`);
      }
      await sleep(250);
    }
    ok++;
    console.log(`✓ ${p.slug.padEnd(24)} ${saved} photo(s) from “${art.title}”`);
  } catch (e) {
    missing.push(p.slug);
    console.log(`✗ ${p.slug.padEnd(24)} ${e.message} (placeholder kept)`);
  }
  await sleep(400);
}

/* Home, era and story images reuse the best product photos. */
const REUSE = {
  "/images/home/exhibits/mac.jpg": "imac-g3",
  "/images/home/exhibits/ipod.jpg": "ipod",
  "/images/home/exhibits/iphone.jpg": "iphone",
  "/images/home/exhibits/ipad.jpg": "ipad",
  "/images/home/exhibits/watch.jpg": "apple-watch",
  "/images/home/exhibits/audio.jpg": "airpods",
  "/images/home/exhibits/vision.jpg": "vision-pro",
  "/images/home/story-vision.jpg": "apple-i",
  "/images/home/story-craft.jpg": "imac-g3",
  "/images/home/story-legacy.jpg": "vision-pro",
  "/images/home/ordinary-1.jpg": "macintosh-128k",
  "/images/home/ordinary-2.jpg": "iphone-x",
  "/images/home/ordinary-3.jpg": "apple-watch",
  "/images/home/philosophy-macro.jpg": "macbook-air",
  "/images/home/timeline-hero.jpg": "apple-ii",
  "/images/home/collection-hero.jpg": "macintosh-128k",
  "/images/home/cta.jpg": "power-mac-g4-cube",
  "/images/eras/garage.jpg": "apple-i",
  "/images/eras/macintosh.jpg": "macintosh-128k",
  "/images/eras/wilderness.jpg": "powerbook-100",
  "/images/eras/return.jpg": "imac-g3",
  "/images/eras/ipod.jpg": "ipod",
  "/images/eras/iphone.jpg": "iphone",
  "/images/eras/ecosystem.jpg": "apple-watch",
  "/images/eras/silicon.jpg": "apple-m1",
  "/images/eras/spatial.jpg": "vision-pro",
};
for (const [target, slug] of Object.entries(REUSE)) {
  // Prefer a detail shot for variety, fall back to the hero.
  const candidates = [`/images/products/${slug}/detail-1.jpg`, `/images/products/${slug}/hero.jpg`];
  const from = target.includes("/eras/") || target.includes("exhibits") ? candidates.reverse().find((c) => credits[c]) : candidates.find((c) => credits[c]);
  if (!from) continue;
  await copyFile(join(PUBLIC, from), join(PUBLIC, target));
  credits[target] = credits[from];
}

const sorted = Object.fromEntries(Object.entries(credits).sort(([a], [b]) => a.localeCompare(b)));
await writeFile(CREDITS_FILE, JSON.stringify(sorted, null, 2) + "\n");

console.log(`\nDone: ${ok} products with real photos, ${missing.length} kept placeholders.`);
if (missing.length) console.log(`Placeholders kept for: ${missing.join(", ")}`);
console.log("Credits written to data/image-credits.json — they appear on product pages and /legal.");
