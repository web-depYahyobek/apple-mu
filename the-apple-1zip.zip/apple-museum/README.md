# The Apple Museum

An unofficial, fan-made digital museum of everything Apple has released: hardware, software, services and accessories, from 1976 to today. It's dark, cinematic and editorial, with scroll-driven motion.

> Unofficial fan-made museum. Apple and all product names are trademarks of Apple Inc.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind CSS v4 · GSAP 3.13 (ScrollTrigger, SplitText, Flip) · Lenis · Framer Motion

---

## Quick start

```bash
npm install
cp .env.example .env.local     # set NEXT_PUBLIC_SITE_URL to your domain
npm run dev                    # http://localhost:3000
npm run build && npm start     # production
```

Requires Node 18.18 or newer (Node 20+ recommended).

| Script | What it does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` | Production build (all product pages are statically generated) |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run images:real` | Downloads real, freely licensed product photos from Wikimedia Commons (see Images) |
| `npm run images` | Creates placeholder images for any referenced file that is missing (`-- --force` regenerates all) |

---

## Folder structure

```
app/
  layout.tsx                 Root layout: font, metadata, JSON-LD, client shell
  template.tsx               Page-transition wipe (re-mounts on every route)
  globals.css                Tailwind v4 theme tokens + utilities (display, micro, counter…)
  page.tsx                   Home (8 sections)
  timeline/page.tsx          Year-by-year timeline
  collection/page.tsx        Filterable archive
  collection/[slug]/         Product detail + per-product Open Graph image
  eras/ software/ about/ visit/ legal/ sitemap/
  api/contact, api/newsletter   Server-side validated form endpoints (stubs)
  sitemap.xml/route.ts       XML sitemap (route handler, so /sitemap stays a page)
  robots.ts, opengraph-image.tsx, not-found.tsx
components/
  layout/   Preloader, Cursor, Header, NavOverlay, SmoothScroll (Lenis), Footer
  home/     HeroCollage, Philosophy, PinnedStory, StickyImageList, OrdinaryEnds,
            TimelinePreview (pinned horizontal strip), CollectionPreview, ClosingCta
  ui/       RevealImage, SplitHeadline, FadeIn, Button, Marquee, MuseumImage, PageHeader, JsonLd
  collection/ CollectionGrid (Flip + masonry), ProductCard
  timeline/   Timeline, YearCounter
  product/    ProductHero, SpecsTable, Gallery, Lightbox
  eras/ software/ forms/
data/
  types.ts      Content schema
  products.ts   66 products (the archive)
  eras.ts       9 eras with colour moods
  software.ts   OS families, versions, apps
  home.ts       Home page copy, collage, exhibits, decade cards
lib/            gsap.ts (plugin registration + shared media queries), site config, helpers
public/images/  Placeholder artwork (replace with licensed images, same filenames)
scripts/        generate-placeholders.mjs
```

---

## Adding or editing products

All content lives in `data/products.ts`. Each entry follows this schema (`data/types.ts`):

```ts
{
  slug: "ipod",                         // URL: /collection/ipod (unique)
  name: "iPod",
  category: "iPod",                     // Classic | Mac | iPod | iPhone | iPad | Watch | Audio | TV/Home | Vision | Software | Services | Accessories
  releaseDate: "2001-11-10",            // "YYYY-MM-DD", or "YYYY-MM" if only the month is certain
  announced: "2001-10-23",              // optional
  discontinued: "July 2002 · iPod classic line ended September 2014", // or null if still available
  priceAtLaunch: "$399",
  designers: ["Tony Fadell", "Jony Ive"],
  summary: "One or two sentences.",
  whyItMattered: ["Paragraph 1", "Paragraph 2", "Paragraph 3"],
  specs: [{ label: "Storage", value: "5 GB hard drive" }],
  era: "ipod",                          // garage | macintosh | wilderness | return | ipod | iphone | ecosystem | silicon | spatial
  source: { label: "Apple Newsroom", url: "https://www.apple.com/newsroom/…" },
  // images: optional; defaults to /images/products/<slug>/hero.jpg + detail-1…4.jpg
}
```

`year` is derived from `releaseDate`. Use the `p({...})` helper in the file, and the `s([...])` helper for specs.

Once an entry is added, the product automatically appears in the collection, the timeline, its era, the sitemap, the XML sitemap and the related-product rows. It also gets a statically generated page and Open Graph image. Run `npm run images` to create its placeholders.

**Moving to a CMS:** the schema is flat and serialisable. Replace the exports in `data/*.ts` with fetchers that return the same shapes. The pages already call `getProduct`, `getNeighbours`, `getRelated`, `groupByYear` and the other query helpers.

**Accuracy:** dates are first public availability in the US, and prices are US launch prices. Each entry links its source, and those sources are shown on the product page. Entries for 2025–2026 are based on Apple Newsroom and contemporary press coverage. Re-check them before publishing, especially for products announced but not yet shipping (e.g. the MacBook Pro with PROLED XDR, available November 6, 2026).

---

## Images

### Real photographs (recommended)

```bash
npm run images:real                 # all products (takes a few minutes)
npm run images:real -- ipod imac-g3 # only some products
```

This downloads **real photos of each product from Wikimedia Commons**. It uses the lead image and other photos from each product's English Wikipedia article. **It only keeps freely licensed files** (public domain, CC0, CC BY, CC BY-SA), and it saves them over the placeholders using the same filenames. Author, licence and source go into `data/image-credits.json`, which feeds the credit line on every photo, the lightbox captions and the "Photo credits" list on `/legal`. Home and era images are then filled from the matching products. Products with no free photo, which is most software, keep their placeholder. Re-run it at any time.

Product pages also show **the full Wikipedia introduction** for each product (fetched at build time, revalidated daily, with CC BY-SA attribution). Clicking a card in the collection opens a **quick view** with all the facts, specs and story, without leaving the page.

### Placeholders

All images are generated **placeholders**: a dark studio floor with a generic silhouette and the filename printed on it. They are original artwork and safe to ship, but you'll want real photography.

**Where files go** (replace a file, keep its name):

| Path | Used for | Suggested size |
| --- | --- | --- |
| `public/images/products/<slug>/hero.jpg` | Cards, collage, product hero | 1000×1250 (4:5) or larger |
| `public/images/products/<slug>/detail-1…4.jpg` | Product gallery | 1400×1050 |
| `public/images/home/…` | Home sections (story, exhibits, ordinary, timeline, collection) | see filenames |
| `public/images/eras/<era>.jpg` | Era sections | 1920×1200 |
| `public/images/software/<family>-<version>.jpg` | Evolution sliders | 1600×1000 (same size per family) |
| `public/images/pages/about.jpg`, `visit.jpg` | About / Visit | 1200×1500 / 1920×1440 |

Update the `alt` text in the data files when you replace an image.

**Where to source licensed images:**

- **Apple Newsroom press kits**: each press release has downloadable images (newsroom pages link "Download all images"). These are intended for editorial use. Read and follow the terms on each kit, and credit Apple.
- **Wikimedia Commons**: many vintage Apple products (Apple I, Lisa, Macintosh, Newton…) have **public-domain or Creative Commons** photos. Check the licence on each file page, and credit the author and licence (e.g. "Photo: Name, CC BY-SA 4.0"). Add credits to `app/legal/page.tsx` or next to the image.
- Your own photography of items in a collection.

**Do not hotlink.** Download the files into `public/images/` so `next/image` can optimise them.

**Blur placeholders:** every image uses a shared dark blur (`components/ui/MuseumImage.tsx`). For per-image blur, generate base64 previews at build time (e.g. with `plaiceholder` or `sharp`), store them next to each image entry, and pass `blurDataURL`.

---

## Motion system

- **Smooth scroll:** Lenis, driven by GSAP's ticker so ScrollTrigger stays in sync (`components/layout/SmoothScroll.tsx`). It exposes `scrollTo` and `lock` via `useSmoothScroll()`.
- **Reveals:** `RevealImage` (clip-path mask + scale 1.15 → 1), `SplitHeadline` (SplitText lines or words rising from a mask) and `FadeIn`.
- **Easing:** `expo.out` / `power3.out`, 0.8–1.2 s, stagger 0.06–0.12 s. Animations are transform, opacity and clip-path only.
- **Pinned sections:** ScrollTrigger `pin` + `scrub` for the three-step story, the "Ordinary ends here" sequence and the horizontal decade strip. Parallax uses 0.8× / 1.0× / 1.2× layers.
- **Breakpoints:** pinning and scrubbing only run at `min-width: 1024px` with `prefers-reduced-motion: no-preference` (`MQ.desktopMotion` in `lib/gsap.ts`). Below that, or with reduced motion, sections render a stacked layout (Tailwind `lg:motion-safe:` variants), and the horizontal strip becomes a native swipe carousel with scroll-snap.
- **Reduced motion:** Lenis is off, the marquee stops, parallax and pinning are off, and reveals become short fades.
- **Page transitions:** `app/template.tsx` wipes on every route change (Framer Motion).
- **Navigation overlay:** Framer Motion curtain with a staggered line reveal. Focus is trapped, Escape closes it, and focus returns to the toggle.

---

## SEO & accessibility

- Per-page `metadata` and canonical URLs, a default and a per-product Open Graph image (`next/og`), JSON-LD (`WebSite`, `Museum`, `ItemList`, `Product`, `BreadcrumbList`), `/sitemap.xml` and `/robots.txt`.
- A skip link, landmarks, a single `h1` per page, `aria-current` in navigation, labelled controls, an accessible slider (`role="slider"`, arrow keys / Home / End), a lightbox and menu with focus management, and forms with `aria-invalid`, linked error messages and focus on the first invalid field.
- The custom cursor only runs on fine pointers. Native cursors are kept for form fields.

---

## Forms

`/api/contact` and `/api/newsletter` validate on the server with the same rules as the client (`lib/validation.ts`) and currently just log. Connect them to your provider (Resend, Postmark, Buttondown, Mailchimp…) where the `TODO` comments are.

---

## Performance notes

- Product pages are statically generated (`generateStaticParams`, `dynamicParams = false`).
- Below-the-fold images lazy-load through `next/image` with AVIF/WebP. Only the first hero images use `priority`.
- GSAP and Lenis load only in client components. All animation is transform/opacity based, with `will-change` set on moving layers.
- To keep Lighthouse 90+, replace the placeholders with well-compressed images at the suggested sizes.

---

## Self-check status

This codebase was written in an environment without access to the npm registry. Next.js, GSAP, Lenis and Framer Motion could not be installed there, so it has **not yet been through `next build`**. It was verified with a preview build: the real React components and Tailwind v4 CSS, with small stand-ins for those four packages, rendered in Chromium. That check covered:

- all 13 routes (including a 404) at 375 / 768 / 1440 px: no console errors, no horizontal overflow, one `h1` each, every image has `alt`, every internal link and anchor resolves;
- interactions: preloader runs once per session, the navigation overlay (focus, Escape), collection filters/search/sort plus the `?category=` link, the lightbox (arrows, wrap, Escape), contact and newsletter validation and submission, slider keyboard control, the timeline decade filter, the skip link;
- reduced motion: stacked layouts on desktop, marquee stopped.

**Not yet verified:** the actual GSAP/Lenis/Framer motion (pinning, scrubbing, SplitText, Flip, smooth scroll), type-checking against the real library types, and Lighthouse. On first run, do `npm install && npm run typecheck && npm run build`, then scroll through the home page at desktop width.
